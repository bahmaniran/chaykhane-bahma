<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

echo json_encode([
    'app_name' => 'چای خانه',
    'latest_version' => '1.3.0',
    'min_supported_version' => '1.0.0',
    'direct_apk_url' => 'https://ghurfe.ir/api/Chaikhaneh-Release-Final.apk',
    'server_message' => 'به سرور آنلاین چایخانه خوش آمدید! رقابت هفتگی فعال است.',
    'status' => 'online'
], JSON_UNESCAPED_UNICODE);
