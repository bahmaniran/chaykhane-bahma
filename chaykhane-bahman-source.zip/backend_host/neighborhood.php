<?php
require_once __DIR__ . '/db.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'list';

if ($action === 'list') {
    try {
        $province = isset($_GET['province']) ? trim($_GET['province']) : '';
        $city = isset($_GET['city']) ? trim($_GET['city']) : '';

        $query = "
            SELECT `id`, `device_id`, `first_name`, `last_name`, `nickname`, `avatar_id`, `province`, `city`, `coins`, `current_level`, `weekly_score`, `emojis_json`
            FROM `chaikhaneh_users`
        ";
        $conditions = [];
        $params = [];

        if (!empty($province)) {
            $conditions[] = "`province` = :province";
            $params[':province'] = $province;
        }

        if (!empty($city)) {
            $conditions[] = "`city` = :city";
            $params[':city'] = $city;
        }

        if (count($conditions) > 0) {
            $query .= " WHERE " . implode(' AND ', $conditions);
        }

        $query .= " ORDER BY `weekly_score` DESC, `current_level` DESC LIMIT 60";

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $users = $stmt->fetchAll();

        echo json_encode([
            'status' => 'success',
            'total_players' => count($users),
            'top_users' => $users
        ], JSON_UNESCAPED_UNICODE);

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'react_emoji') {
    // ارسال ایموجی به حریف (فقط ایموجی مجاز است، چت متنی ممنوع است)
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    $allowedEmojis = ['☕', '🫖', '👏', '🏆', '🔥', '💪', '❤️', '🦁', '🌸'];

    if (!$data || empty($data['target_user_id']) || empty($data['emoji'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'ارسال شناسه کاربر و ایموجی الزامی است.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $targetId = trim($data['target_user_id']);
    $emoji = trim($data['emoji']);

    if (!in_array($emoji, $allowedEmojis)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'تنها ایموجی‌های مجاز چایخانه قابل ارسال هستند.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT `id`, `emojis_json` FROM `chaikhaneh_users` WHERE `id` = :id OR `device_id` = :id LIMIT 1");
        $stmt->execute([':id' => $targetId]);
        $target = $stmt->fetch();

        if ($target) {
            $currentEmojis = !empty($target['emojis_json']) ? json_decode($target['emojis_json'], true) : [];
            if (!is_array($currentEmojis)) $currentEmojis = [];
            $currentEmojis[$emoji] = ($currentEmojis[$emoji] ?? 0) + 1;

            $updateStmt = $pdo->prepare("UPDATE `chaikhaneh_users` SET `emojis_json` = :emojis WHERE `id` = :id");
            $updateStmt->execute([
                ':emojis' => json_encode($currentEmojis, JSON_UNESCAPED_UNICODE),
                ':id' => $target['id']
            ]);

            echo json_encode([
                'status' => 'success',
                'message' => 'ایموجی ' . $emoji . ' با موفقیت برای پهلوان ارسال شد!',
                'emojis' => $currentEmojis
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo json_encode(['status' => 'success', 'message' => 'ایموجی ارسال شد!']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['status' => 'ok', 'message' => 'API فعال است']);
