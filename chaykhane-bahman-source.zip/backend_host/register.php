<?php
require_once __DIR__ . '/db.php';

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!$data || empty($data['device_id']) || empty($data['first_name']) || empty($data['last_name'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'ارسال نام، نام خانوادگی و شناسه دستگاه الزامی است.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$deviceId = trim($data['device_id']);
$firstName = trim($data['first_name']);
$lastName = trim($data['last_name']);
$nickname = !empty($data['nickname']) ? trim($data['nickname']) : ($firstName . ' ' . $lastName);
$avatarId = !empty($data['avatar_id']) ? trim($data['avatar_id']) : 'osta_bahman';
$province = !empty($data['province']) ? trim($data['province']) : null;
$city = !empty($data['city']) ? trim($data['city']) : null;

try {
    $stmt = $pdo->prepare("
        INSERT INTO `chaikhaneh_users` (`device_id`, `first_name`, `last_name`, `nickname`, `avatar_id`, `province`, `city`)
        VALUES (:device_id, :first_name, :last_name, :nickname, :avatar_id, :province, :city)
        ON DUPLICATE KEY UPDATE
            `first_name` = VALUES(`first_name`),
            `last_name` = VALUES(`last_name`),
            `nickname` = VALUES(`nickname`),
            `avatar_id` = VALUES(`avatar_id`),
            `province` = VALUES(`province`),
            `city` = VALUES(`city`)
    ");

    $stmt->execute([
        ':device_id' => $deviceId,
        ':first_name' => $firstName,
        ':last_name' => $lastName,
        ':nickname' => $nickname,
        ':avatar_id' => $avatarId,
        ':province' => $province,
        ':city' => $city,
    ]);

    // بازگردانی اطلاعات کاربر
    $fetchStmt = $pdo->prepare("SELECT * FROM `chaikhaneh_users` WHERE `device_id` = :device_id LIMIT 1");
    $fetchStmt->execute([':device_id' => $deviceId]);
    $user = $fetchStmt->fetch();

    echo json_encode([
        'success' => true,
        'message' => 'اوستا ' . $firstName . ' با موفقیت در چایخانه ثبت شد!',
        'user' => $user
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطای ثبت اطلاعات: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
