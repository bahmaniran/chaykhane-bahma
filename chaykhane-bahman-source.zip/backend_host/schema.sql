-- جدول کاربران و رتبه‌بندی بازی چایخانه عمو بهمن
CREATE TABLE IF NOT EXISTS `chaikhaneh_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `device_id` VARCHAR(120) NOT NULL UNIQUE,
  `first_name` VARCHAR(80) NOT NULL,
  `last_name` VARCHAR(80) NOT NULL,
  `nickname` VARCHAR(120) NOT NULL,
  `avatar_id` VARCHAR(60) DEFAULT 'osta_bahman',
  `province` VARCHAR(80) DEFAULT NULL,
  `city` VARCHAR(80) DEFAULT NULL,
  `coins` INT DEFAULT 540,
  `current_level` INT DEFAULT 1,
  `weekly_score` INT DEFAULT 0,
  `emojis_json` TEXT DEFAULT NULL,
  `patogh_id` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_device` (`device_id`),
  INDEX `idx_score` (`weekly_score` DESC),
  INDEX `idx_level` (`current_level` DESC),
  INDEX `idx_province` (`province`),
  INDEX `idx_city` (`city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;
