<?php
require_once __DIR__ . '/db.php';

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!$data || empty($data['device_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'device_id معتبر نیست']);
    exit;
}

$deviceId = trim($data['device_id']);
$coins = isset($data['coins']) ? (int)$data['coins'] : 500;
$currentLevel = isset($data['current_level']) ? (int)$data['current_level'] : 1;
$weeklyDelta = isset($data['weekly_score_delta']) ? (int)$data['weekly_score_delta'] : 0;

try {
    $stmt = $pdo->prepare("
        INSERT INTO `chaikhaneh_users` (`device_id`, `first_name`, `last_name`, `nickname`, `coins`, `current_level`, `weekly_score`)
        VALUES (:device_id, 'مشتری', 'تازه', 'اوستای چایخانه', :coins, :current_level, :weekly_score)
        ON DUPLICATE KEY UPDATE
            `coins` = VALUES(`coins`),
            `current_level` = GREATEST(`current_level`, VALUES(`current_level`)),
            `weekly_score` = `weekly_score` + :weekly_delta
    ");

    $stmt->execute([
        ':device_id' => $deviceId,
        ':coins' => $coins,
        ':current_level' => $currentLevel,
        ':weekly_score' => max(0, $weeklyDelta),
        ':weekly_delta' => $weeklyDelta
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'پیشرفت کاربر با موفقیت در سرور همگام شد'
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
