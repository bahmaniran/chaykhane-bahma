<?php
// ==============================================================================
// admin_patch.php - مدیریت کامل آنلاین بازی، پچ زنده، آمار لاگ‌ها و لیست بازیکنان
// ==============================================================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Admin-Key');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// کلید رمز اختصاصی شما برای امنیت پنل مدیریت
$ADMIN_SECRET_KEY = 'bahman_pahlavan_2026';

$providedKey = $_SERVER['HTTP_X_ADMIN_KEY'] ?? ($_GET['key'] ?? ($_POST['key'] ?? ''));
if ($providedKey !== $ADMIN_SECRET_KEY) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'کلید امنیتی مدیریت نامعتبر است!'], JSON_UNESCAPED_UNICODE);
    exit;
}

// بارگذاری فایل دیتابیس اگر وجود دارد
$hasDb = false;
$pdo = null;
if (file_exists(__DIR__ . '/db.php')) {
    try {
        require_once __DIR__ . '/db.php';
        if (isset($pdo) && $pdo instanceof PDO) {
            $hasDb = true;
            // اطمینان از وجود جدول لاگ‌های بازی
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `chaikhaneh_game_logs` (
                  `id` INT AUTO_INCREMENT PRIMARY KEY,
                  `device_id` VARCHAR(120) NOT NULL,
                  `nickname` VARCHAR(120) DEFAULT NULL,
                  `action_type` VARCHAR(50) NOT NULL,
                  `level_num` INT DEFAULT 0,
                  `coins_delta` INT DEFAULT 0,
                  `details` TEXT DEFAULT NULL,
                  `ip_address` VARCHAR(45) DEFAULT NULL,
                  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  INDEX `idx_device` (`device_id`),
                  INDEX `idx_action` (`action_type`),
                  INDEX `idx_created` (`created_at` DESC)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;
            ");
        }
    } catch (Exception $e) {
        $hasDb = false;
    }
}

$dataFile = __DIR__ . '/live_data.json';
$currentData = [];

if (file_exists($dataFile)) {
    $raw = @file_get_contents($dataFile);
    $currentData = json_decode($raw, true) ?: [];
}

// خواندن بدنه درخواست POST یا پارامترهای GET
$rawPost = file_get_contents('php://input');
$input = json_decode($rawPost, true) ?: $_POST;
$action = $input['action'] ?? ($_GET['action'] ?? '');

// هندل کردن درخواست‌های GET یا گزارش‌ها
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($action)) {
    echo json_encode(['success' => true, 'data' => $currentData], JSON_UNESCAPED_UNICODE);
    exit;
}

switch ($action) {
    // ۱. دریافت لیست کامل بازیکنان همراه با آمار و فیلتر
    case 'get_players':
        if (!$hasDb || !$pdo) {
            echo json_encode([
                'success' => false,
                'message' => 'دیتابیس در دسترس نیست یا فایل db.php یافت نشد.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $search = trim($input['search'] ?? ($_GET['search'] ?? ''));
        $sortBy = trim($input['sort_by'] ?? ($_GET['sort_by'] ?? 'score_desc'));

        $orderSql = "ORDER BY `weekly_score` DESC, `current_level` DESC";
        if ($sortBy === 'coins_desc') {
            $orderSql = "ORDER BY `coins` DESC";
        } elseif ($sortBy === 'level_desc') {
            $orderSql = "ORDER BY `current_level` DESC, `weekly_score` DESC";
        } elseif ($sortBy === 'updated_desc') {
            $orderSql = "ORDER BY `updated_at` DESC";
        } elseif ($sortBy === 'created_desc') {
            $orderSql = "ORDER BY `created_at` DESC";
        }

        $whereClause = "";
        $params = [];
        if (!empty($search)) {
            $whereClause = "WHERE `nickname` LIKE :q OR `first_name` LIKE :q OR `last_name` LIKE :q OR `device_id` LIKE :q";
            $params[':q'] = "%{$search}%";
        }

        try {
            // آمار کلی
            $statsStmt = $pdo->query("
                SELECT 
                    COUNT(*) as total_users,
                    COALESCE(SUM(coins), 0) as total_coins,
                    COALESCE(MAX(current_level), 1) as max_level,
                    COALESCE(AVG(current_level), 1) as avg_level
                FROM `chaikhaneh_users`
            ");
            $summary = $statsStmt->fetch(PDO::FETCH_ASSOC);

            // استعلام لیست بازیکنان
            $sql = "SELECT `id`, `device_id`, `first_name`, `last_name`, `nickname`, `coins`, `current_level`, `weekly_score`, `created_at`, `updated_at` 
                    FROM `chaikhaneh_users` {$whereClause} {$orderSql} LIMIT 250";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $players = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'stats' => [
                    'total_players' => (int)($summary['total_users'] ?? 0),
                    'total_coins' => (int)($summary['total_coins'] ?? 0),
                    'max_level' => (int)($summary['max_level'] ?? 1),
                    'avg_level' => round((float)($summary['avg_level'] ?? 1), 1)
                ],
                'players' => $players
            ], JSON_UNESCAPED_UNICODE);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطای دیتابیس: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        break;

    // ۲. دریافت لیست لاگ‌ها و رویدادهای زنده بازی
    case 'get_game_logs':
        if (!$hasDb || !$pdo) {
            echo json_encode([
                'success' => false,
                'message' => 'دیتابیس متصل نیست.'
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        try {
            // استعلام آخرین ۱۰۰ لاگ بازی
            $stmt = $pdo->query("
                SELECT `id`, `device_id`, `nickname`, `action_type`, `level_num`, `coins_delta`, `details`, `ip_address`, `created_at`
                FROM `chaikhaneh_game_logs`
                ORDER BY `created_at` DESC
                LIMIT 100
            ");
            $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // در صورتی که جدول لاگ‌ها به تازگی ساخته شده و هنوز خالی است، رویدادهای اخیر را از روی جدول کاربران تولید می‌کنیم
            if (empty($logs)) {
                $userStmt = $pdo->query("
                    SELECT `device_id`, `nickname`, `current_level`, `coins`, `weekly_score`, `updated_at`
                    FROM `chaikhaneh_users`
                    ORDER BY `updated_at` DESC
                    LIMIT 20
                ");
                $recentUsers = $userStmt->fetchAll(PDO::FETCH_ASSOC);
                $simulatedLogs = [];
                $simId = 1;
                foreach ($recentUsers as $u) {
                    $simulatedLogs[] = [
                        'id' => $simId++,
                        'device_id' => $u['device_id'],
                        'nickname' => $u['nickname'] ?: 'اوستای چایخانه',
                        'action_type' => 'level_complete',
                        'level_num' => (int)$u['current_level'],
                        'coins_delta' => (int)$u['weekly_score'],
                        'details' => "حضور فعال در مرحله {$u['current_level']} با موجودی {$u['coins']} سکه",
                        'ip_address' => 'سرور آنلاین',
                        'created_at' => $u['updated_at'] ?: date('Y-m-d H:i:s')
                    ];
                }
                $logs = $simulatedLogs;
            }

            echo json_encode([
                'success' => true,
                'total_logs' => count($logs),
                'logs' => $logs
            ], JSON_UNESCAPED_UNICODE);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'خطای لاگ: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        break;

    // ۳. ارسال هدیه سکه اختصاصی به یک بازیکن خاص
    case 'gift_coins':
        if (!$hasDb || !$pdo) {
            echo json_encode(['success' => false, 'message' => 'دیتابیس در دسترس نیست.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $targetDeviceId = trim($input['device_id'] ?? '');
        $giftAmount = (int)($input['coins'] ?? 0);

        if (empty($targetDeviceId) || $giftAmount <= 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'شناسه بازیکن و مقدار سکه معتبر نیست.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        try {
            $stmt = $pdo->prepare("
                UPDATE `chaikhaneh_users`
                SET `coins` = `coins` + :gift, `updated_at` = CURRENT_TIMESTAMP
                WHERE `device_id` = :device_id
            ");
            $stmt->execute([':gift' => $giftAmount, ':device_id' => $targetDeviceId]);

            // ثبت در لاگ
            $logStmt = $pdo->prepare("
                INSERT INTO `chaikhaneh_game_logs` (`device_id`, `nickname`, `action_type`, `level_num`, `coins_delta`, `details`, `ip_address`)
                VALUES (:device_id, 'مدیریت چایخانه', 'coin_reward', 0, :gift, :details, 'پنل مدیریت')
            ");
            $logStmt->execute([
                ':device_id' => $targetDeviceId,
                ':gift' => $giftAmount,
                ':details' => "اعطای {$giftAmount} سکه طلای تشویقی از طریق پنل مدیریت"
            ]);

            echo json_encode([
                'success' => true,
                'message' => "تعداد {$giftAmount} سکه هدیه با موفقیت به بازیکن با شناسه {$targetDeviceId} اعطا شد!"
            ], JSON_UNESCAPED_UNICODE);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        break;

    // ۴. ارسال نوتیفیکیشن پاپ‌آپ زنده
    case 'set_broadcast':
        $currentData['broadcast'] = $input['broadcast'] ?? null;
        if (!empty($input['announcement'])) {
            $currentData['announcement'] = trim($input['announcement']);
        }
        $currentData['timestamp'] = time();
        @file_put_contents($dataFile, json_encode($currentData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'پیام زنده با موفقیت برای تمام بازیکنان منتشر شد!'], JSON_UNESCAPED_UNICODE);
        break;

    // ۵. حذف اعلان فعال
    case 'clear_broadcast':
        $currentData['broadcast'] = null;
        $currentData['timestamp'] = time();
        @file_put_contents($dataFile, json_encode($currentData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'اعلان فعال حذف شد.'], JSON_UNESCAPED_UNICODE);
        break;

    // ۶. ویرایش و تزریق زنده کد جاوااسکریپت و استایل CSS
    case 'set_code_patch':
        $currentData['patch_id'] = $input['patch_id'] ?? ('patch_' . time());
        $currentData['custom_js'] = $input['custom_js'] ?? '';
        $currentData['custom_css'] = $input['custom_css'] ?? '';
        $currentData['timestamp'] = time();
        @file_put_contents($dataFile, json_encode($currentData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'کد زنده (JS/CSS) با موفقیت در بازی تمام کاربران اعمال شد!'], JSON_UNESCAPED_UNICODE);
        break;

    // ۷. به‌روزرسانی مشخصات فایل نصبی APK
    case 'set_apk_update':
        $currentData['latest_version'] = $input['latest_version'] ?? '1.3.0';
        $currentData['version_code'] = (int)($input['version_code'] ?? 13);
        $currentData['direct_apk_url'] = $input['direct_apk_url'] ?? '';
        $currentData['changelog'] = $input['changelog'] ?? '';
        $currentData['force_update'] = !empty($input['force_update']);
        $currentData['timestamp'] = time();

        $configSync = [
            'app_name' => 'چای خانه',
            'latest_version' => $currentData['latest_version'],
            'min_supported_version' => $currentData['force_update'] ? $currentData['latest_version'] : '1.0.0',
            'direct_apk_url' => $currentData['direct_apk_url'],
            'server_message' => $currentData['announcement'] ?? 'به سرور آنلاین چایخانه خوش آمدید!',
            'changelog' => $currentData['changelog'],
            'status' => 'online'
        ];
        @file_put_contents(__DIR__ . '/config.json', json_encode($configSync, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        @file_put_contents($dataFile, json_encode($currentData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'تنظیمات نسخه APK با موفقیت ذخیره شد!'], JSON_UNESCAPED_UNICODE);
        break;

    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'عملیات نامعتبر است'], JSON_UNESCAPED_UNICODE);
        break;
}
