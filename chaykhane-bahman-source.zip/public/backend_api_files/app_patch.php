<?php
// ==============================================================================
// app_patch.php - سرویس تحویل زنده کد، اعلان‌ها و استایل به کلاینت‌های بازی (OTA)
// ==============================================================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dataFile = __DIR__ . '/live_data.json';

// داده‌های پیش‌فرض در صورت نبود فایل
$defaultData = [
    'patch_id' => 'initial_1.0.0',
    'version_code' => 12,
    'latest_version' => '1.3.0',
    'direct_apk_url' => 'https://ghurfe.ir/api/Chaikhaneh-Release-Final.apk',
    'announcement' => '«صفای قدم همه مشتیا، چای داغ نبات‌دار به راهه!»',
    'custom_js' => '',
    'custom_css' => '',
    'broadcast' => null,
    'timestamp' => time()
];

if (file_exists($dataFile)) {
    $raw = @file_get_contents($dataFile);
    $json = json_decode($raw, true);
    if (is_array($json)) {
        echo json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
}

// در صورت عدم وجود فایل، مقدار پیش‌فرض را خروجی و ذخیره می‌کنیم
@file_put_contents($dataFile, json_encode($defaultData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
echo json_encode($defaultData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
