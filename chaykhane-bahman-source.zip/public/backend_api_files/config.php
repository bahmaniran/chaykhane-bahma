<?php
// ==============================================================================
// config.php - استعلام وضعیت نسخه و دانلود مستقیم APK بازی
// ==============================================================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dataFile = __DIR__ . '/live_data.json';
$latestVersion = '1.3.0';
$directApkUrl = 'https://ghurfe.ir/api/Chaikhaneh-Release-Final.apk';
$serverMessage = 'به سرور آنلاین چایخانه خوش آمدید! رقابت هفتگی فعال است.';
$changelog = "• اضافه شدن مراحل جدید\n• رفع باگ‌ها و ارتقای چشمگیر سرعت";
$forceUpdate = false;

if (file_exists($dataFile)) {
    $raw = @file_get_contents($dataFile);
    $d = json_decode($raw, true);
    if (is_array($d)) {
        if (!empty($d['latest_version'])) $latestVersion = $d['latest_version'];
        if (!empty($d['direct_apk_url'])) $directApkUrl = $d['direct_apk_url'];
        if (!empty($d['announcement'])) $serverMessage = $d['announcement'];
        if (!empty($d['changelog'])) $changelog = $d['changelog'];
        if (isset($d['force_update'])) $forceUpdate = (bool)$d['force_update'];
    }
}

echo json_encode([
    'app_name' => 'چای خانه',
    'current_version' => $latestVersion,
    'latest_version' => $latestVersion,
    'min_supported_version' => $forceUpdate ? $latestVersion : '1.0.0',
    'direct_apk_url' => $directApkUrl,
    'announcement' => $serverMessage,
    'server_message' => $serverMessage,
    'changelog' => $changelog,
    'force_update' => $forceUpdate,
    'status' => 'online'
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
