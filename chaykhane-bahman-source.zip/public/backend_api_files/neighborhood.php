<?php
require_once __DIR__ . '/db.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'list';

if ($action === 'list') {
    try {
        // دریافت ۵۰ بازیکن برتر بر اساس امتیاز هفتگی و مرحله
        $stmt = $pdo->query("
            SELECT `id`, `device_id`, `first_name`, `last_name`, `nickname`, `coins`, `current_level`, `weekly_score`
            FROM `chaikhaneh_users`
            ORDER BY `weekly_score` DESC, `current_level` DESC
            LIMIT 50
        ");
        $users = $stmt->fetchAll();

        echo json_encode([
            'status' => 'success',
            'total_players' => count($users),
            'top_users' => $users
        ], JSON_UNESCAPED_UNICODE);

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['status' => 'ok', 'message' => 'API فعال است']);
