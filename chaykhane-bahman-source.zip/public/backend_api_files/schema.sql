-- ==============================================================================
-- پایگاه‌داده MySQL بازی سنتی چایخانه عمو بهمن
-- نسخه سازگار با MariaDB / MySQL 5.7+ / MySQL 8.0+
-- ==============================================================================

-- ۱. جدول کاربران و رتبه‌بندی بازی چایخانه
CREATE TABLE IF NOT EXISTS `chaikhaneh_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `device_id` VARCHAR(120) NOT NULL UNIQUE,
  `first_name` VARCHAR(80) NOT NULL,
  `last_name` VARCHAR(80) NOT NULL,
  `nickname` VARCHAR(120) NOT NULL,
  `coins` INT DEFAULT 500,
  `current_level` INT DEFAULT 1,
  `weekly_score` INT DEFAULT 0,
  `patogh_id` VARCHAR(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_device` (`device_id`),
  INDEX `idx_score` (`weekly_score` DESC),
  INDEX `idx_level` (`current_level` DESC),
  INDEX `idx_updated` (`updated_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ۲. جدول لاگ‌های فعالیت و رویدادهای زنده بازی
CREATE TABLE IF NOT EXISTS `chaikhaneh_game_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `device_id` VARCHAR(120) NOT NULL,
  `nickname` VARCHAR(120) DEFAULT NULL,
  `action_type` VARCHAR(50) NOT NULL, -- level_complete, sync, register, coin_reward, purchase
  `level_num` INT DEFAULT 0,
  `coins_delta` INT DEFAULT 0,
  `details` TEXT DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_device` (`device_id`),
  INDEX `idx_action` (`action_type`),
  INDEX `idx_created` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;
