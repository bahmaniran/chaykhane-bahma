<?php
// ==============================================================================
// sync.php - همگام‌سازی پیشرفت، سکه‌ها و ثبت لاگ فعالیت بازیکن
// ==============================================================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Signature, X-Timestamp');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/db.php';

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

if (!$data || empty($data['device_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'شناسه دستگاه device_id معتبر نیست'], JSON_UNESCAPED_UNICODE);
    exit;
}

$deviceId = trim($data['device_id']);
$coins = isset($data['coins']) ? (int)$data['coins'] : 500;
$currentLevel = isset($data['current_level']) ? (int)$data['current_level'] : 1;
$weeklyDelta = isset($data['weekly_score_delta']) ? (int)$data['weekly_score_delta'] : 0;
$nickname = !empty($data['nickname']) ? trim($data['nickname']) : 'اوستای چایخانه';
$firstName = !empty($data['first_name']) ? trim($data['first_name']) : 'مشتری';
$lastName = !empty($data['last_name']) ? trim($data['last_name']) : 'تازه';

try {
    // ۱. به‌روزرسانی یا ثبت پیشرفت در جدول کاربران
    $stmt = $pdo->prepare("
        INSERT INTO `chaikhaneh_users` (`device_id`, `first_name`, `last_name`, `nickname`, `coins`, `current_level`, `weekly_score`)
        VALUES (:device_id, :first_name, :last_name, :nickname, :coins, :current_level, :weekly_score)
        ON DUPLICATE KEY UPDATE
            `coins` = VALUES(`coins`),
            `current_level` = GREATEST(`current_level`, VALUES(`current_level`)),
            `weekly_score` = `weekly_score` + :weekly_delta,
            `updated_at` = CURRENT_TIMESTAMP
    ");

    $stmt->execute([
        ':device_id' => $deviceId,
        ':first_name' => $firstName,
        ':last_name' => $lastName,
        ':nickname' => $nickname,
        ':coins' => $coins,
        ':current_level' => $currentLevel,
        ':weekly_score' => max(0, $weeklyDelta),
        ':weekly_delta' => $weeklyDelta
    ]);

    // ۲. ثبت خودکار لاگ فعالیت بازی (در صورت وجود جدول لاگ)
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $actionType = $weeklyDelta > 0 ? 'level_complete' : 'sync';
        $details = $weeklyDelta > 0 
            ? ("تکمیل چالش مرحله {$currentLevel} (امتیاز +{$weeklyDelta})") 
            : ("همگام‌سازی سکه‌ها: {$coins} و سطح: {$currentLevel}");

        $logStmt = $pdo->prepare("
            INSERT INTO `chaikhaneh_game_logs` (`device_id`, `nickname`, `action_type`, `level_num`, `coins_delta`, `details`, `ip_address`)
            VALUES (:device_id, :nickname, :action_type, :level_num, :coins_delta, :details, :ip)
        ");
        $logStmt->execute([
            ':device_id' => $deviceId,
            ':nickname' => $nickname,
            ':action_type' => $actionType,
            ':level_num' => $currentLevel,
            ':coins_delta' => $weeklyDelta,
            ':details' => $details,
            ':ip' => $ip
        ]);
    } catch (Exception $logEx) {
        // عدم وقفه در عملکرد بازیکن در صورت عدم وجود جدول لاگ
    }

    echo json_encode([
        'success' => true,
        'message' => 'پیشرفت کاربر و لاگ بازی با موفقیت در سرور همگام شد'
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
