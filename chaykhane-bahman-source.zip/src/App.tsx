import React, { useState, useEffect, useCallback, useRef } from 'react';
import confetti from 'canvas-confetti';
import { Cup, DrinkType, RadioTrackId, ShopItem, PlayerProfile, WeeklyChallengeStage } from './types';
import { generateLevel, LevelConfig } from './game/LevelGenerator';
import { solveWaterSort, isBoardSolved, findImmediateBestMove } from './game/Solver';
import { soundEngine } from './audio/SoundEngine';
import {
  saveLocalState,
  loadLocalState,
  createPayloadSignature,
  queueOfflineSync,
} from './utils/antiCheat';
import {
  getStoredPlayerProfile,
  syncProgressToServer,
  fetchServerConfig,
  ServerConfig,
  APP_VERSION,
} from './services/backendApi';
import {
  completeWeeklyStage,
  getWeeklyChallengeState,
  getWeeklyStagesForCurrentWeek,
} from './game/WeeklyChallengeService';
import { toPersianDigits, formatPersianCoins } from './utils/persianNumbers';

// Core Gameplay Components
import { HUD } from './components/HUD';
import { Estekan } from './components/Estekan';
import { ActionBar } from './components/ActionBar';
import { RushOrderBanner } from './components/RushOrderBanner';
import { OnboardingPointer } from './components/OnboardingPointer';
import { TeahouseAtmosphere } from './components/TeahouseAtmosphere';
import { PersianTeahouseScene } from './components/PersianTeahouseScene';
import { VIPBossBanner } from './components/VIPBossBanner';
import {
  getDailyRewardStatus,
  claimDailyReward,
  DailyRewardStatus,
} from './services/DailyRewardService';
// Lazy-loaded Modals for lightning-fast initial load & ultra-lightweight bundle
const RadioModal = React.lazy(() => import('./components/modals/RadioModal').then((m) => ({ default: m.RadioModal })));
const SpecialGuestModal = React.lazy(() => import('./components/modals/SpecialGuestModal').then((m) => ({ default: m.SpecialGuestModal })));
const FortuneModal = React.lazy(() => import('./components/modals/FortuneModal').then((m) => ({ default: m.FortuneModal })));
const DecorationShopModal = React.lazy(() => import('./components/modals/DecorationShopModal').then((m) => ({ default: m.DecorationShopModal })));
const NeighborhoodModal = React.lazy(() => import('./components/modals/NeighborhoodModal').then((m) => ({ default: m.NeighborhoodModal })));
const DailyRewardModal = React.lazy(() => import('./components/modals/DailyRewardModal').then((m) => ({ default: m.DailyRewardModal })));
const VictoryModal = React.lazy(() => import('./components/modals/VictoryModal').then((m) => ({ default: m.VictoryModal })));
const RegisterPlayerModal = React.lazy(() => import('./components/modals/RegisterPlayerModal').then((m) => ({ default: m.RegisterPlayerModal })));
const WeeklyChallengeModal = React.lazy(() => import('./components/modals/WeeklyChallengeModal').then((m) => ({ default: m.WeeklyChallengeModal })));
const ContactModal = React.lazy(() => import('./components/modals/ContactModal').then((m) => ({ default: m.ContactModal })));
const MainMenuModal = React.lazy(() => import('./components/modals/MainMenuModal').then((m) => ({ default: m.MainMenuModal })));
const GameGuideModal = React.lazy(() => import('./components/modals/GameGuideModal').then((m) => ({ default: m.GameGuideModal })));
const DaftarHesabModal = React.lazy(() => import('./components/modals/DaftarHesabModal').then((m) => ({ default: m.DaftarHesabModal })));
const NaghaliModal = React.lazy(() => import('./components/modals/NaghaliModal').then((m) => ({ default: m.NaghaliModal })));
const DecorationRenovationModal = React.lazy(() => import('./components/modals/DecorationRenovationModal').then((m) => ({ default: m.DecorationRenovationModal })));
const PatoghModal = React.lazy(() => import('./components/modals/PatoghModal').then((m) => ({ default: m.PatoghModal })));
const SiniGardaniModal = React.lazy(() => import('./components/modals/SiniGardaniModal').then((m) => ({ default: m.SiniGardaniModal })));
const TakhtehNardModal = React.lazy(() => import('./components/modals/TakhtehNardModal').then((m) => ({ default: m.TakhtehNardModal })));
const PahlavaniCardModal = React.lazy(() => import('./components/modals/PahlavaniCardModal').then((m) => ({ default: m.PahlavaniCardModal })));
const HavalehModal = React.lazy(() => import('./components/modals/HavalehModal').then((m) => ({ default: m.HavalehModal })));
const NightMysteryModal = React.lazy(() => import('./components/modals/NightMysteryModal').then((m) => ({ default: m.NightMysteryModal })));
const AppUpdateModal = React.lazy(() => import('./components/modals/AppUpdateModal').then((m) => ({ default: m.AppUpdateModal })));
const AutoUpdateModal = React.lazy(() => import('./components/modals/AutoUpdateModal').then((m) => ({ default: m.AutoUpdateModal })));
const PahlavaniAchievementsModal = React.lazy(() => import('./components/modals/PahlavaniAchievementsModal').then((m) => ({ default: m.PahlavaniAchievementsModal })));
const LiveBroadcastModal = React.lazy(() => import('./components/modals/LiveBroadcastModal').then((m) => ({ default: m.LiveBroadcastModal })));
const DakhleBahmanDrawer = React.lazy(() => import('./components/DakhleBahmanDrawer').then((m) => ({ default: m.DakhleBahmanDrawer })));
const AiLimitModal = React.lazy(() => import('./components/modals/AiLimitModal').then((m) => ({ default: m.AiLimitModal })));
const InstallEstekanModal = React.lazy(() => import('./components/modals/InstallEstekanModal').then((m) => ({ default: m.InstallEstekanModal })));
import {
  getAiQuotaStatus,
  recordAiStageCompleted,
  formatAiTimeRemaining,
  askUncleBahmanAi,
  AiQuotaStatus,
} from './services/AiSolverService';
import { fetchAndApplyLivePatch, markBroadcastAsSeen, RemoteBroadcastMessage } from './services/LivePatchService';
import {
  incrementTeasPouredCount,
  incrementSugarCubesDissolvedCount,
} from './services/PahlavaniAchievements';
import { checkForAppUpdate, shouldPromptUpdate, recordUpdateCheckedNow } from './services/UpdateService';
import { AppUpdateInfo } from './types';
import {
  getDaftarHesab,
  borrowDebt,
  advanceDebtStreak,
  failDebtStreak,
  repayDebtRepossession,
  getNaghaliState,
  saveNaghaliState,
  awardNaghaliPiece,
  getOwnedDecorations,
  saveOwnedDecorations,
  getDailyTipStatus,
  claimDailyTip,
  canRollDiceToday,
  VIP_BOSSES,
} from './services/TeahouseStore';
import { syncWithBackend } from './utils/apiClient';
import { VIPBossCustomer } from './types';
import exactTeahouseBg from './assets/images/teahouse_exact_scene_1791919273685.webp';

const EXACT_TEAHOUSE_BG = exactTeahouseBg;

const OSTA_SPEECHES = [
  'باریکلا جوون، حواستو جمع کن!',
  'دمت گرم، عجب چای قندپهلوئی شد! دست مریزاد!',
  'شربت خنک زعفران، دوای درد خستگی پهلوون‌هاست.',
  'عجله کار شیطونه! اول فکر کن، بعد استکان رو کج کن.',
  'خاکشیر دوفاز رو دیدی چطور ته‌نشین شد؟ هنر یعنی این!',
  'سماور همیشه در حال جوشه، دل ما هم به دیدارت روشنه!',
];

export default function App() {
  // Game progression state
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [coins, setCoins] = useState<number>(540);
  const [stars, setStars] = useState<number>(1);
  const [cups, setCups] = useState<Cup[]>([]);
  const [history, setHistory] = useState<Cup[][]>([]);
  const [selectedCupIdx, setSelectedCupIdx] = useState<number | null>(null);
  const [extraCupUsed, setExtraCupUsed] = useState<boolean>(false);
  const [movesCount, setMovesCount] = useState<number>(0);

  // Pouring animation state
  const [pouringCupIdx, setPouringCupIdx] = useState<number | null>(null);
  const [pourTargetIdx, setPourTargetIdx] = useState<number | null>(null);
  const [pourDirection, setPourDirection] = useState<'left' | 'right'>('right');

  // Solver hint
  const [hint, setHint] = useState<{ fromIndex: number; toIndex: number } | null>(null);

  // Timed Rush Mode (Every 5th level)
  const [isRushMode, setIsRushMode] = useState<boolean>(false);
  const [rushTimeLeft, setRushTimeLeft] = useState<number>(45);
  const [rushTargets, setRushTargets] = useState<DrinkType[]>([]);
  const [isRushWon, setIsRushWon] = useState<boolean>(false);

  // Audio & Settings
  const [colorblindMode, setColorblindMode] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [volume, setVolume] = useState<number>(0.8);
  const [activeRadioTrack, setActiveRadioTrack] = useState<RadioTrackId>('tar_sonati');

  // Cozy Night Mode (Auto-detected between 20:00 and 06:00, or user toggled)
  const [isNightMode, setIsNightMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('bahman_night_mode');
      if (saved !== null) return saved === 'true';
    } catch {}
    const h = new Date().getHours();
    return h >= 20 || h < 6;
  });

  // Progressive Feature Disclosure: Dev Toggle to Unlock All UI
  const [unlockAll, setUnlockAll] = useState<boolean>(() => {
    try {
      return localStorage.getItem('bahman_unlock_all') === 'true';
    } catch {
      return false;
    }
  });

  // Modals state
  const [isMainMenuOpen, setIsMainMenuOpen] = useState<boolean>(false);
  const [isCounterDrawerOpen, setIsCounterDrawerOpen] = useState<boolean>(false);
  const [isHavalehOpen, setIsHavalehOpen] = useState<boolean>(false);
  const [isRadioOpen, setIsRadioOpen] = useState<boolean>(false);
  const [isSpecialGuestOpen, setIsSpecialGuestOpen] = useState<boolean>(false);
  const [isFortuneOpen, setIsFortuneOpen] = useState<boolean>(false);
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [isNeighborhoodOpen, setIsNeighborhoodOpen] = useState<boolean>(false);
  const [isDailyRewardOpen, setIsDailyRewardOpen] = useState<boolean>(false);
  const [dailyRewardStatus, setDailyRewardStatus] = useState<DailyRewardStatus>(() =>
    getDailyRewardStatus()
  );
  const [isVictoryOpen, setIsVictoryOpen] = useState<boolean>(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);
  const [isWeeklyChallengeOpen, setIsWeeklyChallengeOpen] = useState<boolean>(false);
  const [isContactOpen, setIsContactOpen] = useState<boolean>(false);
  const [isGameGuideOpen, setIsGameGuideOpen] = useState<boolean>(false);

  // 10 Viral Mechanics Modals & State
  const [isDaftarHesabOpen, setIsDaftarHesabOpen] = useState<boolean>(false);
  const [debtState, setDebtState] = useState(() => getDaftarHesab());
  const [isNaghaliOpen, setIsNaghaliOpen] = useState<boolean>(false);
  const [naghaliState, setNaghaliState] = useState(() => getNaghaliState());
  const [isRenovationsOpen, setIsRenovationsOpen] = useState<boolean>(false);
  const [ownedDecorations, setOwnedDecorations] = useState<string[]>(() => getOwnedDecorations());
  const [isPatoghOpen, setIsPatoghOpen] = useState<boolean>(false);
  const [isSiniGardaniOpen, setIsSiniGardaniOpen] = useState<boolean>(false);
  const [isTakhtehNardOpen, setIsTakhtehNardOpen] = useState<boolean>(false);
  const [isPahlavaniCardOpen, setIsPahlavaniCardOpen] = useState<boolean>(false);
  const [isNightMysteryOpen, setIsNightMysteryOpen] = useState<boolean>(false);
  const [isAchievementsOpen, setIsAchievementsOpen] = useState<boolean>(false);

  // In-App Direct APK & OTA Update
  const [isAppUpdateOpen, setIsAppUpdateOpen] = useState<boolean>(false);
  const [appUpdateInfo, setAppUpdateInfo] = useState<AppUpdateInfo | null>(null);

  // Direct Self-Updater & Live Server Config (https://ghurfe.ir/api/config.php)
  const [serverConfig, setServerConfig] = useState<ServerConfig | null>(null);
  const [isAutoUpdateOpen, setIsAutoUpdateOpen] = useState<boolean>(false);
  const [isInstallOpen, setIsInstallOpen] = useState<boolean>(false);

  // Live OTA Broadcast Push Notification without App Update
  const [liveBroadcast, setLiveBroadcast] = useState<RemoteBroadcastMessage | null>(null);
  const [isLiveBroadcastOpen, setIsLiveBroadcastOpen] = useState<boolean>(false);

  // Uncle Bahman AI Brain 1-Hour Quota (Max 3 Stages Per Hour per user)
  const [aiQuota, setAiQuota] = useState<AiQuotaStatus>(() => getAiQuotaStatus());
  const [isAiLimitOpen, setIsAiLimitOpen] = useState<boolean>(false);
  const [isCurrentLevelAiAssisted, setIsCurrentLevelAiAssisted] = useState<boolean>(false);

  // VIP Boss Customer
  const [activeVIPBoss, setActiveVIPBoss] = useState<VIPBossCustomer | null>(null);
  const [vipBossTimeLeft, setVipBossTimeLeft] = useState<number | undefined>(undefined);
  const [vipBossMovesLeft, setVipBossMovesLeft] = useState<number | undefined>(undefined);

  // Weekly Challenge Active Play State
  const [activeWeeklyStage, setActiveWeeklyStage] = useState<WeeklyChallengeStage | null>(null);
  const [weeklyCompletedIds, setWeeklyCompletedIds] = useState<number[]>(() => {
    return getWeeklyChallengeState().completedStageIds;
  });
  const [weeklyPointsWon, setWeeklyPointsWon] = useState<number>(0);
  const [weeklyEarnedCoins, setWeeklyEarnedCoins] = useState<number>(0);

  // Player Profile
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile>(getStoredPlayerProfile());

  // Customization & Collections
  const [unlockedShopItems, setUnlockedShopItems] = useState<string[]>([
    'carpet_gelim',
    'samovar_halabi',
    'window_khaki',
  ]);
  const [equippedCarpet, setEquippedCarpet] = useState<string>('carpet_gelim');
  const [equippedSamovar, setEquippedSamovar] = useState<string>('samovar_halabi');
  const [equippedWindow, setEquippedWindow] = useState<string>('window_khaki');
  const [sugarCubes, setSugarCubes] = useState<number[]>([1]);
  const [isSpecialChallengeAccepted, setIsSpecialChallengeAccepted] = useState<boolean>(false);

  // Osta Bahman & Guidance
  const [speechText, setSpeechText] = useState<string>(OSTA_SPEECHES[0]);
  const stuckSecondsRef = useRef<number>(0);
  const [failCount, setFailCount] = useState<number>(0);
  const [isStuckAlert, setIsStuckAlert] = useState<boolean>(false);
  const [onboardingActive, setOnboardingActive] = useState<boolean>(true);
  const speechResetTimerRef = useRef<number | null>(null);

  // Non-intrusive speech notification dispatcher with 4-second auto-dismiss
  const setCozySpeech = useCallback((text: string, isPersistent: boolean = false) => {
    setSpeechText(text);
    if (speechResetTimerRef.current) {
      clearTimeout(speechResetTimerRef.current);
      speechResetTimerRef.current = null;
    }
    if (!isPersistent) {
      speechResetTimerRef.current = window.setTimeout(() => {
        setSpeechText(OSTA_SPEECHES[Math.floor(Math.random() * OSTA_SPEECHES.length)]);
      }, 4000);
    }
  }, []);

  // Level progress percentage
  const levelProgressPercent = Math.min(100, 20 + ((currentLevel % 5) / 5) * 80);

  // Penalty lock state: active if debt was defaulted and item repossessed
  const isPenaltyLocked = Boolean(debtState.repossessedItem);

  // Android Hardware Back Button & Esc Key handler for smooth mobile navigation
  useEffect(() => {
    const handleBackButton = (e: Event) => {
      // If any modal is open, prevent default app exit and dismiss topmost modal
      if (
        isGameGuideOpen || isFortuneOpen || isMainMenuOpen || isCounterDrawerOpen ||
        isHavalehOpen || isRadioOpen || isSpecialGuestOpen || isShopOpen ||
        isNeighborhoodOpen || isDailyRewardOpen || isVictoryOpen || isRegisterOpen ||
        isWeeklyChallengeOpen || isContactOpen || isDaftarHesabOpen || isNaghaliOpen ||
        isRenovationsOpen || isPatoghOpen || isSiniGardaniOpen || isTakhtehNardOpen ||
        isPahlavaniCardOpen || isNightMysteryOpen || isAchievementsOpen ||
        isAppUpdateOpen || isAutoUpdateOpen || isLiveBroadcastOpen || isInstallOpen
      ) {
        if ('preventDefault' in e) e.preventDefault();
        soundEngine.playClick();
        if (isInstallOpen) setIsInstallOpen(false);
        else if (isLiveBroadcastOpen) setIsLiveBroadcastOpen(false);
        else if (isVictoryOpen) setIsVictoryOpen(false);
        else if (isGameGuideOpen) setIsGameGuideOpen(false);
        else if (isFortuneOpen) setIsFortuneOpen(false);
        else if (isAutoUpdateOpen) setIsAutoUpdateOpen(false);
        else if (isAppUpdateOpen) setIsAppUpdateOpen(false);
        else if (isAchievementsOpen) setIsAchievementsOpen(false);
        else if (isNightMysteryOpen) setIsNightMysteryOpen(false);
        else if (isPahlavaniCardOpen) setIsPahlavaniCardOpen(false);
        else if (isTakhtehNardOpen) setIsTakhtehNardOpen(false);
        else if (isSiniGardaniOpen) setIsSiniGardaniOpen(false);
        else if (isPatoghOpen) setIsPatoghOpen(false);
        else if (isRenovationsOpen) setIsRenovationsOpen(false);
        else if (isNaghaliOpen) setIsNaghaliOpen(false);
        else if (isDaftarHesabOpen) setIsDaftarHesabOpen(false);
        else if (isContactOpen) setIsContactOpen(false);
        else if (isWeeklyChallengeOpen) setIsWeeklyChallengeOpen(false);
        else if (isRegisterOpen) setIsRegisterOpen(false);
        else if (isDailyRewardOpen) setIsDailyRewardOpen(false);
        else if (isNeighborhoodOpen) setIsNeighborhoodOpen(false);
        else if (isShopOpen) setIsShopOpen(false);
        else if (isSpecialGuestOpen) setIsSpecialGuestOpen(false);
        else if (isRadioOpen) setIsRadioOpen(false);
        else if (isHavalehOpen) setIsHavalehOpen(false);
        else if (isCounterDrawerOpen) setIsCounterDrawerOpen(false);
        else if (isMainMenuOpen) setIsMainMenuOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleBackButton(e);
      }
    };

    document.addEventListener('backbutton', handleBackButton, false);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('backbutton', handleBackButton, false);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [
    isGameGuideOpen, isFortuneOpen, isMainMenuOpen, isCounterDrawerOpen,
    isHavalehOpen, isRadioOpen, isSpecialGuestOpen, isShopOpen,
    isNeighborhoodOpen, isDailyRewardOpen, isVictoryOpen, isRegisterOpen,
    isWeeklyChallengeOpen, isContactOpen, isDaftarHesabOpen, isNaghaliOpen,
    isRenovationsOpen, isPatoghOpen, isSiniGardaniOpen, isTakhtehNardOpen,
    isPahlavaniCardOpen, isNightMysteryOpen, isAchievementsOpen,
    isAppUpdateOpen, isAutoUpdateOpen
  ]);

  // Load saved state on mount
  useEffect(() => {
    const saved = loadLocalState();
    if (saved) {
      setCurrentLevel(saved.currentLevel || 1);
      setCoins(saved.coins ?? 540);
      setStars(saved.stars || 1);
      setColorblindMode(!!saved.colorblindMode);
      setSoundEnabled(saved.soundEnabled !== false);
      if (saved.unlockedShopItems) setUnlockedShopItems(saved.unlockedShopItems);
      if (saved.equippedCarpet) setEquippedCarpet(saved.equippedCarpet);
      if (saved.equippedSamovar) setEquippedSamovar(saved.equippedSamovar);
      if (saved.equippedWindow) setEquippedWindow(saved.equippedWindow);
      if (saved.sugarCubesCollected) setSugarCubes(saved.sugarCubesCollected);
      if (saved.activeTrack) setActiveRadioTrack(saved.activeTrack);
    }
  }, []);

  // Daily Login Reward Auto-check
  useEffect(() => {
    const status = getDailyRewardStatus();
    setDailyRewardStatus(status);
    if (status.canClaim) {
      const timer = setTimeout(() => {
        setIsDailyRewardOpen(true);
      }, 750);
      return () => clearTimeout(timer);
    }
  }, []);

  // In-App Direct APK & OTA Update Automatic Check on Launch
  useEffect(() => {
    let isMounted = true;
    const checkUpdates = async () => {
      try {
        const info = await checkForAppUpdate();
        if (!isMounted) return;
        setAppUpdateInfo(info);
        recordUpdateCheckedNow();
        if (shouldPromptUpdate(info)) {
          // Delay display slightly so initial game UI renders smoothly
          setTimeout(() => {
            if (isMounted) setIsAppUpdateOpen(true);
          }, 1400);
        }
      } catch {}
    };

    checkUpdates();
    return () => {
      isMounted = false;
    };
  }, []);

  // Direct Self-Updater & Live Server Config System (https://ghurfe.ir/api/config.php & app_patch.php)
  useEffect(() => {
    let isMounted = true;
    const checkLiveServerConfig = async () => {
      try {
        // 1. Fetch live server config
        const config = await fetchServerConfig();
        if (isMounted && config) {
          setServerConfig(config);

          // If data.announcement is returned, display it in Uncle Bahman's speech bubble
          if (config.announcement && config.announcement.trim()) {
            setCozySpeech(config.announcement.trim(), true);
          }

          // If data.current_version !== APP_VERSION, automatically open AutoUpdateModal
          if (config.current_version && config.current_version !== APP_VERSION) {
            setTimeout(() => {
              if (isMounted) {
                setIsAutoUpdateOpen(true);
              }
            }, 1200);
          }
        }

        // 2. Fetch and apply Live Remote Code (JS/CSS) & Live Broadcast without updating APK
        const patchResult = await fetchAndApplyLivePatch();
        if (isMounted && patchResult) {
          if (patchResult.announcement && patchResult.announcement.trim()) {
            setCozySpeech(patchResult.announcement.trim(), true);
          }
          if (patchResult.broadcast) {
            setLiveBroadcast(patchResult.broadcast);
            setIsLiveBroadcastOpen(true);
          }
        }
      } catch (err) {
        console.warn('Failed to fetch server config on startup:', err);
      }
    };

    checkLiveServerConfig();
    return () => {
      isMounted = false;
    };
  }, [setCozySpeech]);

  // Initialize level
  const initLevel = useCallback(
    (lvl: number) => {
      const config: LevelConfig = generateLevel(lvl);
      setCups(config.cups);
      setHistory([]);
      setSelectedCupIdx(null);
      setExtraCupUsed(false);
      setMovesCount(0);
      setHint(null);
      setIsCurrentLevelAiAssisted(false);
      setAiQuota(getAiQuotaStatus());
      stuckSecondsRef.current = 0;
      setFailCount(0);
      setIsStuckAlert(false);
      setIsRushWon(false);

      // VIP Boss Customer every 10 levels
      if (lvl % 10 === 0) {
        const bossKeys = Object.keys(VIP_BOSSES);
        const boss = VIP_BOSSES[bossKeys[(Math.floor(lvl / 10) - 1) % bossKeys.length]];
        setActiveVIPBoss(boss);
        setVipBossTimeLeft(boss.timeLimit);
        setVipBossMovesLeft(boss.movesLimit);
        if (boss.id === 'poet_shekasteh') {
          config.cups.forEach((c) => {
            if (c.layers.length > 0) c.isSteamy = true;
          });
        }
        setCozySpeech(`«${boss.dialogue[0]}»`, true);
      } else {
        setActiveVIPBoss(null);
        setVipBossTimeLeft(undefined);
        setVipBossMovesLeft(undefined);
        setCozySpeech(OSTA_SPEECHES[Math.floor(Math.random() * OSTA_SPEECHES.length)]);
      }

      setIsRushMode(config.isRushMode);
      if (config.isRushMode && config.rushTargets) {
        setRushTargets(config.rushTargets);
        setRushTimeLeft(config.rushTimeLimit || 45);
      }

      setOnboardingActive(lvl === 1);
    },
    [setCozySpeech]
  );

  useEffect(() => {
    initLevel(currentLevel);
  }, [currentLevel, initLevel]);

  // VIP Boss Impatient Timer
  useEffect(() => {
    if (!vipBossTimeLeft || vipBossTimeLeft <= 0 || !activeVIPBoss) return;
    const timer = setInterval(() => {
      setVipBossTimeLeft((prev) => {
        if (!prev || prev <= 1) {
          clearInterval(timer);
          soundEngine.playTrayClatter();
          setCozySpeech('«جواد سبیل: دیر کردی رفیق! سرویس رفت، منم رفتم!»');
          setTimeout(() => initLevel(currentLevel), 1500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [vipBossTimeLeft, activeVIPBoss, currentLevel, initLevel, setCozySpeech]);

  // Rush Order Timer
  useEffect(() => {
    if (!isRushMode || isRushWon || rushTimeLeft <= 0) return;
    const timer = setInterval(() => {
      setRushTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          soundEngine.playTrayClatter();
          setCozySpeech('«سفارش فوری سوخت! دست بجنبون پهلوون.»');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isRushMode, isRushWon, rushTimeLeft, setCozySpeech]);

  // Stuck Detection
  useEffect(() => {
    if (isBoardSolved(cups) || isVictoryOpen) return;
    const interval = setInterval(() => {
      stuckSecondsRef.current += 1;
      if (stuckSecondsRef.current >= 60 && !isStuckAlert) {
        setIsStuckAlert(true);
        setCozySpeech('«خسته شدی پهلوون؟ این راهنما مهمون من!»', true);
        const solution = solveWaterSort(cups);
        if (solution && solution.length > 0) {
          setHint(solution[0]);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [cups, isStuckAlert, isVictoryOpen, setCozySpeech]);

  // Sound Engine sync
  useEffect(() => {
    soundEngine.setMuted(!soundEnabled);
  }, [soundEnabled]);

  useEffect(() => {
    soundEngine.setVolume(volume);
  }, [volume]);

  // Save state helper
  const persistState = useCallback(
    async (lvl: number, c: number, s: number) => {
      const hash = await createPayloadSignature({ level: lvl, coins: c, stars: s });
      saveLocalState({
        currentLevel: lvl,
        coins: c,
        stars: s,
        extraCupsUsedInLevel: 0,
        colorblindMode,
        soundEnabled,
        musicEnabled: true,
        volume,
        activeTrack: activeRadioTrack,
        sugarCubesCollected: sugarCubes,
        unlockedShopItems,
        equippedCarpet,
        equippedSamovar,
        equippedWindow,
        lastDailyChallengeDate: new Date().toISOString().split('T')[0],
        stateHash: hash,
      });

      queueOfflineSync({
        id: `sync_${Date.now()}`,
        timestamp: Date.now(),
        levelCompleted: lvl,
        coinsEarned: c,
        signature: hash,
      });
    },
    [
      colorblindMode,
      soundEnabled,
      volume,
      activeRadioTrack,
      sugarCubes,
      unlockedShopItems,
      equippedCarpet,
      equippedSamovar,
      equippedWindow,
    ]
  );

  // Claim daily reward
  const handleClaimDailyReward = (rewardAmount: number) => {
    const res = claimDailyReward();
    if (res.success) {
      setCoins((prev) => {
        const next = prev + res.rewardAmount;
        persistState(currentLevel, next, stars);
        return next;
      });
      setDailyRewardStatus(getDailyRewardStatus());
      setCozySpeech('«عیدی عمو بهمن نوش جونت پهلوون! دشت اول صبح برکت چایخانه‌ست.»');
    }
  };

  // Check valid target cups from source
  const getValidTargetIndices = useCallback(
    (sourceIdx: number, cupList: Cup[]): number[] => {
      const source = cupList[sourceIdx];
      if (!source || source.layers.length === 0 || source.isFrozenSolid) {
        return [];
      }
      const sourceTop = source.layers[source.layers.length - 1];

      const validList: number[] = [];
      cupList.forEach((target, idx) => {
        if (idx === sourceIdx || target.isFrozenSolid || target.layers.length >= 4) return;
        if (target.layers.length === 0) {
          validList.push(idx);
        } else {
          const targetTop = target.layers[target.layers.length - 1];
          if (targetTop === sourceTop) {
            validList.push(idx);
          }
        }
      });
      return validList;
    },
    []
  );

  // Execute valid pour from source to target with silky-smooth two-phase timing
  const executePour = useCallback(
    (fromIdx: number, toIdx: number, customBaseCups?: Cup[]) => {
      const baseCups = customBaseCups || cups;
      const sourceCup = baseCups[fromIdx];
      const targetCup = baseCups[toIdx];
      if (!sourceCup || !targetCup || sourceCup.layers.length === 0) return;

      setHistory((prev) => [...prev, baseCups.map((c) => ({ ...c, layers: [...c.layers] }))]);

      const sourceTop = sourceCup.layers[sourceCup.layers.length - 1];
      let count = 0;
      for (let k = sourceCup.layers.length - 1; k >= 0; k--) {
        if (sourceCup.layers[k] === sourceTop) count++;
        else break;
      }

      const availableSpace = 4 - targetCup.layers.length;
      const transferCount = Math.min(count, availableSpace);
      if (transferCount <= 0) return;

      // Stage 1: Smoothly tilt towards target and trigger authentic pouring audio
      setPouringCupIdx(fromIdx);
      setPourTargetIdx(toIdx);
      setPourDirection(fromIdx < toIdx ? 'right' : 'left');
      soundEngine.playPouring(targetCup.layers.length);

      // Stage 2: Liquid flow transfer happens at the crest of the tilt arc (320ms)
      setTimeout(() => {
        const nextCups = baseCups.map((c) => ({ ...c, layers: [...c.layers] }));
        const newSource = nextCups[fromIdx];
        const newTarget = nextCups[toIdx];

        for (let i = 0; i < transferCount; i++) {
          newSource.layers.pop();
          newTarget.layers.push(sourceTop);
        }

        // Sugar Cube Blocker Melt (melted instantly by warm tea!)
        if (newTarget.hasSugarCubeBlocker) {
          newTarget.hasSugarCubeBlocker = false;
          soundEngine.playSugarMelt();
          setCozySpeech('«ایول پهلوون! قند حبه با چای داغ ذوب شد و مسیر استکان باز شد!»');
        }

        // Steamy Mystery Glass Reveal
        if (newSource.isSteamy) {
          newSource.isSteamy = false;
          soundEngine.playClick();
          setCozySpeech('«بخار استکان کنار رفت و رنگ چای آشکار شد!»');
        }

        // Decrement Cooling Tea Move Count
        nextCups.forEach((c) => {
          if (c.coolingMovesLeft !== undefined && !c.isFrozenSolid) {
            c.coolingMovesLeft = Math.max(0, c.coolingMovesLeft - 1);
            if (c.coolingMovesLeft === 0) {
              c.isFrozenSolid = true;
              soundEngine.playIceFreeze();
              setCozySpeech('«وای وای! چای سرد شد و استکان یخ زد و قفل شد!»');
            }
          }
        });

        // VIP Boss Moves Limit Check
        if (vipBossMovesLeft !== undefined) {
          const nextMoves = vipBossMovesLeft - 1;
          setVipBossMovesLeft(nextMoves);
          if (nextMoves <= 0) {
            soundEngine.playTrayClatter();
            setCozySpeech('«حاج‌آقا بازاری: چرتکه انداختم، حرکت‌هات تموم شد! از سود افتادیم!»');
            setTimeout(() => initLevel(currentLevel), 1500);
            return;
          }
        }

        // Update liquid layers while cup is holding the tilt
        setCups(nextCups);

        // Visual Closure celebration
        const targetIsNowComplete =
          newTarget.layers.length === 4 && newTarget.layers.every((l) => l === newTarget.layers[0]);

        if (targetIsNowComplete) {
          incrementTeasPouredCount(1);
          soundEngine.playSaucerClink();
          soundEngine.playCupServedSteam();
          setCozySpeech('«نوش جان مشتری! یه استکان دیشلمه با نعلبکی و قند پهلو چیده شد.»');
        }

        // Stage 3: Smooth return transition back to resting state without sudden pop/jump
        setTimeout(() => {
          setSelectedCupIdx(null);
          setPouringCupIdx(null);
          setPourTargetIdx(null);
          setMovesCount((prev) => prev + 1);

          if (isBoardSolved(nextCups)) {
            setTimeout(
              () => {
                handleWin(nextCups);
              },
              targetIsNowComplete ? 600 : 220
            );
          }
        }, 220);
      }, 320);
    },
    [cups, vipBossMovesLeft, initLevel, currentLevel, setCozySpeech]
  );

  // Handle cup tap with useCallback to prevent re-rendering Estekans
  const handleCupClick = React.useCallback(
    (cupIdx: number) => {
      // Prevent tapping while a pour animation is underway
      if (pouringCupIdx !== null) return;

      if (onboardingActive) setOnboardingActive(false);
      stuckSecondsRef.current = 0;

      // Obstacle Check: Frozen solid
      if (cups[cupIdx].isFrozenSolid) {
        soundEngine.playIceFreeze();
        setCozySpeech('«این استکان یخ زده و قفله پهلوون! نمی‌تونی بهش دست بزنی.»');
        return;
      }

      // Smart Hint Tap Execution: If hint is active and user taps either the hint source or target cup
      if (hint && (cupIdx === hint.fromIndex || cupIdx === hint.toIndex)) {
        const from = hint.fromIndex;
        const to = hint.toIndex;
        setHint(null);
        setSelectedCupIdx(null);
        executePour(from, to);
        return;
      }

      if (selectedCupIdx === null) {
        // Obstacle Check: Tap directly on cup with sugar cube dissolves it instantly and selects cup!
        if (cups[cupIdx].hasSugarCubeBlocker) {
          const nextCups = [...cups];
          nextCups[cupIdx] = { ...nextCups[cupIdx], hasSugarCubeBlocker: false };
          setCups(nextCups);
          incrementSugarCubesDissolvedCount();
          soundEngine.playSugarMelt();
          setCozySpeech('«قند حبه با یک اشاره حل شد! مسیر استکان کاملاً باز شد.»');
          if (nextCups[cupIdx].layers.length > 0) {
            setSelectedCupIdx(cupIdx);
          }
          return;
        }
        if (cups[cupIdx].layers.length === 0) {
          soundEngine.playGlassClink();
          return;
        }
        soundEngine.playGlassClink();
        setSelectedCupIdx(cupIdx);
        return;
      }

      if (selectedCupIdx === cupIdx) {
        soundEngine.playGlassClink();
        setSelectedCupIdx(null);
        return;
      }

      const sourceCup = cups[selectedCupIdx];
      const targetCup = cups[cupIdx];

      // If target cup has a sugar cube blocker, dissolve it immediately with warm tea!
      if (targetCup.hasSugarCubeBlocker) {
        targetCup.hasSugarCubeBlocker = false;
        soundEngine.playSugarMelt();
        setCozySpeech('«چای داغ ریختی و قند فوراً حل شد!»');
      }

      if (targetCup.layers.length >= 4) {
        soundEngine.playGlassClink();
        setSelectedCupIdx(cupIdx);
        return;
      }

      const sourceTop = sourceCup.layers[sourceCup.layers.length - 1];
      const targetTop = targetCup.layers[targetCup.layers.length - 1];

      if (targetCup.layers.length > 0 && targetTop !== sourceTop) {
        soundEngine.playGlassClink();
        setSelectedCupIdx(cupIdx);
        setFailCount((prev) => {
          const next = prev + 1;
          if (next >= 3 && !isStuckAlert) {
            setIsStuckAlert(true);
            setCozySpeech('«حواست کجاست پهلوون؟ رنگ‌ها باید یکی باشن. بذار کمکت کنم!»', true);
            const solution = solveWaterSort(cups);
            if (solution && solution.length > 0) {
              setHint(solution[0]);
            }
          }
          return next;
        });
        return;
      }

      // VALID POUR!
      executePour(selectedCupIdx, cupIdx);
    },
    [onboardingActive, cups, selectedCupIdx, isStuckAlert, setCozySpeech, executePour, pouringCupIdx]
  );

  // Smart Double-Tap Quick Pour: automatically pours to best target without reaching across screen!
  const handleDoubleTapCup = React.useCallback(
    (cupIdx: number) => {
      if (pouringCupIdx !== null) return;

      const cup = cups[cupIdx];
      if (!cup || cup.layers.length === 0 || cup.hasSugarCubeBlocker || cup.isFrozenSolid) {
        handleCupClick(cupIdx);
        return;
      }

      const validTargets = getValidTargetIndices(cupIdx, cups);
      if (validTargets.length === 0) {
        handleCupClick(cupIdx);
        return;
      }

      const sourceTop = cup.layers[cup.layers.length - 1];
      // First preference: cup with matching color
      let bestTarget = validTargets.find(
        (idx) =>
          cups[idx].layers.length > 0 &&
          cups[idx].layers[cups[idx].layers.length - 1] === sourceTop
      );
      // Second preference: empty cup
      if (bestTarget === undefined) {
        bestTarget = validTargets[0];
      }

      executePour(cupIdx, bestTarget);
    },
    [cups, handleCupClick, executePour, pouringCupIdx, getValidTargetIndices]
  );

  const handleStartWeeklyStage = (stage: WeeklyChallengeStage) => {
    setActiveWeeklyStage(stage);
    setCups(stage.initialCups.map((c) => ({ ...c, layers: [...c.layers] })));
    setHistory([]);
    setSelectedCupIdx(null);
    setExtraCupUsed(false);
    setMovesCount(0);
    setHint(null);
    stuckSecondsRef.current = 0;
    setFailCount(0);
    setIsStuckAlert(false);
    setIsRushMode(false);
    setOnboardingActive(false);
    setCozySpeech(
      `«مرحله ${toPersianDigits(stage.id)} چالش دوشنبه: ${stage.title}! یا علی بگو و استکان‌ها رو بچین.»`
    );
  };

  const handleWin = (finalCups: Cup[]) => {
    soundEngine.playSanturVictory();
    try {
      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#0D9488', '#8B0000', '#FDE047'],
      });
    } catch {}

    if (activeWeeklyStage) {
      const res = completeWeeklyStage(activeWeeklyStage.id);
      const earned = res.rewardCoins;
      const weeklyScoreBonus = res.rewardWeeklyScore;
      setWeeklyPointsWon(weeklyScoreBonus);
      setWeeklyEarnedCoins(earned);

      const newCoins = coins + earned;
      setCoins(newCoins);
      persistState(currentLevel, newCoins, stars + 1);

      const updatedState = getWeeklyChallengeState();
      setWeeklyCompletedIds(updatedState.completedStageIds);

      syncProgressToServer({
        coins: newCoins,
        currentLevel: currentLevel,
        weeklyScoreDelta: weeklyScoreBonus,
        decorations: {
          carpet: equippedCarpet,
          samovar: equippedSamovar,
          window: equippedWindow,
        },
      }).catch(() => {});

      setIsVictoryOpen(true);
      return;
    }

    let earned = 60;
    if (isSpecialChallengeAccepted) {
      earned *= 2;
    }
    if (isRushMode && rushTimeLeft > 0) {
      earned += 150;
      setIsRushWon(true);
    }

    // 0. AI Quota tracking if current stage was completed using AI assistance
    if (isCurrentLevelAiAssisted) {
      const updatedQuota = recordAiStageCompleted(currentLevel);
      setAiQuota(updatedQuota);
      setIsCurrentLevelAiAssisted(false);
    }

    // 1. VIP Boss Tip
    if (activeVIPBoss) {
      earned += activeVIPBoss.tipReward;
      setCozySpeech(`«${activeVIPBoss.dialogue[2]}»`);
      setActiveVIPBoss(null);
    }

    // 2. Daftar Hesab: Advance debt win streak
    if (debtState.isDebtActive) {
      const debtRes = advanceDebtStreak();
      setDebtState(debtRes.state);
      if (debtRes.cleared) {
        setCozySpeech('«حسابت صاف شد پهلوون! حلالت باشه! اسمت از دفتر خط خورد.»', true);
      }
    }

    // 3. Naghali piece
    if (naghaliState.isActive) {
      const pieceRes = awardNaghaliPiece();
      setNaghaliState(getNaghaliState());
      if (pieceRes.newPiece !== null) {
        setCozySpeech(
          `«۱ قطعه دیگر از تابلوی نقاشی رستم آزاد شد (${toPersianDigits(pieceRes.total)}/۹)!»`
        );
      }
    }

    const newCoins = coins + earned;
    setCoins(newCoins);
    persistState(currentLevel + 1, newCoins, stars + 1);

    // 4. Trigger 20-second Sini-Gardani Bonus every 5 levels
    if ((currentLevel + 1) % 5 === 0) {
      setTimeout(() => setIsSiniGardaniOpen(true), 1200);
    }

    // 5. Progressive Feature Disclosure Toasts & Carpet Unveiling
    const nextLevel = currentLevel + 1;
    if (nextLevel % 5 === 1 && nextLevel > 1) {
      const carpetIndex = Math.floor((nextLevel - 1) / 5) % 8;
      const carpetNames = [
        'قالی لاکی شاه‌عباسی کاشان',
        'قالی فیروزه‌ای ابریشم اصفهان',
        'قالی زرشکی عتیقه تبریز',
        'قالی کرم و عاجی نایین',
        'قالی سبز یشمی کرمان',
        'قالی خشتی گلستان بختیاری',
        'گلیم هندسی قشقایی',
        'قالی لاجوردی هریس',
      ];
      setCozySpeech(`«دست‌مریزاد پهلوون! به مرحله ${toPersianDigits(nextLevel)} رسیدی! ${carpetNames[carpetIndex]} زیر استکان‌ها پهن شد!»`, true);
    } else if (nextLevel === 3) {
      setCozySpeech('«ماشاءالله! به مرحله ۳ رسیدی! دکوراسیون چایخانه و تخته‌نرد برات باز شد!»', true);
    } else if (nextLevel === 5) {
      setCozySpeech('«ایوالله پهلوون! به مرحله ۵ رسیدی! دفتر حساب، رادیو لامپی و حواله سکه باز شد!»', true);
    } else if (nextLevel === 8) {
      setCozySpeech('«دمت گرم سالار! به مرحله ۸ رسیدی! پاتوق‌کشی محله و رویداد نقالی باز شد!»', true);
    }

    // 6. Live HMAC Sync
    syncWithBackend({
      device_id: playerProfile?.deviceId || 'device_guest',
      nickname: playerProfile?.nickname || 'پهلوان چایخانه',
      coins: newCoins,
      current_level: nextLevel,
      weekly_score_delta: earned,
      decorations: ownedDecorations,
    }).catch(() => {});

    setIsVictoryOpen(true);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    soundEngine.playClick();
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    setCups(prev);
    setSelectedCupIdx(null);
    setHint(null);

    if (activeVIPBoss?.id === 'poet_shekasteh') {
      setCozySpeech('«چنان در غم فرو رفتم که رنگ از چای هم بگریخت... (برگشت به عقب)»');
    }
  };

  const handleAddCup = () => {
    if (cups.length >= 8) {
      soundEngine.playGlassClink();
      setCozySpeech('«سینی مسی پر شده پهلوون! حداکثر ۸ استکان جا میشه.»', true);
      return;
    }
    soundEngine.playGlassClink();
    setHistory((prev) => [...prev, cups.map((c) => ({ ...c, layers: [...c.layers] }))]);
    const maxId = cups.reduce((max, c) => Math.max(max, c.id), 0);
    const newCup: Cup = {
      id: maxId + 1,
      layers: [],
      isExtra: true,
    };
    setCups((prev) => [...prev, newCup]);
    setExtraCupUsed(true);
    setCozySpeech('«یه استکان نو گذاشتم تو سینی، حالا دستت برای ریختن چای بازه!»', true);
  };

  const handleHint = () => {
    soundEngine.playClick();

    // 0. Strict 1-Hour Quota Check (Max 3 stages per 1 hour per user)
    const currentQuota = getAiQuotaStatus();
    setAiQuota(currentQuota);

    if (currentQuota.isRestricted) {
      soundEngine.playTrayClatter();
      setIsAiLimitOpen(true);
      setCozySpeech(
        `«سهمیه هوش مصنوعی این ساعت تموم شد! (${formatAiTimeRemaining(
          currentQuota.minutesRemaining,
          currentQuota.secondsRemaining
        )} دیگر شارژ می‌شود). هوش خودت رو نشون بده پهلوون!»`,
        true
      );
      return;
    }

    // Mark current level as assisted by AI
    setIsCurrentLevelAiAssisted(true);

    // 1. First, check if any cup has a sugar cube blocker and melt ALL of them immediately!
    let meltedAny = false;
    const workingCups = cups.map((c) => {
      if (c.hasSugarCubeBlocker) {
        meltedAny = true;
        return { ...c, hasSugarCubeBlocker: false };
      }
      return { ...c };
    });

    if (meltedAny) {
      setCups(workingCups);
      incrementSugarCubesDissolvedCount();
      soundEngine.playSugarMelt();
    }

    // Query prioritized AI models for live commentary
    askUncleBahmanAi(workingCups, currentLevel)
      .then((advice) => {
        if (advice) setCozySpeech(advice);
      })
      .catch(() => {});

    // 2. Discover best move using Solver
    let bestMove: { fromIndex: number; toIndex: number } | null = null;
    const solution = solveWaterSort(workingCups);
    if (solution && solution.length > 0) {
      const candidate = solution[0];
      const srcCup = workingCups[candidate.fromIndex];
      const dstCup = workingCups[candidate.toIndex];
      if (srcCup && dstCup && !srcCup.isFrozenSolid && !dstCup.isFrozenSolid && dstCup.layers.length < 4) {
        bestMove = candidate;
      }
    }

    if (!bestMove) {
      bestMove = findImmediateBestMove(workingCups);
    }

    // 3. Fallback: Check ANY valid move between non-empty source and target
    if (!bestMove) {
      for (let f = 0; f < workingCups.length; f++) {
        const src = workingCups[f];
        if (!src || src.layers.length === 0 || src.isFrozenSolid) continue;
        const validTargets = getValidTargetIndices(f, workingCups);
        if (validTargets.length > 0) {
          bestMove = { fromIndex: f, toIndex: validTargets[0] };
          break;
        }
      }
    }

    // 4. If a valid move is found, visually highlight with badges and execute smoothly
    if (bestMove) {
      const targetMove = bestMove;
      setHint(targetMove);
      setSelectedCupIdx(targetMove.fromIndex);
      setCozySpeech(
        `«راهنما: از استکان شماره ${toPersianDigits(targetMove.fromIndex + 1)} به استکان ${toPersianDigits(targetMove.toIndex + 1)} بریز.»`
      );

      setTimeout(() => {
        executePour(targetMove.fromIndex, targetMove.toIndex, workingCups);
        setTimeout(() => setHint(null), 300);
      }, 500);
      return;
    }

    // 5. If board is truly locked (no legal moves possible):
    if (!extraCupUsed && cups.length < 8 && !isPenaltyLocked) {
      handleAddCup();
      setCozySpeech('«سینی پر شده بود! یک استکان کمکی برات گذاشتم تا دستت باز بشه.»', true);
    } else if (history.length > 0) {
      handleUndo();
      setCozySpeech('«راهی نمونده بود! یک حرکت برگشت زدم تا سینی باز بشه.»', true);
    } else {
      setCozySpeech('«پهلوون، سینی کاملاً قفله! دکمه بازنشانی مرحله رو بزن تا از اول بچینیم.»', true);
    }
  };

  const handleNextLevel = () => {
    setIsVictoryOpen(false);
    if (activeWeeklyStage) {
      const allStages = getWeeklyStagesForCurrentWeek();
      const nextStage = allStages.find((s) => s.id === activeWeeklyStage.id + 1);
      if (nextStage) {
        handleStartWeeklyStage(nextStage);
      } else {
        setActiveWeeklyStage(null);
        setIsWeeklyChallengeOpen(true);
        initLevel(currentLevel);
        setCozySpeech('«ایوالله پهلوون! تمام مراحل چالش دوشنبه رو با سربلندی فتح کردی!»');
      }
      return;
    }

    setCurrentLevel((lvl) => lvl + 1);
    setIsSpecialChallengeAccepted(false);
  };

  // Borrow credit from Uncle Bahman
  const handleBorrowCredit = () => {
    const res = borrowDebt();
    if (res.success) {
      const newCoins = coins + res.coinsGranted;
      setCoins(newCoins);
      setDebtState(res.state);
      persistState(currentLevel, newCoins, stars);
      setCozySpeech('«۳۰۰ سکه نسیه به جیبت واریز شد! ۳ مرحله بدون باخت ببر تا صاف شه!»', true);
    }
  };

  // Repay repossession debt (350 coins)
  const handleRepayDebt = () => {
    if (coins < 350) return;
    const res = repayDebtRepossession();
    if (res.success) {
      const newCoins = coins - 350;
      setCoins(newCoins);
      setDebtState(res.state);
      persistState(currentLevel, newCoins, stars);
      setCozySpeech('«دمت گرم! ۳۵۰ سکه تسویه شد و توقیف وسایل چایخانه برداشته شد!»', true);
    }
  };

  // Fail level penalty trigger
  const handleRestartLevel = () => {
    if (debtState.isDebtActive) {
      const res = failDebtStreak(ownedDecorations);
      setDebtState(res.state);
      setCozySpeech(
        '«مأمور وصول عمو بهمن: ریستارت کردی و شرط ۳ برد باطل شد! یکی از وسایل توقیف شد تا ۳۵۰ سکه تسویه کنی!»',
        true
      );
    }
    initLevel(currentLevel);
  };

  // Buy and equip items
  const handleBuyShopItem = (item: ShopItem) => {
    if (coins < item.price) {
      // Auto prompt debt if coins not enough!
      setCozySpeech('«سکه کم داری پهلوون! می‌تونی از دفتر حساب نسیه بگیری!»');
      setIsDaftarHesabOpen(true);
      return;
    }
    const newCoins = coins - item.price;
    setCoins(newCoins);
    const newUnlocked = [...unlockedShopItems, item.id];
    setUnlockedShopItems(newUnlocked);
    persistState(currentLevel, newCoins, stars);

    if (item.category === 'carpet') setEquippedCarpet(item.id);
    if (item.category === 'samovar') setEquippedSamovar(item.id);
    if (item.category === 'window') setEquippedWindow(item.id);
  };

  const handleEquipShopItem = (item: ShopItem) => {
    if (item.category === 'carpet') setEquippedCarpet(item.id);
    if (item.category === 'samovar') setEquippedSamovar(item.id);
    if (item.category === 'window') setEquippedWindow(item.id);
  };

  // Valid target indices calculation for Smart Auto-Target highlight
  const validTargetIndices = selectedCupIdx !== null ? getValidTargetIndices(selectedCupIdx, cups) : [];

  return (
    <main
      className="relative w-full h-[100dvh] overflow-hidden flex items-center justify-center bg-[#241107]"
      dir="rtl"
    >
      {/* Desktop Atmospheric Teahouse Background Blur */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-45 pointer-events-none filter blur-md scale-105"
        style={{ backgroundImage: `url(${EXACT_TEAHOUSE_BG})` }}
      />
      <div className="absolute inset-0 bg-radial from-transparent via-[#2E1609]/70 to-[#180A04] pointer-events-none" />

      {/* Responsive Game Cabinet Container: Edge-to-edge on mobile, Royal Persian Arcade Frame on Tablet & Laptop */}
      <section
        className="relative w-full max-w-full sm:max-w-[480px] md:max-w-[520px] lg:max-w-[560px] h-[100dvh] h-[100svh] sm:h-[96dvh] sm:my-auto sm:rounded-[36px] sm:border-[4px] sm:border-[#854D27] sm:shadow-[0_25px_80px_rgba(0,0,0,0.9),0_0_0_2px_rgba(245,158,11,0.25)] flex flex-col justify-between overflow-hidden shadow-[0_0_60px_rgba(30,12,4,0.85)] border-x-0 sm:border-x-2 border-[#683C1D]/80 select-none bg-cover bg-center transition-all duration-500"
        style={{ backgroundImage: `url(${EXACT_TEAHOUSE_BG})` }}
      >
        {/* Soft Warm Top & Bottom Ambient Gradients */}
        <div className="absolute top-0 inset-x-0 h-14 bg-gradient-to-b from-[#2E1508]/35 to-transparent pointer-events-none z-10" />
        <div className="absolute bottom-0 inset-x-0 h-12 bg-gradient-to-t from-[#2E1508]/35 to-transparent pointer-events-none z-10" />

        {/* Ambient Effects */}
        <TeahouseAtmosphere />

        {/* Top HUD with Progressive Feature Disclosure & Consolidated Triggers */}
        <HUD
          currentLevel={currentLevel}
          coins={coins}
          levelProgressPercent={levelProgressPercent}
          unlockAll={unlockAll}
          isDebtActive={debtState.isDebtActive}
          debtStreakLeft={Math.max(0, 3 - debtState.debtStreak)}
          playerProfile={playerProfile}
          onOpenMenu={() => setIsMainMenuOpen(true)}
          onOpenGuide={() => setIsGameGuideOpen(true)}
          onOpenSettings={() => setIsRegisterOpen(true)}
          onOpenRegister={() => setIsRegisterOpen(true)}
          onOpenNeighborhood={() => setIsNeighborhoodOpen(true)}
          onOpenCounterDrawer={() => setIsCounterDrawerOpen(true)}
          onOpenHavaleh={() => setIsHavalehOpen(true)}
          onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
          onToggleUnlockAll={() => {
            soundEngine.playClick();
            setUnlockAll((prev) => {
              const next = !prev;
              try {
                localStorage.setItem('bahman_unlock_all', String(next));
              } catch {}
              setCozySpeech(
                next
                  ? '«حالت توسعه فعال شد: همه امکانات و بخش‌ها باز شدند!»'
                  : '«حالت عادی: امکانات طبق مرحله باز می‌شوند.»'
              );
              return next;
            });
          }}
          hasDailyRewardAvailable={dailyRewardStatus.canClaim}
          hasUnclaimedWeekly={weeklyCompletedIds.length < 5}
        />

        {/* Non-intrusive Floating Stuck Warning Pill (Only shows when player is stuck) */}
        {isStuckAlert && (
          <div className="absolute top-24 inset-x-0 z-40 flex justify-center px-4 pointer-events-none animate-bounce">
            <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-red-950/95 via-amber-950/95 to-red-950/95 border-2 border-yellow-400 text-yellow-200 text-xs font-vazir shadow-2xl backdrop-blur-sm">
              <span className="text-sm">⚠️</span>
              <span className="font-semibold">{speechText || 'راه حرکتی نیست! از برگشت یا راهنما استفاده کن.'}</span>
            </div>
          </div>
        )}

        {/* Active Weekly Monday Challenge Banner */}
        {activeWeeklyStage && (
          <div className="z-20 px-2 py-0.5 animate-fade-in">
            <div className="flex items-center justify-between p-2 rounded-2xl bg-gradient-to-r from-amber-950/95 via-[#351909] to-amber-950/95 border-2 border-yellow-400 shadow-xl text-amber-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-amber-950 font-lalezar text-xs flex items-center justify-center font-bold shadow">
                  {toPersianDigits(activeWeeklyStage.id)}
                </div>
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-lalezar text-xs text-yellow-300">
                      چالش دوشنبه: {activeWeeklyStage.title}
                    </span>
                    {activeWeeklyStage.modifierLabel && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-900/80 text-amber-200 border border-amber-600/60 font-vazir">
                        {activeWeeklyStage.modifierLabel}
                      </span>
                    )}
                  </div>
                  <span className="text-[9px] text-amber-200/80 font-vazir block">
                    پاداش: +{formatPersianCoins(activeWeeklyStage.rewardCoins)} سکه ★ و +
                    {toPersianDigits(activeWeeklyStage.rewardWeeklyScore)} امتیاز لیگ
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  soundEngine.playClick();
                  setActiveWeeklyStage(null);
                  initLevel(currentLevel);
                }}
                className="px-2 py-1 rounded-xl bg-[#200D04] hover:bg-[#381708] border border-amber-600/70 text-amber-300 text-[10px] font-lalezar transition-all active:scale-95 cursor-pointer"
                title="بازگشت به مراحل اصلی چایخانه"
              >
                انصراف
              </button>
            </div>
          </div>
        )}

        {/* Empty Spacing Buffer below HUD: Guarantees Samovar, Teapot & Teahouse Scene are 100% visible on all levels */}
        <div className="w-full min-h-[95px] xs:min-h-[105px] sm:min-h-[120px] shrink-0 flex flex-col justify-center px-2 z-20 pointer-events-none">
          {!activeWeeklyStage && isRushMode && (
            <div className="pointer-events-auto">
              <RushOrderBanner
                timeLeft={rushTimeLeft}
                targets={rushTargets}
                isCompleted={isRushWon}
              />
            </div>
          )}

          {!activeWeeklyStage && activeVIPBoss && !isRushMode && (
            <div className="pointer-events-auto">
              <VIPBossBanner
                boss={activeVIPBoss}
                timeLeft={vipBossTimeLeft}
                movesLeft={vipBossMovesLeft}
              />
            </div>
          )}
        </div>

        {/* Center Gameplay Area with Eye-Comfort Palette & Diegetic Teahouse Scene */}
        <div className="relative flex-1 flex flex-col justify-end items-center px-1 pb-1 z-20 overflow-hidden">
          <OnboardingPointer isVisible={onboardingActive && currentLevel === 1 && !activeWeeklyStage} />

          <PersianTeahouseScene
            isNightMode={isNightMode}
            currentLevel={currentLevel}
            unlockAll={unlockAll}
            onOpenRenovations={() => setIsRenovationsOpen(true)}
            onOpenRadio={() => setIsRadioOpen(true)}
            onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
            onOpenPatogh={() => setIsPatoghOpen(true)}
          >
            {cups.map((cup, idx) => {
              const isSelected = selectedCupIdx === idx;
              const isValidTarget = validTargetIndices.includes(idx);
              const isInvalidDimmed = selectedCupIdx !== null && !isValidTarget && !isSelected;

              return (
                <Estekan
                  key={cup.id}
                  cup={cup}
                  cupIndex={idx}
                  isSelected={isSelected}
                  isValidTarget={isValidTarget}
                  isInvalidDimmed={isInvalidDimmed}
                  isHintSource={hint?.fromIndex === idx}
                  isHintTarget={hint?.toIndex === idx}
                  isPouring={pouringCupIdx === idx}
                  isReceiving={pourTargetIdx === idx}
                  pourDirection={pourDirection}
                  colorblindMode={colorblindMode}
                  hasGoldenSugarCube={idx === 0 && currentLevel % 2 === 1 && !activeWeeklyStage}
                  onCupClick={handleCupClick}
                  onCupDoubleTap={handleDoubleTapCup}
                />
              );
            })}
          </PersianTeahouseScene>
        </div>

        {/* Bottom Ergonomic Action Bar (Thumb-Zone strictly in bottom 25%) */}
        <ActionBar
          canUndo={history.length > 0}
          undoCount={history.length}
          canAddExtraCup={cups.length < 8}
          isPenaltyLocked={isPenaltyLocked}
          onUndo={handleUndo}
          onAddCup={handleAddCup}
          onHint={handleHint}
          onOpenFortune={() => setIsFortuneOpen(true)}
          aiStagesRemaining={aiQuota.stagesRemaining}
          isAiRestricted={aiQuota.isRestricted}
        />
      </section>

      {/* Lazy-Loaded Modals Suspense Boundary */}
      <React.Suspense fallback={null}>
        {/* Uncle Bahman AI Brain 1-Hour Quota Limit Modal */}
        <AiLimitModal
          isOpen={isAiLimitOpen}
          onClose={() => setIsAiLimitOpen(false)}
          currentLevel={currentLevel}
        />

        {/* Diegetic Drawer: میز دخل عمو بهمن */}
        <DakhleBahmanDrawer
        isOpen={isCounterDrawerOpen}
        onClose={() => setIsCounterDrawerOpen(false)}
        currentLevel={currentLevel}
        unlockAll={unlockAll}
        onOpenRenovations={() => setIsRenovationsOpen(true)}
        onOpenRadio={() => setIsRadioOpen(true)}
        onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
        onOpenTakhtehNard={() => setIsTakhtehNardOpen(true)}
        onOpenPatogh={() => setIsPatoghOpen(true)}
        onOpenPahlavaniCard={() => setIsPahlavaniCardOpen(true)}
        onOpenHavaleh={() => setIsHavalehOpen(true)}
        onOpenNightMystery={() => setIsNightMysteryOpen(true)}
        onOpenNeighborhood={() => setIsNeighborhoodOpen(true)}
        onOpenSettings={() => setIsRegisterOpen(true)}
        isNightMode={isNightMode}
        hasDailyTipAvailable={getDailyTipStatus().canClaim}
        hasDiceRollAvailable={canRollDiceToday()}
        isDebtActive={debtState.isDebtActive}
      />

      {/* Peer-to-Peer Coin Sharing / Havaleh Modal */}
      <HavalehModal
        isOpen={isHavalehOpen}
        onClose={() => setIsHavalehOpen(false)}
        currentLevel={currentLevel}
        coins={coins}
        onCoinsChange={(newCoins) => {
          setCoins(newCoins);
          persistState(currentLevel, newCoins, stars);
        }}
        senderId={playerProfile.deviceId}
        unlockAll={unlockAll}
        onGenerosityAward={(msg) => setCozySpeech(msg, true)}
      />

      {/* Interactive Cultural Modals */}
      <RadioModal
        isOpen={isRadioOpen}
        onClose={() => setIsRadioOpen(false)}
        activeTrack={activeRadioTrack}
        volume={volume}
        onTrackChange={(track) => {
          setActiveRadioTrack(track);
          soundEngine.playRadioTrack(track);
        }}
        onVolumeChange={(vol) => setVolume(vol)}
      />

      <SpecialGuestModal
        isOpen={isSpecialGuestOpen}
        onClose={() => setIsSpecialGuestOpen(false)}
        isAccepted={isSpecialChallengeAccepted}
        onAcceptChallenge={() => {
          setIsSpecialChallengeAccepted(true);
          setIsSpecialGuestOpen(false);
          setCozySpeech('«پهلوان غفور مهمون ماست، چالش ۲ برابر سکه فعال شد!»');
        }}
      />

      <FortuneModal
        isOpen={isFortuneOpen}
        onClose={() => setIsFortuneOpen(false)}
        onRewardCoins={(reward) => {
          setCoins((prev) => {
            const next = prev + reward;
            persistState(currentLevel, next, stars);
            return next;
          });
        }}
      />

      <DecorationShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        coins={coins}
        unlockedItems={unlockedShopItems}
        equippedCarpet={equippedCarpet}
        equippedSamovar={equippedSamovar}
        equippedWindow={equippedWindow}
        sugarCubesCollected={sugarCubes}
        onBuyItem={handleBuyShopItem}
        onEquipItem={handleEquipShopItem}
      />

      <NeighborhoodModal
        isOpen={isNeighborhoodOpen}
        onClose={() => setIsNeighborhoodOpen(false)}
        playerLevel={currentLevel}
        playerScore={coins + stars * 50}
        onOpenRegister={() => setIsRegisterOpen(true)}
        playerProfile={playerProfile}
        onOpenWeeklyChallenge={() => {
          setIsNeighborhoodOpen(false);
          setIsWeeklyChallengeOpen(true);
        }}
      />

      <WeeklyChallengeModal
        isOpen={isWeeklyChallengeOpen}
        onClose={() => setIsWeeklyChallengeOpen(false)}
        onStartStage={(stage) => handleStartWeeklyStage(stage)}
        onOpenLeaderboard={() => {
          setIsWeeklyChallengeOpen(false);
          setIsNeighborhoodOpen(true);
        }}
        onRewardsClaimed={(bonus) => {
          setCoins((prev) => {
            const next = prev + bonus;
            persistState(currentLevel, next, stars);
            return next;
          });
          setWeeklyCompletedIds(getWeeklyChallengeState().completedStageIds);
        }}
      />

      <DailyRewardModal
        isOpen={isDailyRewardOpen}
        onClose={() => setIsDailyRewardOpen(false)}
        onClaim={handleClaimDailyReward}
        currentStreak={dailyRewardStatus.streak}
        todayRewardAmount={dailyRewardStatus.todayRewardAmount}
        isClaimedToday={dailyRewardStatus.isClaimedToday}
      />

      <DaftarHesabModal
        isOpen={isDaftarHesabOpen}
        onClose={() => setIsDaftarHesabOpen(false)}
        debtState={debtState}
        coins={coins}
        onBorrow={handleBorrowCredit}
        onRepay={handleRepayDebt}
      />

      <TakhtehNardModal
        isOpen={isTakhtehNardOpen}
        onClose={() => setIsTakhtehNardOpen(false)}
        onAwardCoins={(earned: number) => {
          setCoins((prev) => {
            const next = prev + earned;
            persistState(currentLevel, next, stars);
            return next;
          });
        }}
      />

      <DecorationRenovationModal
        isOpen={isRenovationsOpen}
        onClose={() => setIsRenovationsOpen(false)}
        coins={coins}
        ownedIds={ownedDecorations}
        equippedSamovar={equippedSamovar}
        equippedCarpet={equippedCarpet}
        onBuyItem={(item) => {
          if (coins < item.price) return;
          const nextCoins = coins - item.price;
          setCoins(nextCoins);
          const nextOwned = [...ownedDecorations, item.id];
          setOwnedDecorations(nextOwned);
          saveOwnedDecorations(nextOwned);
          persistState(currentLevel, nextCoins, stars);
        }}
        onEquipItem={(item) => {
          if (item.category === 'samovar') setEquippedSamovar(item.id);
          else if (item.category === 'carpet') setEquippedCarpet(item.id);
        }}
        onCoinsAwarded={(amount: number) => {
          setCoins((prev) => {
            const next = prev + amount;
            persistState(currentLevel, next, stars);
            return next;
          });
          setCozySpeech(`«انعام روزانه دخل (${toPersianDigits(amount)} سکه) نوش جونت پهلوون!»`);
        }}
      />

      <PatoghModal
        isOpen={isPatoghOpen}
        onClose={() => setIsPatoghOpen(false)}
        deviceId={playerProfile.deviceId}
        playerName={playerProfile.nickname || 'پهلوان چایخانه'}
      />

      <PahlavaniCardModal
        isOpen={isPahlavaniCardOpen}
        onClose={() => setIsPahlavaniCardOpen(false)}
        nickname={playerProfile.nickname || 'پهلوان چایخانه'}
        level={currentLevel}
        coins={coins}
        ownedDecorations={ownedDecorations}
        onRewardCoins={(amt: number) => {
          setCoins((prev) => {
            const next = prev + amt;
            persistState(currentLevel, next, stars);
            return next;
          });
        }}
        onOpenAchievements={() => setIsAchievementsOpen(true)}
      />

      <NaghaliModal
        isOpen={isNaghaliOpen}
        onClose={() => setIsNaghaliOpen(false)}
        naghaliState={naghaliState}
        onToggleActive={() => {
          const nextState = { ...naghaliState, isActive: !naghaliState.isActive };
          setNaghaliState(nextState);
          saveNaghaliState(nextState);
        }}
        onClaimPrize={() => {
          setCoins((prev) => {
            const next = prev + 500;
            persistState(currentLevel, next, stars);
            return next;
          });
          const nextState = { ...naghaliState, hasClaimedReward: true };
          setNaghaliState(nextState);
          saveNaghaliState(nextState);
          setCozySpeech('«تبریک پهلوون! جایزه بزرگ رویداد نقالی (۵۰۰ سکه طلا) تقدیم شما!»');
        }}
      />

      <SiniGardaniModal
        isOpen={isSiniGardaniOpen}
        onClose={() => setIsSiniGardaniOpen(false)}
        onFinish={(bonus: number) => {
          setCoins((prev) => {
            const next = prev + bonus;
            persistState(currentLevel, next, stars);
            return next;
          });
          setCozySpeech(`«دستخوش! سینی‌گردانی عالی بود، +${toPersianDigits(bonus)} سکه انعام گرفتی!»`);
        }}
      />

      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />

      <MainMenuModal
        isOpen={isMainMenuOpen}
        onClose={() => setIsMainMenuOpen(false)}
        playerProfile={playerProfile}
        currentLevel={currentLevel}
        coins={coins}
        soundEnabled={soundEnabled}
        colorblindMode={colorblindMode}
        weeklyStagesCompleted={weeklyCompletedIds.length}
        hasDailyRewardAvailable={dailyRewardStatus.canClaim}
        hasDiceRollAvailable={canRollDiceToday()}
        hasDailyTipAvailable={getDailyTipStatus().canClaim}
        isDebtActive={debtState.isDebtActive}
        onOpenRegister={() => setIsRegisterOpen(true)}
        onOpenShop={() => setIsShopOpen(true)}
        onOpenNeighborhood={() => setIsNeighborhoodOpen(true)}
        onOpenSpecialGuest={() => setIsSpecialGuestOpen(true)}
        onOpenWeeklyChallenge={() => setIsWeeklyChallengeOpen(true)}
        onOpenDailyReward={() => setIsDailyRewardOpen(true)}
        onOpenRadio={() => setIsRadioOpen(true)}
        onOpenGuide={() => setIsGameGuideOpen(true)}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenDaftarHesab={() => setIsDaftarHesabOpen(true)}
        onOpenNaghali={() => setIsNaghaliOpen(true)}
        onOpenRenovations={() => setIsRenovationsOpen(true)}
        onOpenPatogh={() => setIsPatoghOpen(true)}
        onOpenSiniGardani={() => setIsSiniGardaniOpen(true)}
        onOpenTakhtehNard={() => setIsTakhtehNardOpen(true)}
        onOpenPahlavaniCard={() => setIsPahlavaniCardOpen(true)}
        onOpenNightMystery={() => setIsNightMysteryOpen(true)}
        onOpenAchievements={() => setIsAchievementsOpen(true)}
        onOpenAiLimit={() => setIsAiLimitOpen(true)}
        onOpenInstall={() => setIsInstallOpen(true)}
        hasUpdateAvailable={
          Boolean(
            (serverConfig && serverConfig.current_version !== APP_VERSION) ||
              appUpdateInfo?.hasUpdate
          )
        }
        onCheckUpdate={async () => {
          if (serverConfig && serverConfig.current_version !== APP_VERSION) {
            setIsAutoUpdateOpen(true);
            return;
          }
          const cfg = await fetchServerConfig();
          if (cfg) {
            setServerConfig(cfg);
            if (cfg.current_version !== APP_VERSION) {
              setIsAutoUpdateOpen(true);
              return;
            }
          }
          // If already on latest version, notify user happily
          setCozySpeech(
            `شما در حال حاضر از آخرین نسخه (${toPersianDigits(APP_VERSION)}) چایخانه عمو بهمن استفاده می‌کنید! دمت گرم.`,
            false
          );
          setIsAppUpdateOpen(true);
        }}
        onToggleSound={() => {
          soundEngine.playClick();
          setSoundEnabled((prev) => !prev);
        }}
        isNightMode={isNightMode}
        onToggleNightMode={() => {
          soundEngine.playClick();
          setIsNightMode((prev) => {
            const next = !prev;
            try {
              localStorage.setItem('bahman_night_mode', String(next));
            } catch {}
            return next;
          });
        }}
        onToggleColorblind={() => {
          soundEngine.playClick();
          setColorblindMode((prev) => !prev);
        }}
      />

      {/* Direct Self-Updater & Live Server Config Modal */}
      <AutoUpdateModal
        isOpen={isAutoUpdateOpen}
        onClose={() => setIsAutoUpdateOpen(false)}
        config={
          serverConfig || {
            current_version: '1.1.0',
            direct_apk_url: 'https://ghurfe.ir/api/bahman-latest.apk',
            changelog:
              '• ارتقای کامل سرعت بازی و رفع هرگونه لگ در موبایل\n• اضافه شدن مراحل جذاب و چالش‌های هفتگی جدید\n• هماهنگی با لیگ محله و سینی گردانی',
            force_update: false,
          }
        }
      />

      {/* Direct In-App APK & OTA Update Modal */}
      <AppUpdateModal
        isOpen={isAppUpdateOpen}
        onClose={() => setIsAppUpdateOpen(false)}
        updateInfo={appUpdateInfo}
        onCheckAgain={async () => {
          const info = await checkForAppUpdate();
          setAppUpdateInfo(info);
        }}
      />

      {/* Live Server Broadcast & Push Notification without App Update */}
      <LiveBroadcastModal
        isOpen={isLiveBroadcastOpen}
        onClose={() => {
          if (liveBroadcast?.id) {
            markBroadcastAsSeen(liveBroadcast.id);
          }
          setIsLiveBroadcastOpen(false);
        }}
        broadcast={liveBroadcast}
        onClaimReward={(reward) => {
          setCoins((prev) => {
            const next = prev + reward;
            persistState(currentLevel, next, stars);
            return next;
          });
          setCozySpeech(`«دستخوش باصفا! +${toPersianDigits(reward)} سکه طلا هدیه برات واریز شد.»`, true);
        }}
      />

      {/* Night Mystery Safe & Detective Case Modal */}
      <NightMysteryModal
        isOpen={isNightMysteryOpen}
        onClose={() => setIsNightMysteryOpen(false)}
        onRewardCoins={(reward) => {
          setCoins((prev) => {
            const next = prev + reward;
            persistState(currentLevel, next, stars);
            return next;
          });
          setCozySpeech(`«دستخوش کارآگاه زبردست! معما حل شد و +${toPersianDigits(reward)} سکه طلا گرفتی.»`);
        }}
      />

      <RegisterPlayerModal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        currentProfile={playerProfile}
        onProfileUpdated={(updated) => setPlayerProfile(updated)}
        soundEnabled={soundEnabled}
        onToggleSound={() => {
          soundEngine.playClick();
          setSoundEnabled((prev) => !prev);
        }}
        isNightMode={isNightMode}
        onToggleNightMode={() => {
          soundEngine.playClick();
          setIsNightMode((prev) => {
            const next = !prev;
            try {
              localStorage.setItem('bahman_night_mode', String(next));
            } catch {}
            return next;
          });
        }}
        colorblindMode={colorblindMode}
        onToggleColorblind={() => {
          soundEngine.playClick();
          setColorblindMode((prev) => !prev);
        }}
        onOpenAchievements={() => {
          setIsRegisterOpen(false);
          setIsAchievementsOpen(true);
        }}
        onOpenNeighborhood={() => {
          setIsRegisterOpen(false);
          setIsNeighborhoodOpen(true);
        }}
      />

      <GameGuideModal
        isOpen={isGameGuideOpen}
        onClose={() => setIsGameGuideOpen(false)}
      />

      <VictoryModal
        isOpen={isVictoryOpen}
        level={currentLevel}
        earnedCoins={
          activeWeeklyStage
            ? weeklyEarnedCoins
            : isSpecialChallengeAccepted
            ? 120
            : 60
        }
        movesCount={movesCount}
        isRushOrderWon={isRushWon}
        onNextLevel={handleNextLevel}
        isWeeklyMode={!!activeWeeklyStage}
        weeklyStageTitle={activeWeeklyStage?.title}
        weeklyPointsEarned={weeklyPointsWon}
        specialItemReward={activeWeeklyStage?.specialItemReward}
        onViewLeaderboard={() => {
          setIsVictoryOpen(false);
          setIsNeighborhoodOpen(true);
        }}
      />

      {/* PWA Install Estekan Modal with User's Uploaded Icon */}
      <InstallEstekanModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
      />
      </React.Suspense>
    </main>
  );
}
