import { RadioTrackId } from '../types';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private activeMusicNodes: { stop: () => void } | null = null;
  private isMuted: boolean = false;
  private volume: number = 0.8;
  private currentTrack: RadioTrackId = 'tar_sonati';
  private cachedNoiseBuffer: AudioBuffer | null = null;

  private initCtx() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
      
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(0.5, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      this.sfxGain.connect(this.masterGain);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private getNoiseBuffer(): AudioBuffer | null {
    if (!this.ctx) return null;
    if (!this.cachedNoiseBuffer) {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.5);
      this.cachedNoiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = this.cachedNoiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
    }
    return this.cachedNoiseBuffer;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  public vibrate(pattern: number | number[] = 25) {
    try {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      // Ignore vibration errors if not supported or disabled
    }
  }

  /**
   * Procedural glass clink (<0.3s) for tapping an Iranian estekan
   */
  public playGlassClink() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // High crystalline glass resonance ~ 2100Hz and harmonic at 3520Hz
    osc.type = 'sine';
    osc.frequency.setValueAtTime(2150, t);
    osc.frequency.exponentialRampToValueAtTime(2080, t + 0.22);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(3640, t);
    osc2.frequency.exponentialRampToValueAtTime(3500, t + 0.15);

    gain.gain.setValueAtTime(0.4, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc2.start(t);
    osc.stop(t + 0.25);
    osc2.stop(t + 0.25);

    this.vibrate(15);
  }

  /**
   * Procedural dynamic pitch-rising liquid pouring sound
   */
  public playPouring(layerIndex: number = 0) {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const baseFreq = 400 + layerIndex * 110; // Pitch rises as cup fills up!

    // Liquid bubbling modulator
    const modOsc = this.ctx.createOscillator();
    const modGain = this.ctx.createGain();
    modOsc.type = 'sine';
    modOsc.frequency.setValueAtTime(14, t);
    modOsc.frequency.linearRampToValueAtTime(26, t + 0.45);
    modGain.gain.setValueAtTime(80, t);

    // Main water/tea stream resonance
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq + 180, t + 0.45);
    modGain.connect(osc.frequency);

    // Filtered noise for tea droplet splash (using cached buffer)
    const noiseBuffer = this.getNoiseBuffer();
    const noise = this.ctx.createBufferSource();
    if (noiseBuffer) {
      noise.buffer = noiseBuffer;
    }

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(baseFreq * 1.5, t);
    filter.Q.setValueAtTime(4, t);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.35, t + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

    osc.connect(gain);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);

    modOsc.start(t);
    osc.start(t);
    noise.start(t);

    modOsc.stop(t + 0.45);
    osc.stop(t + 0.45);
    noise.stop(t + 0.45);

    this.vibrate([10, 30, 15]);
  }

  /**
   * Santur-like Persian celebratory chord on puzzle victory (Dastgah Shur / Mahur arpeggio)
   */
  public playSanturVictory() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    // Notes: D4 (293.66), F#4 (369.99), A4 (440), B4 (493.88), D5 (587.33), F#5 (739.99)
    const notes = [293.66, 369.99, 440.0, 493.88, 587.33, 739.99];

    notes.forEach((freq, idx) => {
      const strikeTime = t + idx * 0.08;
      
      // Santur mezrab double-strike characteristic
      [0, 0.02].forEach((delayOffset) => {
        if (!this.ctx || !this.sfxGain) return;
        const noteTime = strikeTime + delayOffset;

        const osc = this.ctx.createOscillator();
        const harmonic = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteTime);

        harmonic.type = 'sine';
        harmonic.frequency.setValueAtTime(freq * 2.01, noteTime); // slight detune for bright metallic string resonance

        noteGain.gain.setValueAtTime(0.28 / (idx * 0.2 + 1), noteTime);
        noteGain.gain.exponentialRampToValueAtTime(0.001, noteTime + 1.2);

        osc.connect(noteGain);
        harmonic.connect(noteGain);
        noteGain.connect(this.sfxGain);

        osc.start(noteTime);
        harmonic.start(noteTime);
        osc.stop(noteTime + 1.25);
        harmonic.stop(noteTime + 1.25);
      });
    });

    this.vibrate([40, 60, 40, 80, 50, 120]);
  }

  /**
   * Traditional Persian gold coin chime
   */
  public playCoin() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(987.77, t); // B5
    osc1.frequency.setValueAtTime(1318.51, t + 0.07); // E6

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1975.53, t + 0.07);

    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + 0.35);
    osc2.stop(t + 0.35);
  }

  public playCoins() {
    this.playCoin();
  }

  /**
   * Sound effect when a cup is completely sorted: hot samovar steam hiss + harmonic crystal bell chime
   */
  public playCupServedSteam() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;

    // 1. Aromatic Samovar Steam Hiss (Filtered noise)
    try {
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.45);
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1200, t);
      filter.frequency.exponentialRampToValueAtTime(600, t + 0.4);
      filter.Q.setValueAtTime(1.5, t);

      const steamGain = this.ctx.createGain();
      steamGain.gain.setValueAtTime(0.01, t);
      steamGain.gain.linearRampToValueAtTime(0.18, t + 0.08);
      steamGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

      whiteNoise.connect(filter);
      filter.connect(steamGain);
      steamGain.connect(this.sfxGain);

      whiteNoise.start(t);
      whiteNoise.stop(t + 0.45);
    } catch {
      // Ignored
    }

    // 2. Clear crystal harmonic chime (celebratory pitch sequence)
    const bellPitches = [1046.5, 1318.5, 1567.98, 2093.0]; // C6, E6, G6, C7
    bellPitches.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const bellGain = this.ctx.createGain();
      const startTime = t + idx * 0.06;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, startTime);

      bellGain.gain.setValueAtTime(0.18, startTime);
      bellGain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.45);

      osc.connect(bellGain);
      bellGain.connect(this.sfxGain);

      osc.start(startTime);
      osc.stop(startTime + 0.45);
    });

    this.vibrate([35, 50, 40]);
  }

  /**
   * UI Click / Wooden pop
   */
  public playClick() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.06);

    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + 0.06);

    this.vibrate(10);
  }

  /**
   * Procedural Radio Gramophone Ambient Tracks (100% Web Audio, Zero External MP3s)
   */
  public playRadioTrack(trackId: RadioTrackId) {
    this.stopRadio();
    this.currentTrack = trackId;

    if (trackId === 'silence' || this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.musicGain) return;

    let isRunning = true;
    const timers: number[] = [];

    if (trackId === 'homayoun') {
      // -------------------------------------------------------------
      // Dastgah Homayoun (دستگاه همایون - گوشه بیداد و شوشتری)
      // Royal, mystical, dignified with the signature augmented second (Eb -> F#)
      // Notes: D3 (146.83), Eb3 (155.56), F#3 (185.0), G3 (196.0), A3 (220.0), Bb3 (233.08), D4 (293.66), Eb4 (311.13), F#4 (369.99)
      // -------------------------------------------------------------
      const homayounPhrases = [
        [146.83, 155.56, 185.0, 196.0, 185.0, 155.56, 146.83], // Foroud
        [185.0, 196.0, 220.0, 233.08, 220.0, 196.0, 185.0],    // Bidad
        [220.0, 233.08, 293.66, 311.13, 293.66, 233.08, 220.0], // Ouj
        [185.0, 196.0, 185.0, 155.56, 146.83, 110.0, 146.83],  // Return to base
      ];

      let phraseIdx = 0;
      let noteIdx = 0;

      // Deep gentle mystic drone (سیم واخوان بم تار و تنبور)
      const droneOsc = this.ctx.createOscillator();
      const droneGain = this.ctx.createGain();
      droneOsc.type = 'triangle';
      droneOsc.frequency.setValueAtTime(146.83, this.ctx.currentTime); // D3
      droneGain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      droneOsc.connect(droneGain);
      droneGain.connect(this.musicGain);
      droneOsc.start();

      const playHomayounNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const currentPhrase = homayounPhrases[phraseIdx % homayounPhrases.length];
        const freq = currentPhrase[noteIdx % currentPhrase.length];

        // Kamancheh / Setar bowed & plucked dual resonance
        const osc = this.ctx.createOscillator();
        const oscHarmonic = this.ctx.createOscillator();
        const vibrato = this.ctx.createOscillator();
        const vibratoGain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        // Persian micro-vibrato (تحریر کمانچه)
        vibrato.frequency.setValueAtTime(5.2, now);
        vibratoGain.gain.setValueAtTime(2.8, now);
        vibrato.connect(vibratoGain);
        vibratoGain.connect(osc.frequency);

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscHarmonic.type = 'sine';
        oscHarmonic.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1200, now);
        filter.frequency.exponentialRampToValueAtTime(550, now + 0.85);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.95);

        osc.connect(filter);
        oscHarmonic.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        vibrato.start(now);
        osc.start(now);
        oscHarmonic.start(now);

        vibrato.stop(now + 1.0);
        osc.stop(now + 1.0);
        oscHarmonic.stop(now + 1.0);

        noteIdx++;
        if (noteIdx >= currentPhrase.length) {
          noteIdx = 0;
          phraseIdx++;
        }

        const delay = noteIdx === 0 ? 900 : 450 + (noteIdx % 3) * 60;
        const timer = window.setTimeout(playHomayounNote, delay);
        timers.push(timer);
      };

      playHomayounNote();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            droneOsc.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'dashti') {
      // -------------------------------------------------------------
      // Avaz Dashti (آواز دشتی - نوای سوزناک نی هفت‌بند و سه‌تار دشتستان)
      // Bittersweet, pastoral, deeply nostalgic and soulful
      // Scale: G3 (196.0), A-koron (213.5), Bb3 (233.08), C4 (261.63), D4 (293.66), Eb4 (311.13)
      // -------------------------------------------------------------
      const dashtiMelody = [
        196.0, 213.5, 233.08, 261.63, 293.66, // Daramad Dashti
        293.66, 311.13, 293.66, 261.63, 233.08, 213.5, // Ouj & Suz
        233.08, 261.63, 233.08, 213.5, 196.0, 164.81, 196.0, // Foroud be G
      ];

      let step = 0;

      // Soft Ney breath ambient wind simulation
      const noiseBuffer = this.ctx.createBuffer(1, this.ctx.sampleRate * 2, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < noiseBuffer.length; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.04;
      }
      const breathNoise = this.ctx.createBufferSource();
      breathNoise.buffer = noiseBuffer;
      breathNoise.loop = true;

      const breathFilter = this.ctx.createBiquadFilter();
      breathFilter.type = 'bandpass';
      breathFilter.frequency.setValueAtTime(650, this.ctx.currentTime);
      breathFilter.Q.setValueAtTime(3.0, this.ctx.currentTime);

      const breathGain = this.ctx.createGain();
      breathGain.gain.setValueAtTime(0.04, this.ctx.currentTime);

      breathNoise.connect(breathFilter);
      breathFilter.connect(breathGain);
      breathGain.connect(this.musicGain);
      breathNoise.start();

      const playNeyNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = dashtiMelody[step % dashtiMelody.length];

        // Ney tone: Warm fundamental + gentle second harmonic with breath vibrato
        const neyOsc = this.ctx.createOscillator();
        const neyHarmonic = this.ctx.createOscillator();
        const neyVibrato = this.ctx.createOscillator();
        const neyVibGain = this.ctx.createGain();
        const neyFilter = this.ctx.createBiquadFilter();
        const neyGain = this.ctx.createGain();

        // Soulful pitch modulation (4.3 Hz vibrato)
        neyVibrato.frequency.setValueAtTime(4.3, now);
        neyVibGain.gain.setValueAtTime(2.2, now);
        neyVibrato.connect(neyVibGain);
        neyVibGain.connect(neyOsc.frequency);

        neyOsc.type = 'sine';
        neyOsc.frequency.setValueAtTime(freq, now);

        neyHarmonic.type = 'triangle';
        neyHarmonic.frequency.setValueAtTime(freq * 2, now);

        neyFilter.type = 'lowpass';
        neyFilter.frequency.setValueAtTime(950, now);
        neyFilter.frequency.exponentialRampToValueAtTime(600, now + 1.2);

        // Soft breath attack and gentle decay
        neyGain.gain.setValueAtTime(0.005, now);
        neyGain.gain.linearRampToValueAtTime(0.14, now + 0.25);
        neyGain.gain.exponentialRampToValueAtTime(0.001, now + 1.3);

        neyOsc.connect(neyFilter);
        neyHarmonic.connect(neyFilter);
        neyFilter.connect(neyGain);
        neyGain.connect(this.musicGain);

        neyVibrato.start(now);
        neyOsc.start(now);
        neyHarmonic.start(now);

        neyVibrato.stop(now + 1.35);
        neyOsc.stop(now + 1.35);
        neyHarmonic.stop(now + 1.35);

        step++;
        const nextTime = step % 4 === 0 ? 1200 : 650 + (step % 2) * 80;
        const timer = window.setTimeout(playNeyNote, nextTime);
        timers.push(timer);
      };

      playNeyNote();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            breathNoise.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'tar_sonati') {
      // Modal Tar arpeggios in Chahargah / Isfahan mode
      // Frequencies: D3 (146.83), F3 (174.61), G3 (196.00), A3 (220.00), Bb3 (233.08), C#4 (277.18), D4 (293.66)
      const scale = [146.83, 174.61, 196.0, 220.0, 233.08, 277.18, 293.66, 349.23, 392.0];
      let step = 0;

      const playTarNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const noteIdx = (step * 3 + (step % 4)) % scale.length;
        const freq = scale[noteIdx];

        // Tar resonance: saw tooth with lowpass filter + mezrab bite
        const osc = this.ctx.createOscillator();
        const oscSymp = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const noteGain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscSymp.type = 'triangle';
        oscSymp.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1400, now);
        filter.frequency.exponentialRampToValueAtTime(450, now + 0.6);

        noteGain.gain.setValueAtTime(0.12, now);
        noteGain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

        osc.connect(filter);
        oscSymp.connect(filter);
        filter.connect(noteGain);
        noteGain.connect(this.musicGain);

        osc.start(now);
        oscSymp.start(now);
        osc.stop(now + 0.75);
        oscSymp.stop(now + 0.75);

        step++;
        const nextTime = 420 + Math.sin(step) * 60;
        const timer = window.setTimeout(playTarNote, nextTime);
        timers.push(timer);
      };

      playTarNote();
    } else if (trackId === 'tehran_ghadim') {
      // Warm vinyl crackle + soothing retro slow jazz chords
      const chordNotes = [
        [220, 261.63, 329.63, 392], // Am7
        [196, 246.94, 293.66, 349.23], // G7
        [174.61, 220, 261.63, 329.63], // Fmaj7
        [164.81, 207.65, 246.94, 293.66], // E7
      ];
      let chordIndex = 0;

      const playChord = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const currentChord = chordNotes[chordIndex % chordNotes.length];

        currentChord.forEach((f) => {
          if (!this.ctx || !this.musicGain) return;
          const osc = this.ctx.createOscillator();
          const g = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(f, now);

          g.gain.setValueAtTime(0.04, now);
          g.gain.linearRampToValueAtTime(0.07, now + 0.8);
          g.gain.exponentialRampToValueAtTime(0.001, now + 3.2);

          osc.connect(g);
          g.connect(this.musicGain);

          osc.start(now);
          osc.stop(now + 3.3);
        });

        chordIndex++;
        const timer = window.setTimeout(playChord, 3000);
        timers.push(timer);
      };

      playChord();
    } else if (trackId === 'lofi_sonati') {
      // Cozy mellow lo-fi melody
      const lofiPentatonic = [196.0, 220.0, 261.63, 293.66, 329.63, 392.0];
      let beat = 0;

      const playLofiBeat = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = lofiPentatonic[Math.floor(Math.random() * lofiPentatonic.length)];

        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);

        g.gain.setValueAtTime(0.08, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.85);

        osc.connect(g);
        g.connect(this.musicGain);

        osc.start(now);
        osc.stop(now + 0.9);

        beat++;
        const timer = window.setTimeout(playLofiBeat, 500);
        timers.push(timer);
      };

      playLofiBeat();
    } else if (trackId === 'samovar_rain') {
      // Procedural bubbling samovar steam + gentle rain noise
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.15;
      }

      const rainSource = this.ctx.createBufferSource();
      rainSource.buffer = noiseBuffer;
      rainSource.loop = true;

      const rainFilter = this.ctx.createBiquadFilter();
      rainFilter.type = 'lowpass';
      rainFilter.frequency.setValueAtTime(800, this.ctx.currentTime);

      const rainGain = this.ctx.createGain();
      rainGain.gain.setValueAtTime(0.12, this.ctx.currentTime);

      rainSource.connect(rainFilter);
      rainFilter.connect(rainGain);
      rainGain.connect(this.musicGain);

      rainSource.start();

      // Samovar bubbles periodic pop
      const playBubble = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();

        const bFreq = 600 + Math.random() * 400;
        bOsc.type = 'sine';
        bOsc.frequency.setValueAtTime(bFreq, now);
        bOsc.frequency.exponentialRampToValueAtTime(bFreq + 300, now + 0.08);

        bGain.gain.setValueAtTime(0.05, now);
        bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

        bOsc.connect(bGain);
        bGain.connect(this.musicGain);

        bOsc.start(now);
        bOsc.stop(now + 0.09);

        const timer = window.setTimeout(playBubble, 120 + Math.random() * 180);
        timers.push(timer);
      };

      playBubble();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            rainSource.stop();
          } catch {
            // Safe cleanup
          }
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'folk_gilan') {
      // -------------------------------------------------------------
      // Folk Music: Gilan & Mazandaran (گیلان و مازندران - رعنا و دیلمان)
      // Cheerful Caspian pastoral 6/8 tempo, Lalava bamboo flute & Dayereh
      // Pentatonic / Gilaki scale: D4 (293.66), E4 (329.63), G4 (392.0), A4 (440.0), B4 (493.88), D5 (587.33)
      // -------------------------------------------------------------
      const gilanMelody = [
        392.0, 440.0, 493.88, 587.33, 493.88, 440.0, // رعنا رعنا گل رعنا
        392.0, 440.0, 392.0, 329.63, 293.66, 329.63, 392.0, // شالیزار و چای لاهیجان
        440.0, 493.88, 587.33, 659.25, 587.33, 493.88, 440.0,
        392.0, 329.63, 293.66, 329.63, 392.0,
      ];
      let step = 0;

      // Gentle rustling forest breeze / river stream
      const noiseBuffer = this.getNoiseBuffer();
      let streamSource: AudioBufferSourceNode | null = null;
      if (noiseBuffer) {
        streamSource = this.ctx.createBufferSource();
        streamSource.buffer = noiseBuffer;
        streamSource.loop = true;
        const streamFilter = this.ctx.createBiquadFilter();
        streamFilter.type = 'bandpass';
        streamFilter.frequency.setValueAtTime(950, this.ctx.currentTime);
        streamFilter.Q.setValueAtTime(2.0, this.ctx.currentTime);
        const streamGain = this.ctx.createGain();
        streamGain.gain.setValueAtTime(0.025, this.ctx.currentTime);
        streamSource.connect(streamFilter);
        streamFilter.connect(streamGain);
        streamGain.connect(this.musicGain);
        streamSource.start();
      }

      const playGilanFlute = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = gilanMelody[step % gilanMelody.length];

        // Lalava flute: pure fundamental with gentle airy harmonic
        const osc = this.ctx.createOscillator();
        const oscAir = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);
        // Playful pastoral trill on some notes
        if (step % 4 === 1) {
          osc.frequency.setValueAtTime(freq, now);
          osc.frequency.setValueAtTime(freq * 1.06, now + 0.08);
          osc.frequency.setValueAtTime(freq, now + 0.15);
        }

        oscAir.type = 'triangle';
        oscAir.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1600, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.11, now + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

        osc.connect(filter);
        oscAir.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        oscAir.start(now);
        osc.stop(now + 0.48);
        oscAir.stop(now + 0.48);

        // Dayereh cheerful soft beat on 6/8
        if (step % 3 === 0 || step % 3 === 2) {
          const dOsc = this.ctx.createOscillator();
          const dGain = this.ctx.createGain();
          dOsc.type = 'triangle';
          dOsc.frequency.setValueAtTime(step % 3 === 0 ? 160 : 280, now);
          dGain.gain.setValueAtTime(0.04, now);
          dGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
          dOsc.connect(dGain);
          dGain.connect(this.musicGain);
          dOsc.start(now);
          dOsc.stop(now + 0.12);
        }

        step++;
        const nextDelay = step % 3 === 2 ? 380 : 260; // 6/8 lilting groove
        const timer = window.setTimeout(playGilanFlute, nextDelay);
        timers.push(timer);
      };

      playGilanFlute();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            streamSource?.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'folk_khorasan') {
      // -------------------------------------------------------------
      // Folk Music: Khorasan (خراسان - دوتار نوایی و مقام الله مزار)
      // Double-string Dotar picking with resonant high-low string drones
      // Navaei scale in Dastgah Nava: D3 (146.83), G3 (196.0), A3 (220.0), Bb3 (233.08), C4 (261.63), D4 (293.66), F4 (349.23)
      // -------------------------------------------------------------
      const navaeiTheme = [
        196.0, 220.0, 261.63, 293.66, 261.63, 220.0, 196.0, // نوایی نوایی نوایی نوایی
        261.63, 293.66, 349.23, 349.23, 293.66, 261.63, 293.66, // همه باوفایند تو گل بی‌وفایی
        293.66, 261.63, 220.0, 196.0, 146.83, 196.0, // غمت در نهان‌خانه دل نشیند
      ];
      let step = 0;

      // Desert twilight breeze drone (سیم بم دوتار)
      const dotarDrone = this.ctx.createOscillator();
      const dotarDroneGain = this.ctx.createGain();
      dotarDrone.type = 'sawtooth';
      dotarDrone.frequency.setValueAtTime(146.83, this.ctx.currentTime); // D3
      const droneFilter = this.ctx.createBiquadFilter();
      droneFilter.type = 'lowpass';
      droneFilter.frequency.setValueAtTime(320, this.ctx.currentTime);
      dotarDroneGain.gain.setValueAtTime(0.03, this.ctx.currentTime);
      dotarDrone.connect(droneFilter);
      droneFilter.connect(dotarDroneGain);
      dotarDroneGain.connect(this.musicGain);
      dotarDrone.start();

      const playDotarStrum = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = navaeiTheme[step % navaeiTheme.length];

        // Dotar characteristic silk/nylon double string "charkhesh" attack
        [0, 0.025].forEach((offset, idx) => {
          if (!this.ctx || !this.musicGain) return;
          const t = now + offset;
          const oscMelody = this.ctx.createOscillator();
          const oscPluck = this.ctx.createOscillator();
          const filter = this.ctx.createBiquadFilter();
          const gain = this.ctx.createGain();

          oscMelody.type = 'sawtooth';
          oscMelody.frequency.setValueAtTime(idx === 1 ? freq : freq * 0.5, t);

          oscPluck.type = 'triangle';
          oscPluck.frequency.setValueAtTime(freq * (idx === 1 ? 2 : 1), t);

          filter.type = 'bandpass';
          filter.frequency.setValueAtTime(1400, t);
          filter.frequency.exponentialRampToValueAtTime(500, t + 0.35);

          gain.gain.setValueAtTime(idx === 1 ? 0.12 : 0.06, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.55);

          oscMelody.connect(filter);
          oscPluck.connect(filter);
          filter.connect(gain);
          gain.connect(this.musicGain);

          oscMelody.start(t);
          oscPluck.start(t);
          oscMelody.stop(t + 0.6);
          oscPluck.stop(t + 0.6);
        });

        step++;
        const nextTime = step % 4 === 0 ? 550 : 360;
        const timer = window.setTimeout(playDotarStrum, nextTime);
        timers.push(timer);
      };

      playDotarStrum();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            dotarDrone.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'folk_kurdistan') {
      // -------------------------------------------------------------
      // Folk Music: Kurdistan & Kermanshah (کردستان و کرمانشاه - تنبور و دف خانقاهی)
      // Sacred Tanbur picking & soaring Siah-Chemaneh / Hawraman melody with rhythmic Daf
      // Tanbur scale: C3 (130.81), F3 (174.61), G3 (196.0), Bb3 (233.08), C4 (261.63), D4 (293.66)
      // -------------------------------------------------------------
      const kurdishMotif = [
        174.61, 196.0, 233.08, 261.63, 293.66, 261.63, 233.08, 196.0,
        233.08, 261.63, 293.66, 349.23, 293.66, 261.63, 233.08,
        196.0, 174.61, 130.81, 174.61,
      ];
      let step = 0;

      const playTanburAndDaf = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = kurdishMotif[step % kurdishMotif.length];

        // Tanbur ring (sharp percussive fingernail pluck + woody body)
        const osc = this.ctx.createOscillator();
        const oscBody = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscBody.type = 'triangle';
        oscBody.frequency.setValueAtTime(freq * 1.5, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1800, now);
        filter.frequency.exponentialRampToValueAtTime(600, now + 0.4);

        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);

        osc.connect(filter);
        oscBody.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        oscBody.start(now);
        osc.stop(now + 0.7);
        oscBody.stop(now + 0.7);

        // Deep resonant Sufi Daf beat (دف خانقاهی: بوم - تاک)
        if (step % 2 === 0) {
          const isBoom = step % 4 === 0;
          const dafOsc = this.ctx.createOscillator();
          const dafFilter = this.ctx.createBiquadFilter();
          const dafGain = this.ctx.createGain();

          dafOsc.type = 'sine';
          dafOsc.frequency.setValueAtTime(isBoom ? 75 : 190, now);
          dafOsc.frequency.exponentialRampToValueAtTime(isBoom ? 45 : 120, now + 0.25);

          dafFilter.type = 'lowpass';
          dafFilter.frequency.setValueAtTime(350, now);

          dafGain.gain.setValueAtTime(isBoom ? 0.14 : 0.07, now);
          dafGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

          dafOsc.connect(dafFilter);
          dafFilter.connect(dafGain);
          dafGain.connect(this.musicGain);

          dafOsc.start(now);
          dafOsc.stop(now + 0.36);
        }

        step++;
        const nextTime = step % 4 === 0 ? 500 : 320;
        const timer = window.setTimeout(playTanburAndDaf, nextTime);
        timers.push(timer);
      };

      playTanburAndDaf();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'folk_azarbaijan') {
      // -------------------------------------------------------------
      // Folk Music: Azarbaijan (آذربایجان - بالابان و ساری گلین)
      // Warm double-reed Balaban vibrato with nostalgic, heartfelt melody
      // Sari Gelin scale: G3 (196.0), Bb3 (233.08), C4 (261.63), D4 (293.66), Eb4 (311.13), F4 (349.23), G4 (392.0)
      // -------------------------------------------------------------
      const sariGelinNotes = [
        261.63, 293.66, 311.13, 349.23, 311.13, 293.66, // ساری گلین
        293.66, 261.63, 233.08, 261.63, 293.66,
        349.23, 392.0, 349.23, 311.13, 293.66, 261.63, // سهند و سبلان
        233.08, 196.0, 233.08, 261.63,
      ];
      let step = 0;

      // Soft Balaban continuous drone
      const balabanDrone = this.ctx.createOscillator();
      const balabanDroneGain = this.ctx.createGain();
      balabanDrone.type = 'sawtooth';
      balabanDrone.frequency.setValueAtTime(196.0, this.ctx.currentTime); // G3
      const bDroneFilter = this.ctx.createBiquadFilter();
      bDroneFilter.type = 'lowpass';
      bDroneFilter.frequency.setValueAtTime(450, this.ctx.currentTime);
      balabanDroneGain.gain.setValueAtTime(0.035, this.ctx.currentTime);
      balabanDrone.connect(bDroneFilter);
      bDroneFilter.connect(balabanDroneGain);
      balabanDroneGain.connect(this.musicGain);
      balabanDrone.start();

      const playBalabanNote = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = sariGelinNotes[step % sariGelinNotes.length];

        // Balaban reed: warm, expressive, with characteristic 5Hz vibrato
        const osc = this.ctx.createOscillator();
        const oscHarmonic = this.ctx.createOscillator();
        const vibrato = this.ctx.createOscillator();
        const vibratoGain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        vibrato.frequency.setValueAtTime(5.1, now);
        vibratoGain.gain.setValueAtTime(3.2, now);
        vibrato.connect(vibratoGain);
        vibratoGain.connect(osc.frequency);

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscHarmonic.type = 'sine';
        oscHarmonic.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(850, now);
        filter.Q.setValueAtTime(1.8, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.15);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.1);

        osc.connect(filter);
        oscHarmonic.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        vibrato.start(now);
        osc.start(now);
        oscHarmonic.start(now);
        vibrato.stop(now + 1.15);
        osc.stop(now + 1.15);
        oscHarmonic.stop(now + 1.15);

        step++;
        const delay = step % 4 === 0 ? 1100 : 650;
        const timer = window.setTimeout(playBalabanNote, delay);
        timers.push(timer);
      };

      playBalabanNote();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            balabanDrone.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'folk_bushehr') {
      // -------------------------------------------------------------
      // Folk Music: Bushehr & Persian Gulf (بوشهر و جنوب - نی‌انبان و دمام خلیج فارس)
      // Fast, joyful, swinging 6/8 Bandari bagpipe drone and vibrant coastal rhythm
      // Southern scale: D4 (293.66), E4 (329.63), F#4 (369.99), G4 (392.0), A4 (440.0), B4 (493.88), C5 (523.25)
      // -------------------------------------------------------------
      const bandariMelody = [
        392.0, 440.0, 493.88, 523.25, 493.88, 440.0, 392.0, // نغمه پرانرژی نی‌انبان
        440.0, 493.88, 440.0, 369.99, 329.63, 293.66, 329.63, 369.99,
        392.0, 440.0, 493.88, 523.25, 587.33, 523.25, 493.88,
        440.0, 392.0, 369.99, 392.0,
      ];
      let step = 0;

      // Bagpipe drone continuous reed hum (زنگ ممتد نی‌انبان)
      const bagpipeDrone = this.ctx.createOscillator();
      const bagpipeDroneGain = this.ctx.createGain();
      bagpipeDrone.type = 'sawtooth';
      bagpipeDrone.frequency.setValueAtTime(293.66, this.ctx.currentTime); // D4
      const bpFilter = this.ctx.createBiquadFilter();
      bpFilter.type = 'bandpass';
      bpFilter.frequency.setValueAtTime(750, this.ctx.currentTime);
      bpFilter.Q.setValueAtTime(2.5, this.ctx.currentTime);
      bagpipeDroneGain.gain.setValueAtTime(0.035, this.ctx.currentTime);
      bagpipeDrone.connect(bpFilter);
      bpFilter.connect(bagpipeDroneGain);
      bagpipeDroneGain.connect(this.musicGain);
      bagpipeDrone.start();

      const playNeyAnban = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = bandariMelody[step % bandariMelody.length];

        // Ney-Anban vibrant double-reed chanter tone
        const osc = this.ctx.createOscillator();
        const oscOctave = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        oscOctave.type = 'square';
        oscOctave.frequency.setValueAtTime(freq * 0.5, now);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1250, now);
        filter.Q.setValueAtTime(1.5, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

        osc.connect(filter);
        oscOctave.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        oscOctave.start(now);
        osc.stop(now + 0.38);
        oscOctave.stop(now + 0.38);

        // Southern Dammam percussion rhythm (دمام خلیج فارس)
        const dammamOsc = this.ctx.createOscillator();
        const dammamGain = this.ctx.createGain();
        dammamOsc.type = 'triangle';
        dammamOsc.frequency.setValueAtTime(step % 3 === 0 ? 110 : 210, now);
        dammamGain.gain.setValueAtTime(0.07, now);
        dammamGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
        dammamOsc.connect(dammamGain);
        dammamGain.connect(this.musicGain);
        dammamOsc.start(now);
        dammamOsc.stop(now + 0.18);

        step++;
        const nextTime = step % 3 === 2 ? 310 : 210; // Lively Bandari swing
        const timer = window.setTimeout(playNeyAnban, nextTime);
        timers.push(timer);
      };

      playNeyAnban();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            bagpipeDrone.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'folk_lorestan') {
      // -------------------------------------------------------------
      // Folk Music: Lorestan & Zagros (لرستان - کمانچه لری و دایه دایه)
      // Epic mountain spirit, fast Kamancheh (Tal) and rhythmic Zagros drum
      // Lurish scale: E3 (164.81), G3 (196.0), A3 (220.0), B3 (246.94), C4 (261.63), D4 (293.66), E4 (329.63)
      // -------------------------------------------------------------
      const loriTheme = [
        220.0, 246.94, 261.63, 293.66, 329.63, 293.66, 261.63, // دایه دایه وقته جنگه
        246.94, 220.0, 196.0, 220.0, 246.94, 220.0, // قطار که بستمه سر بالا
        261.63, 293.66, 329.63, 392.0, 329.63, 293.66, 261.63,
        246.94, 220.0, 196.0, 164.81, 220.0,
      ];
      let step = 0;

      const playLoriKamancheh = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = loriTheme[step % loriTheme.length];

        // Tal (Lurish Kamancheh) fiery bowed string with slide
        const osc = this.ctx.createOscillator();
        const oscSymp = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq * 0.96, now);
        osc.frequency.exponentialRampToValueAtTime(freq, now + 0.06);

        oscSymp.type = 'triangle';
        oscSymp.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1700, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.42);

        osc.connect(filter);
        oscSymp.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        oscSymp.start(now);
        osc.stop(now + 0.45);
        oscSymp.stop(now + 0.45);

        // Mountain warrior Zagros drum beat
        if (step % 2 === 0) {
          const drumOsc = this.ctx.createOscillator();
          const drumGain = this.ctx.createGain();
          drumOsc.type = 'triangle';
          drumOsc.frequency.setValueAtTime(step % 4 === 0 ? 95 : 180, now);
          drumGain.gain.setValueAtTime(0.08, now);
          drumGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
          drumOsc.connect(drumGain);
          drumGain.connect(this.musicGain);
          drumOsc.start(now);
          drumOsc.stop(now + 0.22);
        }

        step++;
        const nextTime = step % 4 === 0 ? 460 : 300;
        const timer = window.setTimeout(playLoriKamancheh, nextTime);
        timers.push(timer);
      };

      playLoriKamancheh();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'prov_fars') {
      // -------------------------------------------------------------
      // Province 1: Fars & Shiraz (استان فارس - واسونک و بهارنارنج)
      // Joyous Shirazi 6/8 dance, bright Tar plucks & sweet Tombak rhythm
      // -------------------------------------------------------------
      const vasunakNotes = [
        293.66, 329.63, 349.23, 392.0, 440.0, 392.0, 349.23, 329.63, // یار مبارک بادا
        293.66, 349.23, 392.0, 440.0, 392.0, 349.23, 293.66,
        329.63, 349.23, 392.0, 349.23, 329.63, 293.66, 261.63, 293.66,
      ];
      let step = 0;

      const playShiraziTar = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = vasunakNotes[step % vasunakNotes.length];

        // Shirazi Tar plucked string
        const osc = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        osc2.type = 'sawtooth';
        osc2.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1400, now);
        filter.Q.setValueAtTime(2.5, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.14, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

        osc.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        osc2.start(now);
        osc.stop(now + 0.4);
        osc2.stop(now + 0.4);

        // Shirazi 6/8 Tombak Groove
        const drumOsc = this.ctx.createOscillator();
        const drumGain = this.ctx.createGain();
        drumOsc.type = 'sine';
        drumOsc.frequency.setValueAtTime(step % 3 === 0 ? 110 : 220, now);
        drumGain.gain.setValueAtTime(step % 3 === 0 ? 0.09 : 0.04, now);
        drumGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
        drumOsc.connect(drumGain);
        drumGain.connect(this.musicGain);
        drumOsc.start(now);
        drumOsc.stop(now + 0.18);

        step++;
        const nextTime = step % 3 === 0 ? 320 : 220;
        const timer = window.setTimeout(playShiraziTar, nextTime);
        timers.push(timer);
      };

      playShiraziTar();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'prov_isfahan') {
      // -------------------------------------------------------------
      // Province 2: Isfahan (استان اصفهان - زاینده‌رود و نقش‌جهان)
      // Chaharmezrab Isfahan with brilliant Santoor double-mezrab cascades
      // -------------------------------------------------------------
      const esfahanNotes = [
        261.63, 293.66, 311.13, 349.23, 392.0, 415.3, 493.88, 523.25, // گام بیات اصفهان
        493.88, 415.3, 392.0, 349.23, 311.13, 293.66, 261.63,
        349.23, 392.0, 415.3, 523.25, 415.3, 392.0, 349.23,
      ];
      let step = 0;

      const playIsfahanSantoor = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = esfahanNotes[step % esfahanNotes.length];

        // Santoor double-mezrab strike (ریز سنتور)
        [0, 0.05].forEach((offset, idx) => {
          if (!this.ctx || !this.musicGain) return;
          const t = now + offset;
          const osc = this.ctx.createOscillator();
          const filter = this.ctx.createBiquadFilter();
          const gain = this.ctx.createGain();

          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, t);

          filter.type = 'highpass';
          filter.frequency.setValueAtTime(320, t);

          gain.gain.setValueAtTime(0.01, t);
          gain.gain.linearRampToValueAtTime(idx === 0 ? 0.11 : 0.08, t + 0.015);
          gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(this.musicGain);

          osc.start(t);
          osc.stop(t + 0.48);
        });

        step++;
        const nextTime = step % 4 === 0 ? 380 : 210;
        const timer = window.setTimeout(playIsfahanSantoor, nextTime);
        timers.push(timer);
      };

      playIsfahanSantoor();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'prov_yazd') {
      // -------------------------------------------------------------
      // Province 3: Yazd (استان یزد - بادگیرها و سکوت کویر)
      // Meditative, mystical desert Setar plucks and gentle wind drone
      // -------------------------------------------------------------
      const yazdNotes = [
        146.83, 164.81, 174.61, 196.0, 220.0, 246.94, 293.66,
        246.94, 220.0, 196.0, 174.61, 146.83, 110.0, 146.83,
      ];
      let step = 0;

      // Soft desert wind drone
      const windDrone = this.ctx.createOscillator();
      const windGain = this.ctx.createGain();
      windDrone.type = 'sine';
      windDrone.frequency.setValueAtTime(110.0, this.ctx.currentTime); // A2
      windGain.gain.setValueAtTime(0.035, this.ctx.currentTime);
      windDrone.connect(windGain);
      windGain.connect(this.musicGain);
      windDrone.start();

      const playYazdSetar = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = yazdNotes[step % yazdNotes.length];

        // Intimate Setar pluck with sympathetic nail ringing
        const osc = this.ctx.createOscillator();
        const nail = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);
        nail.type = 'sine';
        nail.frequency.setValueAtTime(freq * 3, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1100, now);
        filter.frequency.exponentialRampToValueAtTime(350, now + 0.6);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.09, now + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.85);

        osc.connect(filter);
        nail.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        nail.start(now);
        osc.stop(now + 0.9);
        nail.stop(now + 0.9);

        step++;
        const nextTime = 480 + (step % 3) * 140;
        const timer = window.setTimeout(playYazdSetar, nextTime);
        timers.push(timer);
      };

      playYazdSetar();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          try {
            windDrone.stop();
          } catch {}
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'prov_mazandaran') {
      // -------------------------------------------------------------
      // Province 4: Mazandaran (استان مازندران - آوای طبرستان و لله‌وا)
      // Cheerful mountain flute (Laleva) & Tabari rhythm
      // -------------------------------------------------------------
      const mazaniNotes = [
        329.63, 392.0, 440.0, 493.88, 523.25, 493.88, 440.0, 392.0, // امیری و کتولی
        329.63, 392.0, 440.0, 493.88, 587.33, 523.25, 493.88,
        440.0, 392.0, 329.63, 293.66, 329.63,
      ];
      let step = 0;

      const playMazaniLaleva = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = mazaniNotes[step % mazaniNotes.length];

        // Laleva reed breath sound
        const osc = this.ctx.createOscillator();
        const breath = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        breath.type = 'sine';
        breath.frequency.setValueAtTime(freq * 1.5, now);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(950, now);
        filter.Q.setValueAtTime(2.2, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

        osc.connect(filter);
        breath.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        breath.start(now);
        osc.stop(now + 0.48);
        breath.stop(now + 0.48);

        // Mazandarani Desarkotan drum tap
        if (step % 2 === 0) {
          const tapOsc = this.ctx.createOscillator();
          const tapGain = this.ctx.createGain();
          tapOsc.type = 'triangle';
          tapOsc.frequency.setValueAtTime(step % 4 === 0 ? 120 : 240, now);
          tapGain.gain.setValueAtTime(0.06, now);
          tapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
          tapOsc.connect(tapGain);
          tapGain.connect(this.musicGain);
          tapOsc.start(now);
          tapOsc.stop(now + 0.16);
        }

        step++;
        const nextTime = step % 3 === 0 ? 340 : 240;
        const timer = window.setTimeout(playMazaniLaleva, nextTime);
        timers.push(timer);
      };

      playMazaniLaleva();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'prov_baluchestan') {
      // -------------------------------------------------------------
      // Province 5: Sistan & Baluchestan (سیستان و بلوچستان - قیچک کهن)
      // Rapid Dochapi trance rhythm, rustic Ghaychak bow and energetic pulse
      // -------------------------------------------------------------
      const baluchiNotes = [
        220.0, 261.63, 293.66, 329.63, 392.0, 440.0, 392.0, 329.63,
        293.66, 329.63, 293.66, 261.63, 220.0, 196.0, 220.0,
      ];
      let step = 0;

      const playBaluchiGhaychak = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = baluchiNotes[step % baluchiNotes.length];

        // Ghaychak skin-resonated bow
        const osc = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq * 0.98, now);
        osc.frequency.exponentialRampToValueAtTime(freq, now + 0.04);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1400, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.12, now + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        osc.stop(now + 0.35);

        // Baluchi Doholak rapid rhythmic pattern
        const doholakOsc = this.ctx.createOscillator();
        const doholakGain = this.ctx.createGain();
        doholakOsc.type = 'sine';
        doholakOsc.frequency.setValueAtTime(step % 2 === 0 ? 130 : 260, now);
        doholakGain.gain.setValueAtTime(0.07, now);
        doholakGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        doholakOsc.connect(doholakGain);
        doholakGain.connect(this.musicGain);
        doholakOsc.start(now);
        doholakOsc.stop(now + 0.14);

        step++;
        const nextTime = 200; // Fast energetic Dochapi tempo
        const timer = window.setTimeout(playBaluchiGhaychak, nextTime);
        timers.push(timer);
      };

      playBaluchiGhaychak();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    } else if (trackId === 'prov_khuzestan') {
      // -------------------------------------------------------------
      // Province 6: Khuzestan (استان خوزستان - خروش کارون و شوشتر)
      // Shushtari Santoor melody with soulful Karun Alwaniyeh phrasing
      // -------------------------------------------------------------
      const khuzestanNotes = [
        293.66, 311.13, 369.99, 392.0, 440.0, 369.99, 349.23, 311.13, // گوشه شوشتری
        293.66, 369.99, 392.0, 440.0, 493.88, 440.0, 392.0, 369.99,
        311.13, 293.66, 261.63, 293.66,
      ];
      let step = 0;

      const playKhuzestaniMelody = () => {
        if (!isRunning || !this.ctx || !this.musicGain) return;
        const now = this.ctx.currentTime;
        const freq = khuzestanNotes[step % khuzestanNotes.length];

        // Southern Rababah / Shushtari Santoor timbre
        const osc = this.ctx.createOscillator();
        const oscHarm = this.ctx.createOscillator();
        const filter = this.ctx.createBiquadFilter();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        oscHarm.type = 'sine';
        oscHarm.frequency.setValueAtTime(freq * 2, now);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1350, now);

        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.13, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);

        osc.connect(filter);
        oscHarm.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(now);
        oscHarm.start(now);
        osc.stop(now + 0.5);
        oscHarm.stop(now + 0.5);

        // Warm Dammam heartbeat of Karun
        if (step % 2 === 0) {
          const dammamOsc = this.ctx.createOscillator();
          const dammamGain = this.ctx.createGain();
          dammamOsc.type = 'sine';
          dammamOsc.frequency.setValueAtTime(step % 4 === 0 ? 80 : 160, now);
          dammamGain.gain.setValueAtTime(0.08, now);
          dammamGain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
          dammamOsc.connect(dammamGain);
          dammamGain.connect(this.musicGain);
          dammamOsc.start(now);
          dammamOsc.stop(now + 0.25);
        }

        step++;
        const nextTime = step % 4 === 0 ? 420 : 270;
        const timer = window.setTimeout(playKhuzestaniMelody, nextTime);
        timers.push(timer);
      };

      playKhuzestaniMelody();

      this.activeMusicNodes = {
        stop: () => {
          isRunning = false;
          timers.forEach((t) => clearTimeout(t));
        },
      };
      return;
    }

    this.activeMusicNodes = {
      stop: () => {
        isRunning = false;
        timers.forEach((t) => clearTimeout(t));
      },
    };
  }

  public stopRadio() {
    if (this.activeMusicNodes) {
      this.activeMusicNodes.stop();
      this.activeMusicNodes = null;
    }
  }

  public playDiceRoll() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;

    // Wooden dice bouncing on backgammon board
    const times = [0, 0.08, 0.16, 0.23, 0.29];
    times.forEach((offset, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const t = this.ctx.currentTime + offset;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(280 + Math.random() * 120, t);
      osc.frequency.exponentialRampToValueAtTime(140, t + 0.05);

      gain.gain.setValueAtTime(0.35 / (idx + 1), t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);

      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.06);
    });
    this.vibrate(20);
  }

  public playSugarMelt() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // Sizzling sweet melting sound
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.linearRampToValueAtTime(1600, t + 0.25);
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  public playIceFreeze() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // Crystalline frosty crackle
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1200, t);
    osc.frequency.exponentialRampToValueAtTime(300, t + 0.4);
    gain.gain.setValueAtTime(0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.45);
    this.vibrate([30, 20, 30]);
  }

  public playTrayClatter() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1800, t);
    osc.frequency.exponentialRampToValueAtTime(600, t + 0.15);
    gain.gain.setValueAtTime(0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.16);
  }

  public playSaucerClink() {
    if (this.isMuted) return;
    this.initCtx();
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    // Crisp double-clink like a crystal glass hitting a ceramic saucer
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(2400, t);
    osc1.frequency.exponentialRampToValueAtTime(1800, t + 0.12);

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(3200, t + 0.04);
    osc2.frequency.exponentialRampToValueAtTime(2200, t + 0.18);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(t);
    osc2.start(t + 0.04);
    osc1.stop(t + 0.22);
    osc2.stop(t + 0.22);

    // Tactile haptic double-clink [25, 50, 40]
    this.vibrate([25, 50, 40]);
  }

  public getCurrentTrack(): RadioTrackId {
    return this.currentTrack;
  }
}

export const soundEngine = new SoundEngine();
