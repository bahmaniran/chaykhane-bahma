import React from 'react';

interface CopperTrayProps {
  children: React.ReactNode;
}

export const CopperTray: React.FC<CopperTrayProps> = React.memo(({ children }) => {
  return (
    <div className="relative w-full max-w-[420px] mx-auto flex flex-col items-center justify-end select-none">
      {/* Rustic Carved Wooden Table (میز چوبی روستیک قهوه‌خانه سنتی) */}
      <div className="relative w-full rounded-t-[32px] pt-3 pb-2 px-3 bg-gradient-to-b from-[#5C3A21] via-[#3E2314] to-[#24130A] border-t-4 border-[#784826] shadow-[0_15px_35px_rgba(0,0,0,0.95)]">
        {/* Carved Table Edge Bevel Highlight */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#A0693E]/60 to-transparent pointer-events-none" />

        {/* Realistic Wood Planks Grain Texture */}
        <div className="absolute inset-x-6 top-3 h-[1.5px] bg-[#2A1509]/70 pointer-events-none" />
        <div className="absolute inset-x-12 top-6 h-[1px] bg-[#784826]/30 pointer-events-none" />
        <div className="absolute inset-x-4 top-10 h-[1.5px] bg-[#1F0E05]/60 pointer-events-none" />

        {/* Realistic Ambient Drop Shadow Under the Copper Tray */}
        <div className="absolute inset-x-4 top-4 bottom-2 rounded-[50px] bg-black/60 filter blur-md pointer-events-none" />

        {/* 3D-Perspective Elliptical Hand-Hammered Copper Tray (سینی مسی قلمزنی ۳بعدی) */}
        <div className="relative w-full min-h-[295px] rounded-[52px] p-3 sm:p-4 flex flex-wrap items-center justify-center bg-gradient-to-br from-[#E08E6D] via-[#B85D3B] to-[#5A2713] border-[5px] border-[#F29F7B] shadow-[inset_0_6px_20px_rgba(0,0,0,0.7),0_12px_28px_rgba(0,0,0,0.85)]">
          {/* Outer Raised Metallic Rim Beaded Pattern (لبه قلمزنی کنگره‌ای) */}
          <div className="absolute inset-1.5 rounded-[46px] border-2 border-dashed border-[#FFD0B8]/50 pointer-events-none" />

          {/* Tray Specular Reflection Arc on Top Rim */}
          <div className="absolute top-1 inset-x-12 h-6 rounded-full bg-gradient-to-b from-white/30 to-transparent pointer-events-none" />

          {/* Persian Qalamzani Center Medallion (قلمزنی ترنج و نقوش سنتی اسلیمی) */}
          <div className="absolute inset-5 rounded-[40px] border border-[#FFC2A2]/30 bg-gradient-to-radial from-[#D47043]/40 via-transparent to-[#421B0B]/50 pointer-events-none flex items-center justify-center">
            {/* Traditional Persian Arabesque Center Emblem */}
            <div className="w-28 h-28 rounded-full border border-[#FFE0D0]/25 flex items-center justify-center text-[#FFE0D0]/35 text-3xl font-lalezar">
              ❖
            </div>
          </div>

          {/* Estekans Container Area */}
          {(() => {
            const childrenArray = React.Children.toArray(children);
            const isMultiRow = childrenArray.length >= 6;
            const backRowCount = isMultiRow ? Math.ceil(childrenArray.length / 2) : childrenArray.length;
            const backRowCups = isMultiRow ? childrenArray.slice(0, backRowCount) : childrenArray;
            const frontRowCups = isMultiRow ? childrenArray.slice(backRowCount) : [];

            return isMultiRow ? (
              <div className="relative z-10 w-full flex flex-col items-center justify-center gap-y-2 xs:gap-y-2.5 sm:gap-y-3.5 pt-2 pb-1">
                <div className="w-full flex items-end justify-center gap-x-1.5 xs:gap-x-2.5 sm:gap-x-4 z-10">
                  {backRowCups}
                </div>
                <div className="w-full flex items-end justify-center gap-x-2.5 xs:gap-x-3.5 sm:gap-x-5 z-20">
                  {frontRowCups}
                </div>
              </div>
            ) : (
              <div className="relative z-10 w-full flex flex-wrap items-end justify-center gap-x-2 gap-y-3 pt-3 pb-1">
                {children}
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
});
