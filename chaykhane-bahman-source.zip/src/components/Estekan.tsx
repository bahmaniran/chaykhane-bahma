import React, { useRef, useState, useEffect } from 'react';
import { Cup } from '../types';
import { DRINKS_DATA } from '../constants/drinks';
import { toPersianDigits } from '../utils/persianNumbers';

interface EstekanProps {
  cup: Cup;
  cupIndex?: number;
  isSelected: boolean;
  isHintSource?: boolean;
  isHintTarget?: boolean;
  isPouring?: boolean;
  isReceiving?: boolean;
  pourDirection?: 'left' | 'right';
  colorblindMode: boolean;
  isValidTarget?: boolean;
  isInvalidDimmed?: boolean;
  onClick?: () => void;
  onDoubleTap?: () => void;
  onCupClick?: (index: number) => void;
  onCupDoubleTap?: (index: number) => void;
  hasGoldenSugarCube?: boolean;
}

export const Estekan: React.FC<EstekanProps> = React.memo(({
  cup,
  cupIndex,
  isSelected,
  isHintSource,
  isHintTarget,
  isPouring,
  isReceiving,
  pourDirection = 'right',
  colorblindMode,
  isValidTarget = false,
  isInvalidDimmed = false,
  onClick,
  onDoubleTap,
  onCupClick,
  onCupDoubleTap,
  hasGoldenSugarCube,
}) => {
  const lastTapRef = useRef<number>(0);

  const isFullAndPure =
    cup.layers.length === 4 && cup.layers.every((l) => l === cup.layers[0]);

  // Completion badges (Top "تکمیل شد" badge and Bottom saucer + sugar cube "حبه قند")
  // User requested: disappear after 5 to 8 seconds (timed at 6 seconds + 750ms fade-out)
  const [showCompletedOverlays, setShowCompletedOverlays] = useState<boolean>(false);
  const [isCompletedOverlayFading, setIsCompletedOverlayFading] = useState<boolean>(false);

  useEffect(() => {
    if (isFullAndPure) {
      setShowCompletedOverlays(true);
      setIsCompletedOverlayFading(false);

      // Start fade-out after 6 seconds
      const fadeTimer = setTimeout(() => {
        setIsCompletedOverlayFading(true);
      }, 6000);

      // Completely remove from DOM after smooth 750ms transition
      const hideTimer = setTimeout(() => {
        setShowCompletedOverlays(false);
      }, 6750);

      return () => {
        clearTimeout(fadeTimer);
        clearTimeout(hideTimer);
      };
    } else {
      setShowCompletedOverlays(false);
      setIsCompletedOverlayFading(false);
    }
  }, [isFullAndPure, cup.id]);

  // Exact Iranian Waisted Curve Path
  const cupPathD =
    'M 10,8 C 25,14 55,14 70,8 C 66,38 54,58 58,85 C 62,110 68,122 60,132 C 48,138 32,138 20,132 C 12,122 18,110 22,85 C 26,58 14,38 10,8 Z';

  const layerHeight = 28;
  const liquidBaseY = 132;

  // Active pouring rotation tilt, reception reaction, or selection lift
  const tiltClass = isPouring
    ? pourDirection === 'right'
      ? 'pour-tilt-right'
      : 'pour-tilt-left'
    : isReceiving
    ? 'translate-y-0 scale-102 ring-2 ring-amber-300 shadow-[0_0_22px_rgba(251,191,36,0.85)] rounded-2xl transition-all duration-200'
    : isSelected
    ? '-translate-y-6 z-30 scale-105 ring-2 ring-amber-300'
    : isHintSource
    ? '-translate-y-6 z-40 scale-105 ring-4 ring-amber-400 shadow-[0_0_24px_rgba(251,191,36,0.95)] rounded-2xl animate-pulse'
    : isHintTarget
    ? 'translate-y-0 z-40 scale-105 ring-4 ring-emerald-400 shadow-[0_0_24px_rgba(52,211,153,0.95)] rounded-2xl animate-pulse'
    : isFullAndPure
    ? 'translate-y-0 scale-95 opacity-90 transition-all duration-300'
    : isValidTarget
    ? 'translate-y-0 scale-102 ring-2 ring-amber-400/80 rounded-2xl shadow-[0_0_16px_rgba(245,158,11,0.7)] animate-pulse'
    : isInvalidDimmed
    ? 'translate-y-0 opacity-75'
    : 'translate-y-0 z-20';

  const topLayer = cup.layers[cup.layers.length - 1];
  const topDrink = topLayer ? DRINKS_DATA[topLayer] : null;

  const handleClick = () => {
    if (isFullAndPure || cup.isFrozenSolid) return;

    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      // Double tap detected!
      lastTapRef.current = 0;
      if (onCupDoubleTap && cupIndex !== undefined) {
        onCupDoubleTap(cupIndex);
        return;
      }
      if (onDoubleTap) {
        onDoubleTap();
        return;
      }
    }
    lastTapRef.current = now;
    if (onCupClick && cupIndex !== undefined) {
      onCupClick(cupIndex);
    } else if (onClick) {
      onClick();
    }
  };

  return (
    <div
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (!isFullAndPure && !cup.isFrozenSolid && (e.key === 'Enter' || e.key === ' ')) {
          handleClick();
        }
      }}
      style={{ transformOrigin: '50% 85%' }}
      className={`relative flex flex-col items-center justify-end select-none group touch-manipulation transition-transform duration-300 ease-out cursor-pointer w-[62px] h-[118px] xs:w-[68px] xs:h-[126px] sm:w-[80px] sm:h-[148px] ${tiltClass} ${
        cup.isFrozenSolid ? 'cursor-not-allowed filter grayscale-[0.2]' : ''
      }`}
      aria-label={`استکان ${cup.id + 1} با ${cup.layers.length} لایه`}
    >
      {/* Contact shadow on copper tray */}
      <div className="absolute -bottom-1.5 w-14 sm:w-16 h-3.5 sm:h-4 bg-[#1E0E05]/45 rounded-full filter blur-[3px] pointer-events-none" />

      {/* Royal Persian Coaster / Saucer left on tray when cup is served */}
      {isFullAndPure && showCompletedOverlays && (
        <div
          className={`absolute -bottom-2 w-20 h-6 flex items-center justify-center pointer-events-none z-10 transition-all duration-700 ease-out ${
            isCompletedOverlayFading
              ? 'opacity-0 scale-90 translate-y-1'
              : 'opacity-100 scale-100 translate-y-0 animate-in fade-in zoom-in-95'
          }`}
        >
          {/* Detailed Persian Saucer (نعلبکی) with Engraved Rim */}
          <div className="relative w-18 h-5 rounded-[50%] bg-gradient-to-r from-[#5B2E10] via-[#C06A26] to-[#5B2E10] border-2 border-[#FDE047] shadow-[0_4px_10px_rgba(0,0,0,0.8)] flex items-center justify-center">
            <div className="w-13 h-3 rounded-[50%] border border-amber-200/70 bg-gradient-to-r from-[#321706] via-[#5C2E11] to-[#321706] flex items-center justify-center">
              <span className="text-[7px] text-yellow-300 font-bold font-lalezar">✓ تحویل</span>
            </div>
            {/* Traditional Sugar Cube beside the glass on the saucer */}
            <div
              className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-sm bg-gradient-to-br from-white via-amber-50 to-amber-100 border border-amber-200 shadow-sm flex items-center justify-center rotate-12"
              title="قند پهلو"
            >
              <div className="w-1.5 h-1.5 bg-white/80 rounded-xs" />
            </div>
          </div>
        </div>
      )}

      {/* Visual Hint Badges for Source and Target */}
      {isHintSource && (
        <div className="absolute -top-10 z-50 flex flex-col items-center pointer-events-none animate-bounce">
          <div className="bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 font-lalezar font-bold text-xs px-2.5 py-0.5 rounded-full shadow-lg border-2 border-yellow-100 flex items-center gap-1 whitespace-nowrap">
            <span>👆</span>
            <span>از این بردار</span>
          </div>
          <div className="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[5px] border-t-amber-500" />
        </div>
      )}
      {isHintTarget && (
        <div className="absolute -top-10 z-50 flex flex-col items-center pointer-events-none animate-bounce">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-lalezar font-bold text-xs px-2.5 py-0.5 rounded-full shadow-lg border-2 border-emerald-200 flex items-center gap-1 whitespace-nowrap">
            <span>👇</span>
            <span>بریز اینجا</span>
          </div>
          <div className="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[5px] border-t-emerald-600" />
        </div>
      )}

      {/* Sugar Cube Dissolve Prompt Badge */}
      {cup.hasSugarCubeBlocker && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            handleClick();
          }}
          className="absolute -top-6 z-40 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-300 via-yellow-100 to-amber-300 border-2 border-yellow-500 text-amber-950 font-lalezar text-[11px] font-bold shadow-lg animate-bounce flex items-center gap-1 cursor-pointer whitespace-nowrap hover:scale-105 active:scale-95 transition-transform"
          title="لمس کنید تا قند فوراً حل شود و مسیر استکان باز گردد"
        >
          <span>🍬</span>
          <span>لمس = حل فوری قند</span>
        </div>
      )}

      {/* Cooling Tea Timer Countdown Badge */}
      {cup.coolingMovesLeft !== undefined && !cup.isFrozenSolid && (
        <div className="absolute -top-4 z-40 px-2 py-0.5 rounded-full bg-gradient-to-r from-sky-900 to-cyan-950 border border-sky-300 text-sky-100 font-lalezar text-[10px] shadow-lg animate-pulse flex items-center gap-1">
          <span>❄️</span>
          <span>{toPersianDigits(cup.coolingMovesLeft)} حرکت</span>
        </div>
      )}

      {/* Cup Visual Body Wrapper */}
      <div className="relative flex flex-col items-center justify-end w-full h-full">
        {/* Active Pouring Stream with Fluid Dynamics and Droplet Splashes */}
        {isPouring && topDrink && (
          <div
            className={`absolute top-10 pointer-events-none z-50 ${
              pourDirection === 'right' ? 'left-16' : 'right-16'
            }`}
          >
            <svg width="70" height="120" viewBox="0 0 70 120" fill="none" className="overflow-visible">
              <defs>
                <linearGradient id={`stream-fluid-grad-${cup.id}`} x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor={topDrink.gradient[0]} />
                  <stop offset="35%" stopColor="#FFFBEB" stopOpacity="0.95" />
                  <stop offset="65%" stopColor={topDrink.gradient[0]} />
                  <stop offset="100%" stopColor={topDrink.gradient[1]} />
                </linearGradient>
                <filter id={`stream-glow-${cup.id}`} x="-30%" y="-30%" width="160%" height="160%">
                  <feGaussianBlur stdDeviation="3.5" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>

              {/* Steam wisps rising gracefully from hot poured stream */}
              <path
                d={pourDirection === 'right' ? 'M 20 22 Q 28 12, 34 2' : 'M 50 22 Q 42 12, 36 2'}
                stroke="#FFFFFF"
                strokeWidth="1.6"
                strokeLinecap="round"
                fill="none"
                opacity="0.65"
                className="animate-pour-steam-wisp-1"
              />
              <path
                d={pourDirection === 'right' ? 'M 36 50 Q 45 35, 48 20' : 'M 34 50 Q 25 35, 22 20'}
                stroke="#FFFBEB"
                strokeWidth="1.8"
                strokeLinecap="round"
                fill="none"
                opacity="0.55"
                className="animate-pour-steam-wisp-2"
              />

              {/* Wide Fluid Ambient Glow in actual drink color */}
              <path
                d={pourDirection === 'right' ? 'M 0 0 C 40 30, 48 75, 54 115' : 'M 70 0 C 30 30, 22 75, 16 115'}
                stroke={topDrink.gradient[0]}
                strokeWidth="13"
                strokeLinecap="round"
                opacity="0.48"
                filter={`url(#stream-glow-${cup.id})`}
              />

              {/* Main Cascading Liquid Stream */}
              <path
                d={pourDirection === 'right' ? 'M 0 0 C 40 30, 48 75, 54 115' : 'M 70 0 C 30 30, 22 75, 16 115'}
                stroke={`url(#stream-fluid-grad-${cup.id})`}
                strokeWidth="7"
                strokeLinecap="round"
                className="animate-pour-stream-pulse"
              />

              {/* High-Velocity Inner Flow Streaks (Continuous Rushing Stream) */}
              <path
                d={pourDirection === 'right' ? 'M 0 0 C 40 30, 48 75, 54 115' : 'M 70 0 C 30 30, 22 75, 16 115'}
                stroke="#FFFFFF"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeDasharray="14 8"
                opacity="0.92"
                className="animate-pour-stream-flow"
              />

              {/* Dynamic Splash Droplets at Stream Termination */}
              <circle
                cx={pourDirection === 'right' ? 54 : 16}
                cy={112}
                r="3.2"
                fill={topDrink.gradient[0]}
                className="animate-droplet-1"
              />
              <circle
                cx={pourDirection === 'right' ? 47 : 23}
                cy={108}
                r="2.2"
                fill="#FFFFFF"
                className="animate-droplet-2"
              />
              <circle
                cx={pourDirection === 'right' ? 60 : 10}
                cy={110}
                r="2.4"
                fill={topDrink.gradient[1]}
                className="animate-droplet-3"
              />
            </svg>
          </div>
        )}

        {/* 3D Glass SVG Container */}
        <svg
          viewBox="0 0 80 140"
          className="w-full h-full max-h-[140px] overflow-visible filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.3)]"
        >
          <defs>
            <clipPath id={`cup-inner-clip-${cup.id}`}>
              <path d={cupPathD} />
            </clipPath>

            {/* Persian Royal Gold Rim Gradient (طرح لب‌طلایی استکان شاه‌عباسی) */}
            <linearGradient id={`gold-rim-grad-${cup.id}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#F59E0B" />
              <stop offset="25%" stopColor="#FEF08A" />
              <stop offset="50%" stopColor="#FBBF24" />
              <stop offset="75%" stopColor="#FFFBEB" />
              <stop offset="100%" stopColor="#D97706" />
            </linearGradient>

            {/* Ultra-Clear Crystal Glass Cavity (شفافیت کامل کریستالی برای دیده شدن پشت استکان) */}
            <linearGradient id={`glass-inner-backlight-${cup.id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.10" />
              <stop offset="30%" stopColor="#FFFFFF" stopOpacity="0.02" />
              <stop offset="70%" stopColor="#FFFFFF" stopOpacity="0.0" />
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.05" />
            </linearGradient>

            {/* High-Clarity Outer Glass Glare with 100% See-Through Crystal Body */}
            <linearGradient id={`glass-glare-${cup.id}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.42" />
              <stop offset="10%" stopColor="#FFFFFF" stopOpacity="0.10" />
              <stop offset="28%" stopColor="#FFFFFF" stopOpacity="0.0" />
              <stop offset="72%" stopColor="#FFFFFF" stopOpacity="0.0" />
              <stop offset="90%" stopColor="#FFFFFF" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.45" />
            </linearGradient>

            {/* 3D Cylindrical Volumetric Light & Side Glass Refractions */}
            <linearGradient id={`liquid-lighting-${cup.id}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#000000" stopOpacity="0.28" />
              <stop offset="12%" stopColor="#FFFFFF" stopOpacity="0.42" />
              <stop offset="32%" stopColor="#FFFFFF" stopOpacity="0.1" />
              <stop offset="68%" stopColor="#000000" stopOpacity="0.06" />
              <stop offset="86%" stopColor="#FFFFFF" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.32" />
            </linearGradient>

            <filter id={`glass-blur-${cup.id}`}>
              <feGaussianBlur stdDeviation="0.8" />
            </filter>

            {/* Translucent Meniscus Lens Optical Gradient */}
            <linearGradient id={`meniscus-translucent-${cup.id}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.45" />
              <stop offset="20%" stopColor="#FEF08A" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.98" />
              <stop offset="80%" stopColor="#FDE68A" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.45" />
            </linearGradient>

            {/* Royal Liquid Caustic Central Beam (نور شکست کریستال در عمق مایع) */}
            <linearGradient id={`liquid-caustic-beam-${cup.id}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
              <stop offset="28%" stopColor="#FFFFFF" stopOpacity="0.12" />
              <stop offset="42%" stopColor="#FFFFFF" stopOpacity="0.38" />
              <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.55" />
              <stop offset="58%" stopColor="#FFFFFF" stopOpacity="0.25" />
              <stop offset="72%" stopColor="#FFFFFF" stopOpacity="0.06" />
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
            </linearGradient>

            {cup.layers.map((layer, idx) => {
              const drink = DRINKS_DATA[layer];
              if (!drink) return null;
              const prevLayer = idx > 0 ? cup.layers[idx - 1] : null;
              const prevDrink = prevLayer ? DRINKS_DATA[prevLayer] : null;

              return (
                <React.Fragment key={`grads-${cup.id}-${idx}`}>
                  {/* Rich 4-Stop Royal Liquid Gradient */}
                  <linearGradient
                    id={`liquid-grad-${cup.id}-${idx}`}
                    x1="0"
                    y1="0"
                    x2="0"
                    y2="1"
                  >
                    <stop offset="0%" stopColor={drink.gradient[0]} stopOpacity="0.95" />
                    <stop offset="30%" stopColor={drink.gradient[0]} stopOpacity="1" />
                    <stop offset="70%" stopColor={drink.gradient[1]} stopOpacity="1" />
                    <stop offset="100%" stopColor={drink.gradient[1]} stopOpacity="0.94" />
                  </linearGradient>

                  {/* 3D Internal Jewel Radial Core */}
                  <radialGradient
                    id={`jewel-core-${cup.id}-${idx}`}
                    cx="48%"
                    cy="40%"
                    r="58%"
                    fx="46%"
                    fy="35%"
                  >
                    <stop offset="0%" stopColor="#FFFFFF" stopOpacity={layer === 'doogh' ? 0.95 : 0.5} />
                    <stop offset="26%" stopColor={drink.gradient[0]} stopOpacity={layer === 'doogh' ? 0.2 : 0.55} />
                    <stop offset="70%" stopColor={drink.gradient[1]} stopOpacity={layer === 'doogh' ? 0.1 : 0.2} />
                    <stop offset="100%" stopColor={layer === 'doogh' ? '#F8FAFC' : '#000000'} stopOpacity={layer === 'doogh' ? 0.15 : 0.45} />
                  </radialGradient>

                  {/* Special Royal Blue Turquoise-Sapphire Radiant Core */}
                  {layer === 'bidmeshk' && (
                    <radialGradient
                      id={`blue-aurora-${cup.id}-${idx}`}
                      cx="50%"
                      cy="42%"
                      r="65%"
                    >
                      <stop offset="0%" stopColor="#E0F2FE" stopOpacity="0.85" />
                      <stop offset="25%" stopColor="#00F2FE" stopOpacity="0.75" />
                      <stop offset="60%" stopColor="#0284C7" stopOpacity="0.35" />
                      <stop offset="100%" stopColor="#1E3A8A" stopOpacity="0.7" />
                    </radialGradient>
                  )}

                  {prevDrink && (
                    <linearGradient
                      id={`layer-diffusion-${cup.id}-${idx}`}
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="0%" stopColor={drink.gradient[1]} stopOpacity="0.8" />
                      <stop offset="50%" stopColor="#FFFFFF" stopOpacity="0.3" />
                      <stop offset="100%" stopColor={prevDrink.gradient[0]} stopOpacity="0.75" />
                    </linearGradient>
                  )}
                </React.Fragment>
              );
            })}
          </defs>

          {/* Liquid & Glass Cavity clipped inside the Waisted Estekan */}
          <g clipPath={`url(#cup-inner-clip-${cup.id})`}>
            {/* 1. Luminous Inner Glass Cavity Back-Wall (Allows empty sections of glass to pop against dark wood) */}
            <path
              d={cupPathD}
              fill={`url(#glass-inner-backlight-${cup.id})`}
            />

            {/* 2. Crystal Cut-Glass Level Marks (طرح تراش خط نشان استکان قجری) in empty portions */}
            {[0, 1, 2, 3].map((lvl) => {
              const isFilled = lvl < cup.layers.length;
              if (isFilled) return null;
              const ringY = liquidBaseY - (lvl + 1) * layerHeight;
              const rx = lvl === 0 ? 20.5 : lvl === 1 ? 18.5 : lvl === 2 ? 22.0 : 26.5;
              const ry = lvl === 0 ? 3.0 : lvl === 1 ? 2.8 : lvl === 2 ? 3.3 : 3.8;

              return (
                <g key={`ring-${lvl}`} opacity="0.45" className="pointer-events-none">
                  {/* Subtle level guide ellipse */}
                  <ellipse
                    cx="40"
                    cy={ringY}
                    rx={rx}
                    ry={ry}
                    fill="none"
                    stroke="#FEF08A"
                    strokeWidth="0.8"
                    strokeDasharray="2 3"
                  />
                  {/* Etched measurement notch dot on outer glass wall */}
                  <circle cx={40 - rx + 1} cy={ringY} r="1.1" fill="#FEF08A" opacity="0.75" />
                  <circle cx={40 + rx - 1} cy={ringY} r="1.1" fill="#FEF08A" opacity="0.75" />
                </g>
              );
            })}

            {/* 3. Render Filled Liquid Layers with Organic Breathing & Meniscus Physics */}
            {cup.layers.map((layer, index) => {
              const drink = DRINKS_DATA[layer];
              if (!drink) return null;
              const layerY = liquidBaseY - (index + 1) * layerHeight;
              const isTopLayer = index === cup.layers.length - 1;

              // Exact glass waist radii for 3D meniscus
              const rx = index === 0 ? 20.5 : index === 1 ? 18.5 : index === 2 ? 22.0 : 26.5;
              const ry = index === 0 ? 3.0 : index === 1 ? 2.8 : index === 2 ? 3.3 : 3.8;

              return (
                <g key={index} className="animate-liquid-breathe">
                  {/* 1. Base Luminous Jewel Liquid Fill */}
                  <rect
                    x="0"
                    y={layerY}
                    width="80"
                    height={layerHeight + 2}
                    fill={`url(#liquid-grad-${cup.id}-${index})`}
                  />

                  {/* 2. Internal 3D Jewel Core Radiance */}
                  <rect
                    x="0"
                    y={layerY}
                    width="80"
                    height={layerHeight + 2}
                    fill={`url(#jewel-core-${cup.id}-${index})`}
                    style={{ mixBlendMode: 'overlay' }}
                  />

                  {/* 3. 3D Cylindrical Glass Refraction & Volumetric Internal Radiance */}
                  <rect
                    x="0"
                    y={layerY}
                    width="80"
                    height={layerHeight + 2}
                    fill={`url(#liquid-lighting-${cup.id})`}
                    style={{ mixBlendMode: 'overlay' }}
                  />

                  {/* 4. Crystal Cut Vertical Caustic Reflection Streak (خطوط شکست نور کریستال در عمق مایع) */}
                  <rect
                    x="18"
                    y={layerY}
                    width="44"
                    height={layerHeight + 2}
                    fill={`url(#liquid-caustic-beam-${cup.id})`}
                    style={{ mixBlendMode: 'screen' }}
                    opacity="0.8"
                  />

                  {/* 5. Glass Bottom Curved Contour for Bottom Layer */}
                  {index === 0 && (
                    <ellipse
                      cx="40"
                      cy={liquidBaseY - 1}
                      rx="18.5"
                      ry="3.2"
                      fill="#000000"
                      fillOpacity="0.32"
                    />
                  )}

                  {/* Subtle Inter-layer Vignette Edge for Depth Separation */}
                  <rect
                    x="0"
                    y={layerY + layerHeight - 1}
                    width="80"
                    height="3"
                    fill="#000000"
                    fillOpacity="0.25"
                  />

                  {/* Specific Royal Drink Micro-Textures & Visual Identity */}
                  {/* SPECTACULAR ROYAL BLUE LIQUID (شربت لاجورد و بیدمشک درباری) */}
                  {layer === 'bidmeshk' && (
                    <g>
                      {/* Luminous Royal Turquoise Inner Caustic Aura */}
                      <ellipse
                        cx="40"
                        cy={layerY + 14}
                        rx={rx * 0.78}
                        ry="9"
                        fill={`url(#blue-aurora-${cup.id}-${index})`}
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* Dynamic Royal Turquoise Fluid Shimmer Wave Ribbon */}
                      <path
                        d={`M ${40 - rx + 3} ${layerY + 12} Q 40 ${layerY + 7} ${40 + rx - 3} ${layerY + 12}`}
                        stroke="#00F2FE"
                        strokeWidth="2.2"
                        strokeOpacity="0.85"
                        strokeLinecap="round"
                        fill="none"
                      />
                      <path
                        d={`M ${40 - rx + 5} ${layerY + 17} Q 40 ${layerY + 22} ${40 + rx - 5} ${layerY + 17}`}
                        stroke="#38BDF8"
                        strokeWidth="1.4"
                        strokeOpacity="0.75"
                        strokeLinecap="round"
                        fill="none"
                      />
                      {/* Royal Floating Azure Bubbles & Star Jewels */}
                      <circle cx="28" cy={layerY + 8} r="1.5" fill="#FFFFFF" opacity="0.95" className="animate-bubble-rise-1" />
                      <circle cx="52" cy={layerY + 15} r="1.8" fill="#E0F2FE" opacity="0.95" className="animate-bubble-rise-2" />
                      <circle cx="36" cy={layerY + 22} r="1.3" fill="#38BDF8" opacity="0.85" className="animate-bubble-rise-3" />
                      <circle cx="48" cy={layerY + 7} r="1.1" fill="#BAE6FD" opacity="0.9" />
                      {/* 4-Point Royal Persian Starlight Glints */}
                      <g transform={`translate(34, ${layerY + 14})`} opacity="0.95">
                        <polygon points="0,-3.5 1,-1 3.5,0 1,1 0,3.5 -1,1 -3.5,0 -1,-1" fill="#FFFFFF" />
                        <circle cx="0" cy="0" r="0.8" fill="#00F2FE" />
                      </g>
                      <g transform={`translate(47, ${layerY + 20})`} opacity="0.88">
                        <polygon points="0,-2.5 0.8,-0.8 2.5,0 0.8,0.8 0,2.5 -0.8,0.8 -2.5,0 -0.8,-0.8" fill="#67E8F9" />
                      </g>
                    </g>
                  )}

                  {/* ROYAL RUBY TEA (چای یاقوتی سلطنتی قندپهلو) */}
                  {layer === 'tea' && (
                    <g>
                      {/* Radiant Ruby-Amber Lantern Heart */}
                      <ellipse
                        cx="40"
                        cy={layerY + 14}
                        rx={rx * 0.82}
                        ry="9.5"
                        fill="#FF2E63"
                        opacity="0.45"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* Golden Amber Core Reflection */}
                      <ellipse
                        cx="38"
                        cy={layerY + 12}
                        rx={rx * 0.48}
                        ry="5.5"
                        fill="#F59E0B"
                        opacity="0.35"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* Fine tea/cinnamon amber specks */}
                      <circle cx="28" cy={layerY + 10} r="1.0" fill="#FEF08A" opacity="0.85" />
                      <circle cx="49" cy={layerY + 18} r="1.2" fill="#FDE047" opacity="0.9" />
                      <circle cx="36" cy={layerY + 22} r="0.9" fill="#FFFBEB" opacity="0.8" />
                    </g>
                  )}

                  {/* IMPERIAL 24K SAFFRON (شربت زعفران اعلای زرین) */}
                  {layer === 'saffron' && (
                    <g>
                      {/* Pure Golden Sunburst Core */}
                      <ellipse
                        cx="40"
                        cy={layerY + 14}
                        rx={rx * 0.8}
                        ry="9"
                        fill="#FEF08A"
                        opacity="0.55"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* Authentic Red Saffron Stigmas (سرگل زعفران قائنات) */}
                      <path
                        d={`M 26 ${layerY + 8} Q 30 ${layerY + 5} 35 ${layerY + 10}`}
                        stroke="#DC2626"
                        strokeWidth="1.2"
                        strokeLinecap="round"
                        fill="none"
                        opacity="0.92"
                      />
                      <path
                        d={`M 44 ${layerY + 17} Q 48 ${layerY + 21} 53 ${layerY + 16}`}
                        stroke="#B91C1C"
                        strokeWidth="1.1"
                        strokeLinecap="round"
                        fill="none"
                        opacity="0.92"
                      />
                      <path
                        d={`M 35 ${layerY + 15} Q 39 ${layerY + 13} 42 ${layerY + 18}`}
                        stroke="#EF4444"
                        strokeWidth="1.0"
                        strokeLinecap="round"
                        fill="none"
                        opacity="0.88"
                      />
                      {/* 24-Karat Gold Sparkles */}
                      <circle cx="23" cy={layerY + 15} r="1.3" fill="#FFFFFF" opacity="0.95" />
                      <circle cx="46" cy={layerY + 8} r="1.6" fill="#FFFBEB" opacity="0.98" />
                      <circle cx="54" cy={layerY + 14} r="1.2" fill="#FEF08A" opacity="0.92" />
                    </g>
                  )}

                  {/* ROYAL OBSIDIAN BLACK (شربت آبنوس و چای مشکی اعلا) */}
                  {layer === 'khakshir' && (
                    <g>
                      {/* Deep Velvet Obsidian Sheen */}
                      <ellipse
                        cx="40"
                        cy={layerY + 14}
                        rx={rx * 0.75}
                        ry="8.5"
                        fill="#71717A"
                        opacity="0.32"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* Silver & Diamond Crystal Micro-Reflections */}
                      <circle cx="26" cy={layerY + 8} r="1.3" fill="#FFFFFF" opacity="0.95" />
                      <circle cx="54" cy={layerY + 16} r="1.5" fill="#E4E4E7" opacity="0.9" />
                      <circle cx="38" cy={layerY + 22} r="1.1" fill="#D4D4D8" opacity="0.85" />
                      {/* Crystalline Facet Edge */}
                      <line
                        x1="30"
                        y1={layerY + 11}
                        x2="50"
                        y2={layerY + 11}
                        stroke="#E4E4E7"
                        strokeWidth="1.2"
                        strokeOpacity="0.65"
                        strokeLinecap="round"
                      />
                    </g>
                  )}

                  {/* ROYAL VELVET DOOGH (دوغ مخملی درباری با نعناع و گل سرخ) */}
                  {layer === 'doogh' && (
                    <g>
                      <circle cx="28" cy={layerY + 8} r="1.3" fill="#15803D" opacity="0.95" />
                      <circle cx="52" cy={layerY + 14} r="1.2" fill="#16A34A" opacity="0.95" />
                      <circle cx="36" cy={layerY + 20} r="1.4" fill="#15803D" opacity="0.9" />
                      {/* Dried Persian Damask Rose Petal Specks (پرک‌های گل‌سرخ) */}
                      <circle cx="44" cy={layerY + 9} r="1.5" fill="#BE123C" opacity="0.95" />
                      <circle cx="32" cy={layerY + 16} r="1.2" fill="#E11D48" opacity="0.92" />
                      {isTopLayer && (
                        <g fill="#FFFFFF" opacity="0.98">
                          <rect x="0" y={layerY} width="80" height="7" fill="#FFFFFF" />
                          <circle cx="20" cy={layerY + 2} r="2.5" />
                          <circle cx="35" cy={layerY + 2.5} r="3" />
                          <circle cx="50" cy={layerY + 2} r="2.7" />
                          <circle cx="65" cy={layerY + 2.8} r="2.2" />
                          <circle cx="30" cy={layerY + 1} r="1.1" fill="#15803D" />
                          <circle cx="48" cy={layerY + 1.5} r="1.3" fill="#BE123C" />
                        </g>
                      )}
                    </g>
                  )}

                  {/* ROYAL EMERALD GREEN (شربت زمرد و سکنجبین نعناع) */}
                  {layer === 'bahar-narenj' && (
                    <g>
                      <ellipse
                        cx="40"
                        cy={layerY + 14}
                        rx={rx * 0.75}
                        ry="8.5"
                        fill="#34D399"
                        opacity="0.45"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* Fresh Mint Vein & Emerald Crystal Highlights */}
                      <path
                        d={`M 26 ${layerY + 10} Q 33 ${layerY + 6} 40 ${layerY + 11}`}
                        stroke="#10B981"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                        fill="none"
                        opacity="0.9"
                      />
                      <circle cx="48" cy={layerY + 15} r="1.5" fill="#A7F3D0" opacity="0.95" />
                      <circle cx="28" cy={layerY + 20} r="1.2" fill="#6EE7B7" opacity="0.9" />
                      <circle cx="43" cy={layerY + 8} r="1.1" fill="#FFFFFF" opacity="0.9" />
                      {/* 4-Point Emerald Glint */}
                      <g transform={`translate(36, ${layerY + 16})`} opacity="0.9">
                        <polygon points="0,-2.5 0.7,-0.7 2.5,0 0.7,0.7 0,2.5 -0.7,0.7 -2.5,0 -0.7,-0.7" fill="#ECFDF5" />
                      </g>
                    </g>
                  )}

                  {/* 4. CRISP, TRANSLUCENT & REALISTIC MENISCUS LENS BOUNDARY */}
                  {isTopLayer ? (
                    /* A. TOP LIQUID SURFACE MENISCUS (Partially-Filled or Full Glass Top Edge) */
                    <g
                      className="pointer-events-none animate-liquid-wave"
                      transform={
                        isPouring
                          ? pourDirection === 'right'
                            ? `rotate(8 40 ${layerY})`
                            : `rotate(-8 40 ${layerY})`
                          : undefined
                      }
                    >
                      {/* Deep Refraction Shadow for 3D Surface Relief */}
                      <ellipse
                        cx="40"
                        cy={layerY + 0.8}
                        rx={rx}
                        ry={ry}
                        fill="#000000"
                        fillOpacity="0.45"
                      />
                      {/* 3D Translucent Dish / Meniscus Surface with Optical Edge */}
                      <ellipse
                        cx="40"
                        cy={layerY}
                        rx={rx}
                        ry={ry}
                        fill={drink.gradient[0]}
                        fillOpacity="0.88"
                        stroke={`url(#meniscus-translucent-${cup.id})`}
                        strokeWidth="1.8"
                        className="animate-meniscus-shimmer"
                      />
                      {/* Inner Meniscus Tone Ring with Translucent Depth */}
                      <ellipse
                        cx="40"
                        cy={layerY}
                        rx={Math.max(1, rx - 2.5)}
                        ry={Math.max(0.5, ry - 0.8)}
                        fill={drink.gradient[1]}
                        fillOpacity="0.75"
                      />
                      {/* Translucent Frosted Glass Refraction Glow */}
                      <ellipse
                        cx="40"
                        cy={layerY - 0.2}
                        rx={rx * 0.72}
                        ry={ry * 0.55}
                        fill="#FFFFFF"
                        fillOpacity="0.35"
                        style={{ mixBlendMode: 'overlay' }}
                      />
                      {/* Specular Teahouse Lantern Glints on Liquid Surface */}
                      <ellipse
                        cx="38"
                        cy={layerY - 0.5}
                        rx={rx * 0.55}
                        ry={ry * 0.4}
                        fill="#FFFFFF"
                        fillOpacity="0.8"
                      />
                      <ellipse
                        cx="35"
                        cy={layerY - 0.7}
                        rx={rx * 0.28}
                        ry={ry * 0.24}
                        fill="#FFFFFF"
                        fillOpacity="0.95"
                      />

                      {/* Active Receiving Pour Ripples & Rising Micro-Bubbles */}
                      {isReceiving && (
                        <g>
                          <ellipse
                            cx="40"
                            cy={layerY}
                            rx={rx * 0.7}
                            ry={ry * 0.7}
                            fill="none"
                            stroke="#FFFFFF"
                            className="animate-receiving-ripple-1"
                          />
                          <ellipse
                            cx="40"
                            cy={layerY}
                            rx={rx * 0.9}
                            ry={ry * 0.9}
                            fill="none"
                            stroke="#FEF08A"
                            className="animate-receiving-ripple-2"
                          />
                          <circle
                            cx="35"
                            cy={layerY + 6}
                            r="1.4"
                            fill="#FFFFFF"
                            className="animate-bubble-rise-1"
                          />
                          <circle
                            cx="45"
                            cy={layerY + 10}
                            r="1.2"
                            fill="#FEF08A"
                            className="animate-bubble-rise-2"
                          />
                          <circle
                            cx="40"
                            cy={layerY + 14}
                            r="1.5"
                            fill="#FFFFFF"
                            className="animate-bubble-rise-3"
                          />
                        </g>
                      )}
                    </g>
                  ) : (
                    /* B. INTER-LAYER BOUNDARY BETWEEN TWO DIFFERENT LIQUIDS (TRANSLUCENT MEMBRANE) */
                    <g className="pointer-events-none animate-inter-layer-pulse">
                      {/* 1. Underlying Dark Refraction Rim for Physical Depth */}
                      <ellipse
                        cx="40"
                        cy={layerY + 0.9}
                        rx={rx}
                        ry={ry}
                        fill="none"
                        stroke="#000000"
                        strokeWidth="2.6"
                        strokeOpacity="0.48"
                      />
                      {/* 2. Soft semi-transparent diffusion blending band where two liquids touch */}
                      {index > 0 && (
                        <rect
                          x={40 - rx}
                          y={layerY - 2.5}
                          width={rx * 2}
                          height="5"
                          fill={`url(#layer-diffusion-${cup.id}-${index})`}
                          opacity="0.65"
                          style={{ mixBlendMode: 'soft-light' }}
                        />
                      )}
                      {/* 3. Semi-Transparent Optical Meniscus Lens Body */}
                      <ellipse
                        cx="40"
                        cy={layerY}
                        rx={rx}
                        ry={ry}
                        fill="#FFFFFF"
                        fillOpacity="0.22"
                        stroke={`url(#meniscus-translucent-${cup.id})`}
                        strokeWidth="1.8"
                        style={{ mixBlendMode: 'screen' }}
                        className="animate-meniscus-shimmer"
                      />
                      {/* 4. Fluid Color Tint Blend along the boundary */}
                      <ellipse
                        cx="40"
                        cy={layerY}
                        rx={Math.max(1, rx - 1.6)}
                        ry={Math.max(0.5, ry - 0.5)}
                        fill={drink.gradient[0]}
                        fillOpacity="0.32"
                        style={{ mixBlendMode: 'overlay' }}
                      />
                      {/* 5. Capillary Edge Notches where liquid touches glass wall */}
                      <ellipse
                        cx={40 - rx + 1.2}
                        cy={layerY - 0.5}
                        rx="2"
                        ry="1"
                        fill="#FFFFFF"
                        fillOpacity="0.85"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      <ellipse
                        cx={40 + rx - 1.2}
                        cy={layerY - 0.5}
                        rx="2"
                        ry="1"
                        fill="#FFFFFF"
                        fillOpacity="0.85"
                        style={{ mixBlendMode: 'screen' }}
                      />
                      {/* 6. Concentrated Crystal Center Gloss & Caustic Highlights */}
                      <ellipse
                        cx="40"
                        cy={layerY - 0.3}
                        rx={rx * 0.58}
                        ry={ry * 0.42}
                        fill="#FFFFFF"
                        fillOpacity="0.88"
                      />
                      <ellipse
                        cx="36"
                        cy={layerY - 0.5}
                        rx={rx * 0.3}
                        ry={ry * 0.24}
                        fill="#FFFFFF"
                        fillOpacity="0.98"
                      />
                    </g>
                  )}

                  {/* Steamy Mystery Layer Mask: "?" for steamy mystery glasses */}
                  {cup.isSteamy && index < cup.layers.length - 1 && (
                    <g>
                      <rect
                        x="0"
                        y={layerY}
                        width="80"
                        height={layerHeight}
                        fill="#CBD5E1"
                        fillOpacity="0.94"
                      />
                      <text
                        x="40"
                        y={layerY + 19}
                        textAnchor="middle"
                        fill="#334155"
                        fontSize="14"
                        fontWeight="900"
                      >
                        ?
                      </text>
                    </g>
                  )}

                  {/* Sugar Cube Blocker Layer Graphic */}
                  {cup.hasSugarCubeBlocker && isTopLayer && (
                    <g className="animate-pulse">
                      <rect
                        x="27"
                        y={layerY - 14}
                        width="26"
                        height="18"
                        rx="3"
                        fill="#FFFFFF"
                        stroke="#E2E8F0"
                        strokeWidth="2"
                      />
                      <line x1="27" y1={layerY - 5} x2="53" y2={layerY - 5} stroke="#CBD5E1" strokeWidth="1" />
                      <circle cx="34" cy={layerY - 9} r="1.5" fill="#94A3B8" />
                      <circle cx="46" cy={layerY - 9} r="1.5" fill="#94A3B8" />
                    </g>
                  )}

                  {/* Colorblind Initial Letter */}
                  {colorblindMode && (!cup.isSteamy || isTopLayer) && (
                    <text
                      x="40"
                      y={layerY + 19}
                      textAnchor="middle"
                      fill={layer === 'doogh' ? '#1F2937' : '#FFFFFF'}
                      fontSize="13"
                      fontWeight="800"
                      fontFamily="Lalezar, Vazirmatn, sans-serif"
                      style={{ textShadow: '0 1px 3px rgba(0,0,0,0.9), 0 0 4px rgba(0,0,0,0.8)' }}
                    >
                      {drink.char}
                    </text>
                  )}
                </g>
              );
            })}
          </g>

          {/* Frozen Solid Ice Overlay */}
          {cup.isFrozenSolid && (
            <g>
              <path
                d={cupPathD}
                fill="#0284C7"
                fillOpacity="0.75"
                stroke="#BAE6FD"
                strokeWidth="2.5"
              />
              <path
                d="M 25 40 L 55 100 M 55 40 L 25 100 M 40 30 L 40 110"
                stroke="#FFFFFF"
                strokeWidth="1.5"
                strokeOpacity="0.7"
                strokeDasharray="4 2"
              />
              <text
                x="40"
                y="74"
                textAnchor="middle"
                fill="#FFFFFF"
                fontSize="12"
                fontWeight="900"
                fontFamily="Lalezar, sans-serif"
              >
                قفل یخ‌زده
              </text>
            </g>
          )}

          {/* 3D Glass Outer Contour with High-Clarity Crystal Rim */}
          <path
            d={cupPathD}
            fill={`url(#glass-glare-${cup.id})`}
            stroke="#FFFFFF"
            strokeOpacity="0.75"
            strokeWidth="1.6"
          />

          {/* Persian Royal Gold Lip Filigree (طرح لب‌طلایی استکان شاه‌عباسی) */}
          <path
            d="M 10,8 C 25,14 55,14 70,8"
            fill="none"
            stroke={`url(#gold-rim-grad-${cup.id})`}
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          <path
            d="M 12,11 C 25,16 55,16 68,11"
            fill="none"
            stroke="#FEF08A"
            strokeWidth="0.8"
            strokeOpacity="0.8"
            strokeLinecap="round"
          />

          {/* Persian Royal Gold Foot Rim at Base */}
          <path
            d="M 20,132 C 32,138 48,138 60,132"
            fill="none"
            stroke={`url(#gold-rim-grad-${cup.id})`}
            strokeWidth="2.0"
            strokeLinecap="round"
            strokeOpacity="0.85"
          />

          {/* Primary Specular Curved Highlight (Soft Left Glare) */}
          <path
            d="M 14,14 C 18,38 28,58 24,85 C 20,110 14,122 22,130"
            stroke="#FFFFFF"
            strokeOpacity="0.82"
            strokeWidth="2.5"
            strokeLinecap="round"
            filter={`url(#glass-blur-${cup.id})`}
          />
          {/* Secondary Sharp Edge Specular Highlight (Right Rim) */}
          <path
            d="M 66,14 C 62,38 52,58 56,85 C 60,110 66,122 58,130"
            stroke="#FFFFFF"
            strokeOpacity="0.45"
            strokeWidth="1.5"
            strokeLinecap="round"
          />

          {/* Golden Rim Seal on completed glass (Visual Closure) */}
          {isFullAndPure ? (
            <g>
              <ellipse
                cx="40"
                cy="8"
                rx="30"
                ry="5"
                fill="#F59E0B"
                fillOpacity="0.85"
                stroke="#FDE047"
                strokeOpacity="1"
                strokeWidth="2.4"
              />
              <ellipse
                cx="40"
                cy="8"
                rx="20"
                ry="3"
                fill="#D97706"
                stroke="#FFFBEB"
                strokeWidth="1.2"
              />
            </g>
          ) : (
            <ellipse
              cx="40"
              cy="8"
              rx="30"
              ry="5"
              fill="#FFFFFF"
              fillOpacity="0.22"
              stroke="#FFFFFF"
              strokeOpacity="0.92"
              strokeWidth="1.8"
            />
          )}
        </svg>

        {/* Completed Seal Badge on Top ("تکمیل شد") */}
        {isFullAndPure && showCompletedOverlays && (
          <div
            className={`absolute -top-3 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 border border-yellow-200 text-amber-950 font-lalezar text-[10px] font-bold shadow-md flex items-center gap-1 transition-all duration-700 ease-out ${
              isCompletedOverlayFading
                ? 'opacity-0 scale-90 -translate-y-1'
                : 'opacity-100 scale-100 translate-y-0 animate-in fade-in zoom-in-95'
            }`}
          >
            <span>✨</span>
            <span>تکمیل شد</span>
          </div>
        )}
      </div>
    </div>
  );
});
