import React from 'react';

export type FolkThemeKey =
  | 'gilan'
  | 'khorasan'
  | 'kurdistan'
  | 'azarbaijan'
  | 'bushehr'
  | 'lorestan'
  | 'fars'
  | 'isfahan'
  | 'yazd'
  | 'mazandaran'
  | 'baluchestan'
  | 'khuzestan'
  | 'classic';

interface FolkAtmosphericBackgroundProps {
  theme: FolkThemeKey;
  className?: string;
  showOverlay?: boolean;
}

export const FolkAtmosphericBackground: React.FC<FolkAtmosphericBackgroundProps> = ({
  theme,
  className = '',
  showOverlay = true,
}) => {
  return (
    <div className={`relative overflow-hidden w-full h-full select-none ${className}`}>
      {theme === 'gilan' && (
        // گیلان و مازندران: مزارع مه‌آلود چای لاهیجان و کوهستان سرسبز هیرکانی
        <div className="absolute inset-0 bg-gradient-to-b from-[#132E1B] via-[#0E2315] to-[#07130A]">
          {/* Sky & Sunbeams */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#2D5A3A_0%,transparent_70%)] opacity-80" />
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="gilanSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#2A5C3D" />
                <stop offset="50%" stopColor="#1B3D28" />
                <stop offset="100%" stopColor="#0B1A10" />
              </linearGradient>
              <linearGradient id="mistGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.05)" />
                <stop offset="50%" stopColor="rgba(255,255,255,0.22)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.05)" />
              </linearGradient>
              <linearGradient id="hillBack" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1E472C" />
                <stop offset="100%" stopColor="#122A1A" />
              </linearGradient>
              <linearGradient id="hillMid" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#2D633D" />
                <stop offset="100%" stopColor="#183622" />
              </linearGradient>
              <linearGradient id="hillFront" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#3E7E4F" />
                <stop offset="100%" stopColor="#1D3E27" />
              </linearGradient>
              <linearGradient id="sunbeam" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FDE047" stopOpacity="0.35" />
                <stop offset="70%" stopColor="#86EFAC" stopOpacity="0.08" />
                <stop offset="100%" stopColor="#10B981" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Background Sky */}
            <rect width="800" height="450" fill="url(#gilanSky)" />

            {/* Sun Rays over Caspian Mountains */}
            <polygon points="400,0 220,450 360,450" fill="url(#sunbeam)" />
            <polygon points="400,0 480,450 620,450" fill="url(#sunbeam)" />
            <circle cx="400" cy="50" r="120" fill="#FDE047" opacity="0.18" filter="blur(20px)" />

            {/* Distant Caspian Mountain Ridge */}
            <path
              d="M0,230 Q120,180 250,210 T500,195 T750,225 L800,240 L800,450 L0,450 Z"
              fill="url(#hillBack)"
              opacity="0.85"
            />

            {/* Morning Fog layer 1 */}
            <rect x="0" y="200" width="800" height="55" fill="url(#mistGrad)" />

            {/* Midground Forest Hills */}
            <path
              d="M0,265 Q180,220 380,250 T800,260 L800,450 L0,450 Z"
              fill="url(#hillMid)"
            />

            {/* Rustic Lahijan Teahouse Cottage Silhouette */}
            <polygon points="210,230 260,190 310,230" fill="#1C1109" />
            <rect x="220" y="230" width="80" height="45" fill="#2E1B0E" />
            <rect x="250" y="240" width="20" height="35" fill="#422513" />
            <rect x="228" y="240" width="14" height="16" fill="#FBBF24" opacity="0.9" />
            <rect x="278" y="240" width="14" height="16" fill="#FBBF24" opacity="0.9" />

            {/* Foreground Tea Plantation Terraces */}
            <path
              d="M0,320 Q200,280 440,310 T800,300 L800,450 L0,450 Z"
              fill="url(#hillFront)"
            />
            {/* Terraced Tea Bush Curves */}
            <path d="M-20,350 Q220,310 460,340 T820,330" stroke="#52A467" strokeWidth="6" fill="none" opacity="0.6" />
            <path d="M-20,380 Q240,340 480,370 T820,360" stroke="#52A467" strokeWidth="8" fill="none" opacity="0.7" />
            <path d="M-20,415 Q260,375 520,405 T820,395" stroke="#3A7549" strokeWidth="10" fill="none" opacity="0.8" />

            {/* Tall Fir & Alder Trees */}
            <polygon points="80,280 90,200 100,280" fill="#0C2012" />
            <polygon points="110,290 120,220 130,290" fill="#0E2716" />
            <polygon points="700,295 715,210 730,295" fill="#0E2716" />
            <polygon points="735,310 745,235 755,310" fill="#0C2012" />
          </svg>
        </div>
      )}

      {theme === 'khorasan' && (
        // خراسان: تپه‌های کویری، کاروانسرای خشتی و آسمان پرستاره نیشابور
        <div className="absolute inset-0 bg-gradient-to-b from-[#090C1A] via-[#1A182E] to-[#2B1B14]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="khorasanSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0B0E21" />
                <stop offset="60%" stopColor="#211832" />
                <stop offset="90%" stopColor="#4A261B" />
                <stop offset="100%" stopColor="#6E381E" />
              </linearGradient>
              <linearGradient id="duneBack" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#61341C" />
                <stop offset="100%" stopColor="#3A1C0E" />
              </linearGradient>
              <linearGradient id="duneFront" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#874723" />
                <stop offset="100%" stopColor="#472312" />
              </linearGradient>
            </defs>

            {/* Sky */}
            <rect width="800" height="450" fill="url(#khorasanSky)" />

            {/* Twinkling Desert Stars */}
            {[
              [60, 40], [140, 70], [210, 30], [280, 85], [350, 45], [420, 25],
              [490, 65], [560, 35], [640, 80], [710, 40], [770, 60], [100, 110],
              [190, 130], [310, 115], [460, 120], [600, 110], [690, 130],
            ].map(([cx, cy], i) => (
              <circle
                key={i}
                cx={cx}
                cy={cy}
                r={i % 3 === 0 ? 2 : 1.2}
                fill="#FFFBEB"
                opacity={0.4 + (i % 5) * 0.15}
              />
            ))}

            {/* Crescent Moon */}
            <circle cx="680" cy="70" r="26" fill="#FEF08A" opacity="0.9" filter="drop-shadow(0 0 12px #FDE047)" />
            <circle cx="688" cy="66" r="24" fill="#0F1226" />

            {/* Ancient Mud-Brick Caravanserai & Windcatcher Silhouette */}
            {/* Central Turquoise Dome Silhouette */}
            <path d="M375,260 Q400,205 425,260 Z" fill="#0D9488" opacity="0.75" />
            <rect x="397" y="195" width="6" height="15" fill="#FBBF24" />
            {/* Caravanserai Adobe Wall & Arches */}
            <rect x="330" y="260" width="140" height="50" fill="#3D1E10" />
            {/* Arches */}
            <path d="M350,300 Q360,275 370,300 Z" fill="#1C0D05" />
            <path d="M390,300 Q400,270 410,300 Z" fill="#F59E0B" opacity="0.95" />
            <path d="M430,300 Q440,275 450,300 Z" fill="#1C0D05" />
            {/* Windcatchers (Badgir) */}
            <rect x="315" y="240" width="16" height="40" fill="#361A0D" />
            <rect x="468" y="240" width="16" height="40" fill="#361A0D" />

            {/* Desert Sand Dunes */}
            <path
              d="M0,290 Q220,240 480,285 T800,270 L800,450 L0,450 Z"
              fill="url(#duneBack)"
            />
            <path
              d="M0,350 Q300,280 580,335 T800,320 L800,450 L0,450 Z"
              fill="url(#duneFront)"
            />

            {/* Glowing Vintage Teahouse Lantern on Sand */}
            <circle cx="640" cy="360" r="30" fill="#F59E0B" opacity="0.3" filter="blur(14px)" />
            <rect x="635" y="348" width="10" height="18" fill="#FDE047" rx="2" />
            <polygon points="633,348 640,340 647,348" fill="#78350F" />
          </svg>
        </div>
      )}

      {theme === 'kurdistan' && (
        // کردستان و کرمانشاه: روستای پلکانی اورامانات در کوه‌های سر به فلک کشیده زاگرس
        <div className="absolute inset-0 bg-gradient-to-b from-[#131229] via-[#1E1636] to-[#1C0F0B]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="kurdSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1B1736" />
                <stop offset="50%" stopColor="#2E1C44" />
                <stop offset="100%" stopColor="#4A2536" />
              </linearGradient>
              <linearGradient id="zagrosBack" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#291838" />
                <stop offset="100%" stopColor="#180D21" />
              </linearGradient>
            </defs>

            <rect width="800" height="450" fill="url(#kurdSky)" />

            {/* Jagged Zagros Mountain Peaks */}
            <polygon points="0,260 140,110 320,240 480,90 660,250 800,140 800,450 0,450" fill="url(#zagrosBack)" />
            <polygon points="80,270 240,140 420,280 570,130 760,260 800,210 800,450 0,450" fill="#1C1026" opacity="0.9" />

            {/* Hawraman Terraced Stone Village Houses stacked on slope */}
            {[
              { x: 380, y: 220, w: 45, h: 22 },
              { x: 420, y: 228, w: 48, h: 22 },
              { x: 350, y: 240, w: 50, h: 24 },
              { x: 400, y: 246, w: 55, h: 25 },
              { x: 455, y: 248, w: 46, h: 24 },
              { x: 320, y: 265, w: 58, h: 28 },
              { x: 380, y: 270, w: 62, h: 28 },
              { x: 445, y: 272, w: 60, h: 28 },
              { x: 290, y: 295, w: 65, h: 32 },
              { x: 360, y: 300, w: 70, h: 32 },
              { x: 435, y: 302, w: 66, h: 32 },
              { x: 505, y: 305, w: 55, h: 30 },
              { x: 260, y: 330, w: 75, h: 35 },
              { x: 340, y: 335, w: 80, h: 35 },
              { x: 425, y: 338, w: 78, h: 35 },
              { x: 510, y: 340, w: 65, h: 34 },
            ].map((box, idx) => (
              <g key={idx}>
                {/* Stone Block */}
                <rect
                  x={box.x}
                  y={box.y}
                  width={box.w}
                  height={box.h}
                  fill={idx % 2 === 0 ? '#422A1E' : '#331F16'}
                  stroke="#26150D"
                  strokeWidth="1.5"
                  rx="1"
                />
                {/* Warm Amber Glowing Window */}
                <rect
                  x={box.x + box.w * 0.25}
                  y={box.y + 4}
                  width={box.w * 0.22}
                  height={box.h * 0.45}
                  fill="#FBBF24"
                  opacity={0.88}
                  rx="1"
                />
                <rect
                  x={box.x + box.w * 0.58}
                  y={box.y + 4}
                  width={box.w * 0.22}
                  height={box.h * 0.45}
                  fill="#F59E0B"
                  opacity={0.75}
                  rx="1"
                />
              </g>
            ))}

            {/* Foreground Slope & Walnut Trees */}
            <path d="M0,360 Q350,340 800,380 L800,450 L0,450 Z" fill="#24140D" />
            {/* Walnut Tree Silhouettes */}
            <circle cx="160" cy="330" r="35" fill="#140B07" />
            <rect x="156" y="345" width="8" height="40" fill="#140B07" />
            <circle cx="660" cy="350" r="45" fill="#140B07" />
            <rect x="655" y="370" width="10" height="40" fill="#140B07" />
          </svg>
        </div>
      )}

      {theme === 'azarbaijan' && (
        // آذربایجان: کوه باصلابت سبلان، دشت شقایق‌های سرخ و آلاچیق ایلیاتی
        <div className="absolute inset-0 bg-gradient-to-b from-[#132A4A] via-[#1D3A3B] to-[#142B1B]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="azSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1B3B60" />
                <stop offset="65%" stopColor="#2D5A68" />
                <stop offset="100%" stopColor="#4A7560" />
              </linearGradient>
            </defs>

            <rect width="800" height="450" fill="url(#azSky)" />

            {/* Mount Sabalan (Snow Capped Summit) */}
            <polygon points="120,290 400,80 680,290" fill="#203947" />
            {/* Snow Peaks */}
            <polygon points="400,80 340,150 370,140 400,165 430,135 460,150" fill="#E2E8F0" />
            <polygon points="400,80 370,120 400,135 430,115" fill="#FFFFFF" />

            {/* Alpine Green Pasture Foothills */}
            <path d="M0,280 Q200,240 450,270 T800,250 L800,450 L0,450 Z" fill="#245435" />
            <path d="M0,330 Q280,290 560,325 T800,310 L800,450 L0,450 Z" fill="#2F6B43" />

            {/* Nomadic Dome Tent (آلاچیق شاهسون عشایر) */}
            <path d="M520,340 Q570,285 620,340 Z" fill="#F8FAFC" opacity="0.9" stroke="#94A3B8" strokeWidth="2" />
            <polygon points="562,340 570,305 578,340" fill="#B91C1C" />
            <rect x="525" y="338" width="90" height="4" fill="#B91C1C" />

            {/* Wild Crimson Poppy Flowers in Alpine Meadow */}
            {[
              [80, 370], [120, 395], [160, 365], [210, 410], [250, 380],
              [310, 390], [360, 420], [420, 385], [460, 415], [510, 375],
              [680, 380], [720, 410], [760, 370], [780, 420],
            ].map(([fx, fy], i) => (
              <g key={i}>
                <circle cx={fx} cy={fy} r="3.5" fill="#EF4444" />
                <circle cx={fx} cy={fy} r="1.5" fill="#18181B" />
              </g>
            ))}
          </svg>
        </div>
      )}

      {theme === 'bushehr' && (
        // بوشهر و جنوب: غروب نیلگون خلیج فارس، نخل‌های سرسبز و لنج صیادی
        <div className="absolute inset-0 bg-gradient-to-b from-[#4A1512] via-[#7C2D12] to-[#0E3547]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="gulfSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#581C10" />
                <stop offset="45%" stopColor="#9A3412" />
                <stop offset="70%" stopColor="#EA580C" />
                <stop offset="85%" stopColor="#F59E0B" />
                <stop offset="100%" stopColor="#FDE047" />
              </linearGradient>
              <linearGradient id="seaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#C2410C" />
                <stop offset="25%" stopColor="#92400E" />
                <stop offset="55%" stopColor="#1E3A5F" />
                <stop offset="100%" stopColor="#0B1E2D" />
              </linearGradient>
            </defs>

            {/* Sunset Sky */}
            <rect width="800" height="280" fill="url(#gulfSky)" />

            {/* Glowing Golden Sun setting on Persian Gulf */}
            <circle cx="400" cy="235" r="45" fill="#FEF08A" filter="drop-shadow(0 0 25px #F59E0B)" />

            {/* Persian Gulf Waters */}
            <rect x="0" y="270" width="800" height="180" fill="url(#seaGrad)" />

            {/* Water Sun Reflection Shimmer */}
            <polygon points="400,270 360,450 440,450" fill="#FDE047" opacity="0.3" filter="blur(6px)" />
            <line x1="380" y1="285" x2="420" y2="285" stroke="#FEF08A" strokeWidth="2" opacity="0.8" />
            <line x1="365" y1="305" x2="435" y2="305" stroke="#FEF08A" strokeWidth="2.5" opacity="0.75" />
            <line x1="350" y1="330" x2="450" y2="330" stroke="#FDE047" strokeWidth="3" opacity="0.7" />
            <line x1="330" y1="365" x2="470" y2="365" stroke="#F59E0B" strokeWidth="3.5" opacity="0.6" />

            {/* Wooden Lenj Boat Silhouette */}
            <path d="M260,285 Q300,305 340,285 L350,278 L250,278 Z" fill="#1C0D05" />
            <line x1="305" y1="278" x2="305" y2="245" stroke="#1C0D05" strokeWidth="2.5" />
            <polygon points="305,250 330,274 305,274" fill="#2E170A" />

            {/* Coastal Date Palm Silhouettes (سایه نخل‌های جنوب) */}
            <path d="M680,450 Q660,320 640,220" stroke="#180A04" strokeWidth="9" fill="none" />
            {/* Palm Fronds */}
            {[0, 40, 80, 130, 170, 220, 270, 310].map((deg, idx) => (
              <path
                key={idx}
                d={`M640,220 Q${640 + Math.cos((deg * Math.PI) / 180) * 50},${
                  220 + Math.sin((deg * Math.PI) / 180) * 35 - 15
                } ${640 + Math.cos((deg * Math.PI) / 180) * 80},${
                  220 + Math.sin((deg * Math.PI) / 180) * 60
                }`}
                stroke="#140803"
                strokeWidth="3.5"
                fill="none"
              />
            ))}

            <path d="M740,450 Q730,340 710,250" stroke="#180A04" strokeWidth="8" fill="none" />
            {[10, 50, 95, 140, 190, 240, 285, 330].map((deg, idx) => (
              <path
                key={idx}
                d={`M710,250 Q${710 + Math.cos((deg * Math.PI) / 180) * 45},${
                  250 + Math.sin((deg * Math.PI) / 180) * 30 - 10
                } ${710 + Math.cos((deg * Math.PI) / 180) * 70},${
                  250 + Math.sin((deg * Math.PI) / 180) * 50
                }`}
                stroke="#140803"
                strokeWidth="3"
                fill="none"
              />
            ))}
          </svg>
        </div>
      )}

      {theme === 'lorestan' && (
        // لرستان: آبشار خروشان بیشه و درختان دیرین بلوط زاگرس
        <div className="absolute inset-0 bg-gradient-to-b from-[#142A29] via-[#0D2622] to-[#0A1A17]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="waterfall" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#E0F2FE" />
                <stop offset="50%" stopColor="#BAE6FD" />
                <stop offset="90%" stopColor="#38BDF8" />
                <stop offset="100%" stopColor="#0284C7" />
              </linearGradient>
            </defs>

            {/* Mountain Cliffs */}
            <rect width="800" height="450" fill="#0F241F" />
            <polygon points="0,0 280,0 240,320 0,360" fill="#1C3831" />
            <polygon points="520,0 800,0 800,360 560,320" fill="#1C3831" />

            {/* Bisheh Cascading Waterfall in Center */}
            <polygon points="340,60 460,60 480,340 320,340" fill="url(#waterfall)" />
            {/* White foaming falls streaks */}
            <line x1="360" y1="60" x2="350" y2="340" stroke="#FFFFFF" strokeWidth="4" opacity="0.85" />
            <line x1="390" y1="60" x2="385" y2="340" stroke="#FFFFFF" strokeWidth="6" opacity="0.9" />
            <line x1="420" y1="60" x2="425" y2="340" stroke="#FFFFFF" strokeWidth="5" opacity="0.85" />
            <line x1="445" y1="60" x2="455" y2="340" stroke="#E0F2FE" strokeWidth="4" opacity="0.8" />

            {/* Waterfall Mist Cloud at Bottom */}
            <circle cx="400" cy="340" r="75" fill="#E0F2FE" opacity="0.45" filter="blur(16px)" />
            <circle cx="360" cy="350" r="60" fill="#FFFFFF" opacity="0.5" filter="blur(12px)" />
            <circle cx="440" cy="350" r="60" fill="#FFFFFF" opacity="0.5" filter="blur(12px)" />

            {/* Emerald River Lagoon Basin */}
            <path d="M0,340 Q400,310 800,340 L800,450 L0,450 Z" fill="#0D534D" />
            <path d="M0,380 Q400,350 800,380 L800,450 L0,450 Z" fill="#093B37" />

            {/* Ancient Zagros Oak Trees framing sides */}
            <circle cx="150" cy="180" r="70" fill="#113329" />
            <circle cx="110" cy="220" r="60" fill="#0D2B22" />
            <rect x="145" y="220" width="16" height="120" fill="#1F150E" />

            <circle cx="670" cy="190" r="75" fill="#113329" />
            <circle cx="710" cy="230" r="65" fill="#0D2B22" />
            <rect x="665" y="230" width="18" height="120" fill="#1F150E" />
          </svg>
        </div>
      )}

      {theme === 'fars' && (
        // استان فارس: آرامگاه حافظ، باغ ارم، سروهای کهن شیراز و شکوفه‌های بهارنارنج
        <div className="absolute inset-0 bg-gradient-to-b from-[#1C0D2E] via-[#431B38] to-[#1F0C16]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="shirazSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1C0D2E" />
                <stop offset="45%" stopColor="#481B3E" />
                <stop offset="75%" stopColor="#A44358" />
                <stop offset="100%" stopColor="#E2847A" />
              </linearGradient>
              <linearGradient id="hafezDome" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#14B8A6" />
                <stop offset="60%" stopColor="#0D9488" />
                <stop offset="100%" stopColor="#0F766E" />
              </linearGradient>
              <linearGradient id="shirazPool" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0D9488" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#042F2E" stopOpacity="0.95" />
              </linearGradient>
            </defs>

            {/* Shiraz Twilight Sky */}
            <rect width="800" height="450" fill="url(#shirazSky)" />

            {/* Glowing Evening Star of Hafez */}
            <circle cx="680" cy="80" r="3" fill="#FFFBEB" opacity="0.9" />
            <circle cx="680" cy="80" r="12" fill="#FDE047" opacity="0.25" filter="blur(4px)" />

            {/* Distant Zagros Purple Mountain Slopes */}
            <path
              d="M0,240 Q180,190 380,225 T800,210 L800,450 L0,450 Z"
              fill="#2A1226"
              opacity="0.9"
            />

            {/* Hafezieh Copper & Turquoise Pavilion Silhouette (Center-Right) */}
            <g transform="translate(360, 110)">
              {/* Turquoise Octagonal Dome */}
              <path
                d="M-45,60 C-45,20 -25,-10 0,-20 C25,-10 45,20 45,60 Z"
                fill="url(#hafezDome)"
              />
              {/* Dome Finial & Spire */}
              <line x1="0" y1="-20" x2="0" y2="-38" stroke="#FBBF24" strokeWidth="2.5" />
              <circle cx="0" cy="-38" r="4" fill="#FDE047" />
              
              {/* Octagonal Pavilion Pillars */}
              <rect x="-42" y="60" width="84" height="6" fill="#451A2E" />
              <rect x="-40" y="66" width="6" height="85" fill="#381525" />
              <rect x="-24" y="66" width="5" height="85" fill="#381525" />
              <rect x="-8" y="66" width="5" height="85" fill="#381525" />
              <rect x="8" y="66" width="5" height="85" fill="#381525" />
              <rect x="24" y="66" width="5" height="85" fill="#381525" />
              <rect x="36" y="66" width="6" height="85" fill="#381525" />
              {/* Marble Tomb Base */}
              <rect x="-55" y="145" width="110" height="15" fill="#2C121F" rx="3" />
            </g>

            {/* Tall Elegant Shiraz Cypress Trees (سرو ناز شیراز) */}
            {/* Left Cypress Pair */}
            <path d="M120,380 C110,320 95,240 120,130 C145,240 130,320 120,380 Z" fill="#0D2E24" />
            <path d="M165,390 C155,340 145,260 165,160 C185,260 175,340 165,390 Z" fill="#08211A" />
            {/* Right Cypress Pair */}
            <path d="M620,380 C610,320 595,240 620,140 C645,240 630,320 620,380 Z" fill="#0D2E24" />
            <path d="M670,390 C660,340 650,260 670,170 C690,260 680,340 670,390 Z" fill="#08211A" />

            {/* Traditional Persian Turquoise Water Channel (حوض فیروزه‌ای باغ ایرانی) */}
            <polygon points="280,340 520,340 600,450 200,450" fill="url(#shirazPool)" />
            {/* Glowing Pool Edging */}
            <polygon points="275,338 525,338 610,450 190,450" stroke="#0D9488" strokeWidth="2" fill="none" opacity="0.6" />
            {/* Water reflections of sky */}
            <line x1="320" y1="375" x2="480" y2="375" stroke="#FDE047" strokeWidth="2" opacity="0.3" />
            <line x1="290" y1="410" x2="510" y2="410" stroke="#FDE047" strokeWidth="2" opacity="0.25" />

            {/* Orange Blossom Tree Silhouettes on banks */}
            <circle cx="210" cy="290" r="38" fill="#133526" />
            <circle cx="240" cy="305" r="30" fill="#0E281D" />
            <circle cx="580" cy="295" r="35" fill="#133526" />
            {/* Tiny glowing orange blossoms */}
            {[
              [195, 275], [220, 285], [205, 305], [235, 315],
              [570, 285], [595, 295], [565, 310]
            ].map(([bx, by], i) => (
              <circle key={i} cx={bx} cy={by} r="2" fill="#FDE68A" opacity="0.9" />
            ))}
          </svg>
        </div>
      )}

      {theme === 'isfahan' && (
        // استان اصفهان: میدان نقش‌جهان، گنبد فیروزه‌ای شیخ لطف‌الله و پل خواجو بر زاینده‌رود
        <div className="absolute inset-0 bg-gradient-to-b from-[#09152E] via-[#122A54] to-[#0A1833]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="isfahanSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#09152E" />
                <stop offset="60%" stopColor="#1B3B6F" />
                <stop offset="100%" stopColor="#3B719F" />
              </linearGradient>
              <linearGradient id="sheikhDome" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#06B6D4" />
                <stop offset="50%" stopColor="#0284C7" />
                <stop offset="100%" stopColor="#0369A1" />
              </linearGradient>
              <linearGradient id="zayandeh" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0284C7" />
                <stop offset="50%" stopColor="#0369A1" />
                <stop offset="100%" stopColor="#082F49" />
              </linearGradient>
              <linearGradient id="brickKhaju" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#78350F" />
                <stop offset="100%" stopColor="#451A03" />
              </linearGradient>
            </defs>

            {/* Isfahan Deep Twilight Sky */}
            <rect width="800" height="450" fill="url(#isfahanSky)" />

            {/* Full Moon illuminating the city */}
            <circle cx="700" cy="70" r="32" fill="#FEF08A" opacity="0.85" />
            <circle cx="700" cy="70" r="55" fill="#FEF08A" opacity="0.15" filter="blur(10px)" />

            {/* Famous Turquoise Sheikh Lotfollah Dome in Background */}
            <g transform="translate(180, 130)">
              <path
                d="M-55,70 C-55,20 -30,-25 0,-35 C30,-25 55,20 55,70 Z"
                fill="url(#sheikhDome)"
              />
              <line x1="0" y1="-35" x2="0" y2="-52" stroke="#FDE047" strokeWidth="2.5" />
              <circle cx="0" cy="-52" r="4" fill="#FDE047" />
              {/* Delicate arabesque pattern hints */}
              <circle cx="0" cy="15" r="28" stroke="#FDE047" strokeWidth="1" fill="none" opacity="0.35" />
              <circle cx="0" cy="15" r="16" stroke="#FDE047" strokeWidth="1" fill="none" opacity="0.35" />
              {/* Portal wall base */}
              <rect x="-70" y="70" width="140" height="35" fill="#1E293B" />
              <path d="M-25,105 Q0,75 25,105 Z" fill="#0F172A" />
            </g>

            {/* Minarets of Naghsh-e Jahan */}
            <rect x="70" y="70" width="12" height="135" fill="#1E293B" />
            <polygon points="66,70 76,45 86,70" fill="#0284C7" />
            <rect x="290" y="70" width="12" height="135" fill="#1E293B" />
            <polygon points="286,70 296,45 306,70" fill="#0284C7" />

            {/* Grand Two-Tiered Historic Khaju Bridge (پل خواجو) */}
            <rect x="0" y="240" width="800" height="95" fill="url(#brickKhaju)" />

            {/* Upper Tier Arches (Small Arches) */}
            {Array.from({ length: 18 }).map((_, i) => (
              <g key={`upper-${i}`} transform={`translate(${i * 44 + 8}, 245)`}>
                <path d="M0,32 Q15,10 30,32 Z" fill="#FDE047" opacity="0.8" />
                <path d="M4,32 Q15,14 26,32 Z" fill="#FEF08A" opacity="0.9" />
              </g>
            ))}

            {/* Lower Tier Main Arches (Grand Water Sluice Arches) */}
            {Array.from({ length: 14 }).map((_, i) => (
              <g key={`lower-${i}`} transform={`translate(${i * 56 + 12}, 285)`}>
                <path d="M0,50 Q22,8 44,50 Z" fill="#0369A1" />
                <path d="M0,50 Q22,8 44,50 Z" stroke="#FBBF24" strokeWidth="1.5" fill="none" opacity="0.7" />
                <rect x="18" y="22" width="8" height="28" fill="#FDE047" opacity="0.85" filter="blur(1px)" />
              </g>
            ))}

            {/* Historic Zayandeh Rood Water with glowing bridge reflections */}
            <rect x="0" y="335" width="800" height="115" fill="url(#zayandeh)" />
            {Array.from({ length: 14 }).map((_, i) => (
              <ellipse
                key={`refl-${i}`}
                cx={i * 56 + 34}
                cy={365}
                rx={16}
                ry={22}
                fill="#FDE047"
                opacity="0.22"
                filter="blur(4px)"
              />
            ))}
            {/* Shimmering water ripples */}
            <path d="M0,380 Q200,370 400,380 T800,380" stroke="#38BDF8" strokeWidth="2" fill="none" opacity="0.4" />
            <path d="M0,410 Q200,400 400,410 T800,410" stroke="#38BDF8" strokeWidth="2.5" fill="none" opacity="0.3" />
          </svg>
        </div>
      )}

      {theme === 'yazd' && (
        // استان یزد: بادگیرهای چهارسویه، بافت خشتی کهن و آسمان پرستاره کویر
        <div className="absolute inset-0 bg-gradient-to-b from-[#070914] via-[#16172E] to-[#2E1810]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="yazdSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#070914" />
                <stop offset="55%" stopColor="#1B1C38" />
                <stop offset="85%" stopColor="#4A261E" />
                <stop offset="100%" stopColor="#7C3B1F" />
              </linearGradient>
              <linearGradient id="adobeBrick" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#8A4822" />
                <stop offset="100%" stopColor="#421C0B" />
              </linearGradient>
            </defs>

            {/* Desert Night Sky */}
            <rect width="800" height="450" fill="url(#yazdSky)" />

            {/* Brilliant Golden Crescent Moon */}
            <path
              d="M660,65 A30,30 0 1 0 705,105 A24,24 0 1 1 660,65 Z"
              fill="#FDE047"
              filter="drop-shadow(0 0 10px rgba(253,224,71,0.5))"
            />

            {/* Glittering Yazd Desert Constellations */}
            {[
              [80, 50], [140, 90], [210, 40], [300, 75], [370, 30], [450, 60],
              [520, 35], [580, 80], [740, 50], [120, 140], [260, 130], [410, 115]
            ].map(([cx, cy], i) => (
              <circle key={i} cx={cx} cy={cy} r={i % 3 === 0 ? 2.2 : 1.3} fill="#FFFBEB" opacity={0.75} />
            ))}

            {/* Ancient Adobe Windcatchers of Yazd (بادگیرهای معروف دولت‌آباد) */}
            {/* Tall Central Windcatcher (بادگیر مرتفع دولت‌آباد) */}
            <g transform="translate(370, 80)">
              <rect x="-35" y="0" width="70" height="190" fill="url(#adobeBrick)" rx="3" />
              {/* Wind Vent Slots */}
              {[-22, -10, 2, 14].map((vx, vi) => (
                <rect key={vi} x={vx} y="15" width="7" height="120" fill="#1C0B04" rx="2" />
              ))}
              {/* Windcatcher Crown */}
              <polygon points="-42,0 0,-18 42,0" fill="#A75A2A" />
              <rect x="-42" y="-3" width="84" height="6" fill="#52240E" />
            </g>

            {/* Left Twin Windcatchers */}
            <g transform="translate(160, 140)">
              <rect x="-24" y="0" width="48" height="140" fill="url(#adobeBrick)" rx="2" />
              {[-16, -4, 8].map((vx, vi) => (
                <rect key={vi} x={vx} y="12" width="6" height="90" fill="#1C0B04" />
              ))}
              <polygon points="-28,0 0,-12 28,0" fill="#A75A2A" />
            </g>

            {/* Right Twin Windcatchers */}
            <g transform="translate(600, 130)">
              <rect x="-26" y="0" width="52" height="150" fill="url(#adobeBrick)" rx="2" />
              {[-18, -6, 6].map((vx, vi) => (
                <rect key={vi} x={vx} y="12" width="6" height="95" fill="#1C0B04" />
              ))}
              <polygon points="-30,0 0,-14 30,0" fill="#A75A2A" />
            </g>

            {/* Historic Domes & Adobe Rooftops of Yazd (کوچه‌های خشتی و گنبدهای آب‌انبار) */}
            {/* Dome 1 (Left) */}
            <path d="M30,300 C30,220 150,220 150,300 Z" fill="#663215" />
            {/* Dome 2 (Center-Left) */}
            <path d="M220,290 C220,190 360,190 360,290 Z" fill="#753918" />
            {/* Dome 3 (Right) */}
            <path d="M440,295 C440,205 580,205 580,295 Z" fill="#663215" />

            {/* Historic Clay Wall Base & Sabat (کوچه‌های مسقف ساباط) */}
            <rect x="0" y="290" width="800" height="160" fill="#3D1A0A" />
            {/* Warm Lantern Windows Glowing in the Night */}
            <rect x="75" y="325" width="22" height="32" fill="#FDE047" opacity="0.85" rx="3" filter="blur(1px)" />
            <rect x="270" y="315" width="26" height="38" fill="#FDE047" opacity="0.9" rx="3" filter="blur(1px)" />
            <rect x="490" y="320" width="24" height="35" fill="#FDE047" opacity="0.85" rx="3" filter="blur(1px)" />
            <rect x="680" y="325" width="22" height="32" fill="#FDE047" opacity="0.85" rx="3" filter="blur(1px)" />

            {/* Silhouette of Sabat Arch (طاق ساباط) */}
            <path d="M330,450 L330,370 Q400,320 470,370 L470,450 Z" fill="#1F0D05" />
          </svg>
        </div>
      )}

      {theme === 'mazandaran' && (
        // استان مازندران: جنگل‌های مه‌آلود هیرکانی، کوهستان البرز و کلبه سنتی چوبی تلار
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A2022] via-[#103433] to-[#081816]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="mazandaranSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0D2E30" />
                <stop offset="60%" stopColor="#184D4A" />
                <stop offset="100%" stopColor="#3A7E74" />
              </linearGradient>
              <linearGradient id="hyrcanianMist" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.06)" />
                <stop offset="50%" stopColor="rgba(255,255,255,0.28)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.06)" />
              </linearGradient>
              <linearGradient id="alborzRidge" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1E4D45" />
                <stop offset="100%" stopColor="#0B231F" />
              </linearGradient>
            </defs>

            {/* Emerald Forest Sky */}
            <rect width="800" height="450" fill="url(#mazandaranSky)" />

            {/* Gentle Morning Sun behind Mountain Mists */}
            <circle cx="280" cy="90" r="45" fill="#FEF08A" opacity="0.3" filter="blur(16px)" />

            {/* Distant Snowcapped Damavand / Alborz Peak Silhouette */}
            <polygon points="180,240 280,105 380,240" fill="#133630" />
            <polygon points="255,140 280,105 305,140" fill="#E2E8F0" opacity="0.65" />

            {/* Rolling Hyrcanian Forest Ridges (جنگل‌های کهن هیرکانی) */}
            <path d="M0,210 Q200,165 420,195 T800,185 L800,450 L0,450 Z" fill="url(#alborzRidge)" />
            {/* Morning Mountain Mist Valley */}
            <rect x="0" y="180" width="800" height="45" fill="url(#hyrcanianMist)" />

            {/* Midground Dense Fir and Beech Woods */}
            <path d="M0,250 Q220,210 460,235 T800,220 L800,450 L0,450 Z" fill="#153B32" />

            {/* Mazandarani Traditional Wooden Stilt Cottage (تلار چوبی مازندرانی) */}
            <g transform="translate(480, 210)">
              {/* Thatch / Wooden Gable Roof */}
              <polygon points="20,70 80,20 140,70" fill="#2E1B0E" />
              {/* Living Chamber */}
              <rect x="35" y="70" width="90" height="40" fill="#442817" />
              {/* Lit Window */}
              <rect x="50" y="78" width="16" height="18" fill="#FDE047" opacity="0.9" />
              <rect x="94" y="78" width="16" height="18" fill="#FDE047" opacity="0.9" />
              {/* Stilts Raising House */}
              <rect x="40" y="110" width="6" height="45" fill="#24140B" />
              <rect x="65" y="110" width="6" height="45" fill="#24140B" />
              <rect x="90" y="110" width="6" height="45" fill="#24140B" />
              <rect x="115" y="110" width="6" height="45" fill="#24140B" />
            </g>

            {/* Foreground Lush Emerald Hills & Tall Pines */}
            <path d="M0,310 Q250,265 520,295 T800,285 L800,450 L0,450 Z" fill="#0E2B24" />
            {/* Majestic Forest Trees */}
            <polygon points="80,310 95,190 110,310" fill="#071915" />
            <polygon points="120,320 135,210 150,320" fill="#0B231E" />
            <polygon points="700,300 718,180 736,300" fill="#071915" />
            <polygon points="740,325 755,220 770,325" fill="#0B231E" />
          </svg>
        </div>
      )}

      {theme === 'baluchestan' && (
        // استان سیستان و بلوچستان: قله آتشفشانی تفتان، قلعه‌های کهن بمپور و نخلستان‌های مکران
        <div className="absolute inset-0 bg-gradient-to-b from-[#1C0904] via-[#3B150A] to-[#1F0A05]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="baluchSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1A0703" />
                <stop offset="45%" stopColor="#4A180C" />
                <stop offset="75%" stopColor="#9C3B17" />
                <stop offset="100%" stopColor="#DE7B35" />
              </linearGradient>
              <linearGradient id="taftanPeak" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#752912" />
                <stop offset="100%" stopColor="#300E06" />
              </linearGradient>
            </defs>

            {/* Fiery Desert Sunset Sky */}
            <rect width="800" height="450" fill="url(#baluchSky)" />

            {/* Glowing Golden Evening Sun */}
            <circle cx="480" cy="140" r="50" fill="#FDE047" opacity="0.85" />
            <circle cx="480" cy="140" r="85" fill="#F97316" opacity="0.25" filter="blur(14px)" />

            {/* Mount Taftan Volcano in Distance (قله آتشفشانی تفتان) */}
            <polygon points="340,240 480,95 620,240" fill="url(#taftanPeak)" />
            {/* White steam plume from Taftan summit */}
            <ellipse cx="480" cy="85" rx="25" ry="10" fill="#FEF3C7" opacity="0.45" filter="blur(4px)" />
            <ellipse cx="495" cy="72" rx="35" ry="14" fill="#FEF3C7" opacity="0.3" filter="blur(6px)" />

            {/* Ancient Citadel Fortress (قلعه بمپور / کهن دژ بلوچستان) */}
            <g transform="translate(140, 185)">
              <rect x="0" y="30" width="160" height="75" fill="#421408" rx="2" />
              {/* Battlements & Watchtowers */}
              <rect x="-10" y="10" width="28" height="95" fill="#521A0A" />
              <rect x="142" y="10" width="28" height="95" fill="#521A0A" />
              <polygon points="-12,10 4,-5 20,10" fill="#6A230F" />
              <polygon points="140,10 156,-5 172,10" fill="#6A230F" />
              {/* Crenellations */}
              {[15, 35, 55, 75, 95, 115, 135].map((cx, i) => (
                <rect key={i} x={cx} y="22" width="10" height="12" fill="#521A0A" />
              ))}
              {/* Fortress Gate Arch */}
              <path d="M60,105 Q80,70 100,105 Z" fill="#1A0602" />
            </g>

            {/* Makran Desert Dunes (تپه‌های طلایی بلوچستان) */}
            <path d="M0,270 Q220,230 460,260 T800,245 L800,450 L0,450 Z" fill="#3D1206" />

            {/* Majestic Date Palm Groves (نخلستان‌های سرفراز بمپور و سراوان) */}
            {[50, 110, 680, 740].map((px, i) => (
              <g key={i} transform={`translate(${px}, 240)`}>
                <path d="M10,130 Q14,60 10,0" stroke="#240A04" strokeWidth="8" fill="none" />
                {/* Palm fronds */}
                {[-50, -25, 0, 25, 50].map((ang, idx) => (
                  <path
                    key={idx}
                    d={`M10,0 Q${10 + ang},${-25} ${10 + ang * 1.5},${15}`}
                    stroke="#140602"
                    strokeWidth="3.5"
                    fill="none"
                  />
                ))}
              </g>
            ))}

            {/* Desert Caravan Silhouette */}
            <g transform="translate(320, 310)" fill="#140602">
              <ellipse cx="20" cy="20" rx="14" ry="9" />
              <ellipse cx="26" cy="11" rx="6" ry="6" />
              <circle cx="28" cy="6" r="3" />
              <line x1="12" y1="28" x2="10" y2="44" stroke="#140602" strokeWidth="2.5" />
              <line x1="26" y1="28" x2="28" y2="44" stroke="#140602" strokeWidth="2.5" />
            </g>
          </svg>
        </div>
      )}

      {theme === 'khuzestan' && (
        // استان خوزستان: پل سفید اهواز، رود پرخروش کارون، نخل‌های سرسبز و پرواز مرغان دریایی
        <div className="absolute inset-0 bg-gradient-to-b from-[#1C0A04] via-[#4A170A] to-[#1A0B05]">
          <svg
            className="absolute inset-0 w-full h-full object-cover"
            viewBox="0 0 800 450"
            preserveAspectRatio="xMidYMid slice"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="khuzestanSky" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1E0A04" />
                <stop offset="50%" stopColor="#6B1F0B" />
                <stop offset="80%" stopColor="#D9571E" />
                <stop offset="100%" stopColor="#FBBF24" />
              </linearGradient>
              <linearGradient id="karunRiver" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#D9571E" />
                <stop offset="40%" stopColor="#7C2D12" />
                <stop offset="100%" stopColor="#1C0A04" />
              </linearGradient>
            </defs>

            {/* Karun Sunset Sky */}
            <rect width="800" height="450" fill="url(#khuzestanSky)" />

            {/* Glowing Sunset Orb over Karun */}
            <circle cx="380" cy="150" r="55" fill="#FEF08A" opacity="0.9" />
            <circle cx="380" cy="150" r="95" fill="#F97316" opacity="0.3" filter="blur(16px)" />

            {/* Soaring River Gulls */}
            {[
              [240, 110], [290, 95], [330, 125], [440, 105], [510, 120]
            ].map(([gx, gy], i) => (
              <path
                key={i}
                d={`M${gx - 12},${gy + 4} Q${gx - 6},${gy - 6} ${gx},${gy} Q${gx + 6},${gy - 6} ${gx + 12},${gy + 4}`}
                stroke="#451A03"
                strokeWidth="2"
                fill="none"
              />
            ))}

            {/* Iconic Ahvaz White Bridge (پل سفید اهواز بر فراز کارون) */}
            <g transform="translate(0, 175)">
              {/* Grand Steel Arch 1 (Left) */}
              <path
                d="M40,75 Q200,-35 360,75"
                stroke="#FFFFFF"
                strokeWidth="7"
                fill="none"
                opacity="0.95"
              />
              {/* Arch Steel Suspension Ribs 1 */}
              {[90, 140, 190, 240, 290].map((sx, i) => (
                <line key={i} x1={sx} y1={25} x2={sx} y2={75} stroke="#E2E8F0" strokeWidth="2" opacity="0.75" />
              ))}

              {/* Grand Steel Arch 2 (Right) */}
              <path
                d="M420,75 Q580,-35 740,75"
                stroke="#FFFFFF"
                strokeWidth="7"
                fill="none"
                opacity="0.95"
              />
              {/* Arch Steel Suspension Ribs 2 */}
              {[470, 520, 570, 620, 670].map((sx, i) => (
                <line key={i} x1={sx} y1={25} x2={sx} y2={75} stroke="#E2E8F0" strokeWidth="2" opacity="0.75" />
              ))}

              {/* Bridge Deck Span */}
              <rect x="0" y="75" width="800" height="12" fill="#E2E8F0" />
              <rect x="0" y="85" width="800" height="5" fill="#475569" />
              {/* Bridge Concrete Piers */}
              <rect x="360" y="85" width="60" height="50" fill="#334155" />
              <rect x="20" y="85" width="30" height="50" fill="#334155" />
              <rect x="740" y="85" width="30" height="50" fill="#334155" />
            </g>

            {/* Glowing Golden Waters of Karun River (رود خروشان کارون) */}
            <rect x="0" y="270" width="800" height="180" fill="url(#karunRiver)" />
            {/* Golden light reflections on water */}
            <polygon points="340,270 420,270 480,450 280,450" fill="#FDE047" opacity="0.35" filter="blur(8px)" />
            <path d="M0,320 Q200,310 400,320 T800,320" stroke="#FDE047" strokeWidth="3" fill="none" opacity="0.5" />
            <path d="M0,360 Q200,350 400,360 T800,360" stroke="#F97316" strokeWidth="3" fill="none" opacity="0.4" />
            <path d="M0,405 Q200,395 400,405 T800,405" stroke="#EA580C" strokeWidth="3.5" fill="none" opacity="0.5" />

            {/* Tropical Date Palm Silhouettes along River Bank */}
            {[40, 100, 700, 760].map((px, i) => (
              <g key={i} transform={`translate(${px}, 270)`}>
                <path d="M10,130 Q15,60 10,0" stroke="#1A0602" strokeWidth="8" fill="none" />
                {[-45, -20, 0, 20, 45].map((ang, idx) => (
                  <path
                    key={idx}
                    d={`M10,0 Q${10 + ang},${-25} ${10 + ang * 1.5},${15}`}
                    stroke="#140401"
                    strokeWidth="3.5"
                    fill="none"
                  />
                ))}
              </g>
            ))}
          </svg>
        </div>
      )}

      {theme === 'classic' && (
        // تم رادیوی کلاسیک چایخانه
        <div className="absolute inset-0 bg-gradient-to-b from-[#2E1508] via-[#1E0D05] to-[#140803]" />
      )}

      {/* Atmospheric Vignette & Warm Teahouse Glow Overlay */}
      {showOverlay && (
        <>
          <div className="absolute inset-0 bg-gradient-to-t from-[#140A04]/90 via-transparent to-[#140A04]/40 pointer-events-none" />
          <div className="absolute inset-0 shadow-[inset_0_0_40px_rgba(0,0,0,0.7)] pointer-events-none" />
        </>
      )}
    </div>
  );
};
