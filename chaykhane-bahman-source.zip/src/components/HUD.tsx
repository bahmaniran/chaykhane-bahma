import React, { useState, useEffect } from 'react';
import {
  Menu,
  Trophy,
  User,
  UserCheck,
  HelpCircle,
} from 'lucide-react';
import { toPersianDigits, formatPersianCoins } from '../utils/persianNumbers';
import { PlayerProfile } from '../types';

interface HUDProps {
  currentLevel: number;
  coins: number;
  levelProgressPercent: number;
  unlockAll: boolean;
  isDebtActive?: boolean;
  debtStreakLeft?: number;
  playerProfile?: PlayerProfile;
  onOpenMenu: () => void;
  onOpenGuide?: () => void;
  onOpenSettings?: () => void;
  onOpenRegister?: () => void;
  onOpenNeighborhood?: () => void;
  onOpenCounterDrawer: () => void;
  onOpenHavaleh?: () => void;
  onOpenDaftarHesab: () => void;
  onToggleUnlockAll?: () => void;
  hasDailyRewardAvailable?: boolean;
  hasUnclaimedWeekly?: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  currentLevel,
  coins,
  levelProgressPercent,
  unlockAll,
  isDebtActive = false,
  debtStreakLeft = 3,
  playerProfile,
  onOpenMenu,
  onOpenGuide,
  onOpenSettings,
  onOpenRegister,
  onOpenNeighborhood,
  onOpenCounterDrawer,
  onOpenDaftarHesab,
  hasDailyRewardAvailable,
  hasUnclaimedWeekly,
}) => {
  const isLevel3Unlocked = unlockAll || currentLevel >= 3;
  const isRegistered = playerProfile?.isRegistered && playerProfile.firstName;


  return (
    <header
      className="relative w-full px-2 sm:px-3 pb-1 z-30 select-none transition-all duration-300"
      style={{
        paddingTop: 'calc(env(safe-area-inset-top, 0px) + 0.35rem)',
      }}
    >
      {/* Top Ergonomic Control Bar: Clean clearance with zero notch collision on old & new devices */}
      <div className="flex items-center justify-between px-0.5 mb-1 sm:mb-1.5 text-[11px] gap-1 sm:gap-1.5 flex-nowrap overflow-x-auto no-scrollbar">
        {/* Right side: Main Menu, Leaderboard & Guide */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Main Menu Button */}
          <button
            onClick={onOpenMenu}
            className="px-2.5 sm:px-3 py-1.5 rounded-full bg-gradient-to-r from-[#3D1E0C] via-[#2A1408] to-[#1F0D05] hover:brightness-125 border-2 border-[#D97706]/80 hover:border-yellow-400 text-yellow-200 flex items-center gap-1.5 font-lalezar text-[11px] sm:text-xs shadow-md transition-all active:scale-95 cursor-pointer relative"
            title="منوی اصلی چایخانه، تنظیمات، صدا و حالت شب"
          >
            <Menu className="w-3.5 h-3.5 text-yellow-400" />
            <span>منو</span>
            {(hasDailyRewardAvailable || hasUnclaimedWeekly) && (
              <span className="w-2 h-2 rounded-full bg-yellow-400 animate-ping absolute -top-0.5 -right-0.5" />
            )}
          </button>

          {/* Guide / Help Button (راهنما) */}
          {onOpenGuide && (
            <button
              onClick={onOpenGuide}
              className="px-2 sm:px-2.5 py-1.5 rounded-full bg-gradient-to-r from-[#2F1F10] to-[#1C120A] hover:brightness-125 border border-yellow-500/80 text-yellow-300 flex items-center gap-1 font-lalezar text-[11px] sm:text-xs shadow-md transition-all active:scale-95 cursor-pointer"
              title="آموزش قوانین بازی و راهنما"
            >
              <HelpCircle className="w-3.5 h-3.5 text-yellow-400" />
              <span>راهنما</span>
            </button>
          )}

          {/* Leaderboard / Competitors Table Button (جدول رقبا) */}
          {onOpenNeighborhood && (
            <button
              onClick={onOpenNeighborhood}
              className="px-2 sm:px-2.5 py-1.5 rounded-full bg-gradient-to-r from-[#17382B] via-[#0E281F] to-[#0A1D16] hover:brightness-125 border border-emerald-500/80 text-emerald-200 flex items-center gap-1 font-lalezar text-[11px] sm:text-xs shadow-md transition-all active:scale-95 cursor-pointer"
              title="جدول رقبا بر اساس کشور، استان و شهر"
            >
              <Trophy className="w-3.5 h-3.5 text-yellow-400" />
              <span>جدول رقبا</span>
            </button>
          )}

          {/* Diegetic Counter Drawer (میز دخل عمو بهمن) - Unlocked Level 3+ */}
          {isLevel3Unlocked && (
            <button
              onClick={onOpenCounterDrawer}
              className="px-2 sm:px-2.5 py-1.5 rounded-full bg-gradient-to-r from-[#4A2612] via-[#351909] to-[#240F05] hover:brightness-125 border border-amber-500/70 text-amber-200 flex items-center gap-1 font-lalezar text-[11px] sm:text-xs shadow-md transition-all active:scale-95 cursor-pointer relative"
              title="میز دخل، انعام و امکانات ویژه عمو بهمن"
            >
              <span>🧮</span>
              <span className="hidden xs:inline">دخل</span>
              {/* Debt indicator */}
              {isDebtActive && (
                <span
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenDaftarHesab();
                  }}
                  className="px-1.5 py-0.5 rounded-full bg-red-900/90 border border-red-500/90 text-red-200 text-[10px] font-sans font-bold animate-pulse shadow"
                  title={`دفتر حساب: ${toPersianDigits(debtStreakLeft)} برد مانده تا تسویه نسیه`}
                >
                  نسیه
                </span>
              )}
            </button>
          )}
        </div>

        {/* Left side: Membership Box (باکس عضویت) */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {(onOpenRegister || onOpenSettings) && (
            <button
              onClick={onOpenRegister || onOpenSettings}
              className={`px-2.5 sm:px-3 py-1.5 rounded-full flex items-center gap-1.5 font-lalezar text-[11px] sm:text-xs shadow-md transition-all active:scale-95 cursor-pointer border ${
                isRegistered
                  ? 'bg-gradient-to-r from-[#1E3A5F] via-[#12253E] to-[#0A1626] border-sky-400 text-sky-200 hover:brightness-110'
                  : 'bg-gradient-to-r from-amber-600 via-yellow-600 to-amber-700 border-yellow-300 text-stone-950 font-bold hover:brightness-110'
              }`}
              title="باکس عضویت: ثبت نام، نام خانوادگی، شهر، استان و تصویر شاخص"
            >
              {isRegistered ? (
                <>
                  <UserCheck className="w-3.5 h-3.5 text-sky-300" />
                  <span className="max-w-[70px] truncate">{playerProfile?.firstName}</span>
                </>
              ) : (
                <>
                  <User className="w-3.5 h-3.5 text-stone-950" />
                  <span>باکس عضویت</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Main HUD Bar: Level Pill, 3D Title, Coins */}
      <div className="relative flex items-center justify-between gap-1 sm:gap-2 mt-0.5">
        {/* Left: Burnt Wood Pill with Persian Turquoise Inlay for Level + Star Progress Bar */}
        <div className="flex flex-col items-start min-w-[70px] sm:min-w-[95px]">
          <div className="flex items-center justify-center px-2.5 sm:px-3.5 py-0.5 sm:py-1 rounded-full bg-gradient-to-b from-[#33180B] via-[#241107] to-[#160A03] border-2 border-[#0D9488]/80 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_10px_rgba(13,148,136,0.35)]">
            <span className="font-lalezar text-xs sm:text-base text-amber-100 tracking-wide drop-shadow">
              مرحله {toPersianDigits(currentLevel)}
            </span>
          </div>

          {/* Star Progress Bar with Turquoise Track */}
          <div className="flex items-center gap-1 mt-0.5 sm:mt-1 pr-0.5">
            <div className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-[9px] sm:text-[10px] text-amber-950 font-bold shadow-sm">
              ★
            </div>
            <div className="w-12 sm:w-16 h-1.5 sm:h-2 bg-[#172B28] rounded-full overflow-hidden border border-[#0D9488]/60">
              <div
                className="h-full bg-gradient-to-r from-teal-500 via-amber-400 to-yellow-300 rounded-full transition-all duration-500 shadow-[0_0_6px_rgba(13,148,136,0.8)]"
                style={{ width: `${Math.max(20, Math.min(100, levelProgressPercent))}%` }}
              />
            </div>
          </div>
        </div>

        {/* Center: Glowing Ornate Golden 3D Title ﴿ چایخانه عمو بهمن ﴾ with Turquoise Accents */}
        <div className="flex-1 flex flex-col items-center justify-center min-w-0">
          <div className="flex items-center gap-1 filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.9)]">
            <span className="text-teal-400 text-xs sm:text-sm font-lalezar select-none">❧</span>
            <h1 className="font-lalezar text-sm sm:text-xl text-transparent bg-clip-text bg-gradient-to-b from-[#FFF3B0] via-[#FFD15C] to-[#E68A00] tracking-wider drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] truncate">
              چایخانه عمو بهمن
            </h1>
            <span className="text-teal-400 text-xs sm:text-sm font-lalezar select-none">☙</span>
          </div>
        </div>

        {/* Right: Coin Counter with Golden Star Coin & Persian Turquoise Frame */}
        <div className="flex items-center justify-end min-w-[70px] sm:min-w-[95px]">
          <button
            onClick={onOpenCounterDrawer}
            className="flex items-center gap-1 sm:gap-2 px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full bg-gradient-to-b from-[#33180B] via-[#241107] to-[#160A03] border-2 border-[#0D9488]/80 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6),0_4px_10px_rgba(13,148,136,0.35)] hover:border-yellow-400 active:scale-95 transition-all cursor-pointer"
            title="موجودی سکه طلا (کلیک برای باز کردن دخل و حواله)"
          >
            <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-gradient-to-tr from-[#FFD700] via-[#F59E0B] to-[#D97706] border border-[#FFF3B0] flex items-center justify-center text-amber-950 text-[10px] sm:text-xs font-black shadow-[0_0_8px_rgba(255,215,0,0.7)] animate-pulse">
              ★
            </div>
            <span className="font-lalezar text-xs sm:text-base text-yellow-300 drop-shadow">
              {formatPersianCoins(coins)}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
