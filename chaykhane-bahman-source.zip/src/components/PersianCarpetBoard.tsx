import React, { useState } from 'react';
import { toPersianDigits } from '../utils/persianNumbers';

export interface CarpetTheme {
  id: string;
  name: string;
  origin: string;
  knotCount: string;
  description: string;
  primaryColor: string;
  accentColor: string;
  borderColor: string;
  fieldGradient: string;
  innerBorderColor: string;
  fringeColor: string;
  toranjType: 'floral' | 'geometric' | 'kheshti' | 'silk';
}

export const PERSIAN_CARPET_THEMES: CarpetTheme[] = [
  {
    id: 'kashan_shah_abbasi',
    name: 'قالی لاکی شاه‌عباسی کاشان',
    origin: 'کاشان - دوره صفوی',
    knotCount: '۷۰ رج ابریشم',
    description: 'ترنج شاه‌عباسی با بته‌جقه‌های اصیل، گل‌های ختایی و رنگ لاکی درباری',
    primaryColor: '#881337', // Deep rose-red/crimson
    accentColor: '#FDE047',
    borderColor: '#4C0519',
    fieldGradient: 'radial-gradient(ellipse at center, #9F1239 0%, #881337 45%, #4C0519 100%)',
    innerBorderColor: '#0F172A', // Navy guard
    fringeColor: '#FEF3C7',
    toranjType: 'floral',
  },
  {
    id: 'isfahan_turquoise_silk',
    name: 'قالی فیروزه‌ای ابریشم اصفهان',
    origin: 'میدان نقش‌جهان اصفهان',
    knotCount: '۸۵ رج تمام ابریشم',
    description: 'نقش ترنج فیروزه‌ای و زرین با اسلیمی‌های مینیاتوری الهام از گنبد مسجد شیخ لطف‌الله',
    primaryColor: '#0E7490', // Persian Turquoise
    accentColor: '#F59E0B',
    borderColor: '#155E75',
    fieldGradient: 'radial-gradient(ellipse at center, #06B6D4 0%, #0891B2 45%, #164E63 100%)',
    innerBorderColor: '#1E1B4B',
    fringeColor: '#FFFBEB',
    toranjType: 'silk',
  },
  {
    id: 'tabriz_antique_maroon',
    name: 'قالی زرشکی و عتیقه تبریز',
    origin: 'بازار مظفریه تبریز',
    knotCount: '۸۰ رج ریزبافت',
    description: 'طرح لچک و ترنج تاریخی با بوم زرشکی درباری و حاشیه کتیبه‌ای زراندود',
    primaryColor: '#4A0404', // Antique Maroon
    accentColor: '#FBBF24',
    borderColor: '#2B0404',
    fieldGradient: 'radial-gradient(ellipse at center, #7F1D1D 0%, #5B0F15 50%, #30070B 100%)',
    innerBorderColor: '#1E293B',
    fringeColor: '#FEF9C3',
    toranjType: 'floral',
  },
  {
    id: 'nain_ivory_imperial',
    name: 'قالی کرم و عاجی سلطنتی نایین',
    origin: 'نایین اصفهان',
    knotCount: '۶ لا ابریشم سفید',
    description: 'بوم کرم و عاجی بسیار چشم‌نواز با گل‌های نیلوفر آبی و حاشیه سرمه‌ای متقارن',
    primaryColor: '#78350F', // Warm golden-cream base
    accentColor: '#38BDF8',
    borderColor: '#1E1B4B',
    fieldGradient: 'radial-gradient(ellipse at center, #5A3018 0%, #431E0D 50%, #251006 100%)',
    innerBorderColor: '#0369A1',
    fringeColor: '#FFFBEB',
    toranjType: 'silk',
  },
  {
    id: 'kerman_jade_green',
    name: 'قالی سبز یشمی و زمردی کرمان',
    origin: 'کرمان - طرح راور',
    knotCount: '۶۵ رج پشم ظریف',
    description: 'طرح باغ بهشت با بوم سبز یشمی سیر، ترنج عنابی و گل‌های سرخ درباری',
    primaryColor: '#064E3B', // Deep Emerald
    accentColor: '#FDE047',
    borderColor: '#022C22',
    fieldGradient: 'radial-gradient(ellipse at center, #047857 0%, #064E3B 50%, #022C22 100%)',
    innerBorderColor: '#831843',
    fringeColor: '#F0FDF4',
    toranjType: 'floral',
  },
  {
    id: 'bakhtiari_garden_kheshti',
    name: 'قالی خشتی گلستان بختیاری',
    origin: 'چهارمحال و بختیاری',
    knotCount: '۵۰ رج سنتی',
    description: 'نقش اصیل خشتی با قاب‌های باغ بهشت، سروهای سرسبز و پرندگان بهشتی',
    primaryColor: '#7C2D12', // Terracotta Red
    accentColor: '#F59E0B',
    borderColor: '#431407',
    fieldGradient: 'radial-gradient(ellipse at center, #7C2D12 0%, #561D0A 50%, #2E0E04 100%)',
    innerBorderColor: '#0C4A6E',
    fringeColor: '#FEF3C7',
    toranjType: 'kheshti',
  },
  {
    id: 'qashqai_tribal_kilim',
    name: 'گلیم و قالی هندسی قشقایی',
    origin: 'فارس و شیراز - ایل قشقایی',
    knotCount: 'دستباف با تار پشمی',
    description: 'ترنج‌های پلکانی هندسی با رنگ‌های طبیعی روناس و نیل، بافته شیرزنان عشایر',
    primaryColor: '#991B1B', // Rich Madder Red
    accentColor: '#0284C7',
    borderColor: '#450A0A',
    fieldGradient: 'radial-gradient(ellipse at center, #991B1B 0%, #701313 50%, #350808 100%)',
    innerBorderColor: '#B45309',
    fringeColor: '#FEF08A',
    toranjType: 'geometric',
  },
  {
    id: 'heriz_heritage_cobalt',
    name: 'قالی شاهکار لاجوردی هریس',
    origin: 'هریس آذربایجان',
    knotCount: '۶۰ رج پشم گوسفندی',
    description: 'خطوط شکسته هندسی با ترنج بزرگ شمسه و رنگ لاجوردی و مسی با صلابت پهلوانی',
    primaryColor: '#1E3A8A', // Cobalt Blue
    accentColor: '#EA580C',
    borderColor: '#0F172A',
    fieldGradient: 'radial-gradient(ellipse at center, #1E40AF 0%, #1E3A8A 50%, #0B132B 100%)',
    innerBorderColor: '#9A3412',
    fringeColor: '#FFFBEB',
    toranjType: 'geometric',
  },
];

interface PersianCarpetBoardProps {
  currentLevel: number;
  isNightMode?: boolean;
  children: React.ReactNode;
}

export const PersianCarpetBoard: React.FC<PersianCarpetBoardProps> = React.memo(({
  currentLevel,
  isNightMode = false,
  children,
}) => {
  // Carpet shifts smoothly every 5 levels
  const carpetTier = Math.floor(Math.max(0, currentLevel - 1) / 5);
  const carpetIndex = carpetTier % PERSIAN_CARPET_THEMES.length;
  const currentCarpet = PERSIAN_CARPET_THEMES[carpetIndex];

  const minLevelInTier = carpetTier * 5 + 1;
  const maxLevelInTier = (carpetTier + 1) * 5;

  // Persistent tracking so the intro banner ONLY appears ONCE for 10s per carpet tier, never repeatedly
  const storageKey = `seen_carpet_intro_${currentCarpet.id}`;
  const [showIntroBanner, setShowIntroBanner] = useState<boolean>(() => {
    try {
      return localStorage.getItem(storageKey) !== 'true';
    } catch {
      return false;
    }
  });

  React.useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    try {
      const alreadySeen = localStorage.getItem(storageKey) === 'true';
      if (alreadySeen) {
        setShowIntroBanner(false);
        return;
      }
      setShowIntroBanner(true);
      localStorage.setItem(storageKey, 'true');
      timer = setTimeout(() => {
        setShowIntroBanner(false);
      }, 10000); // exactly 10 seconds, then completely removed from DOM
    } catch {
      setShowIntroBanner(false);
    }

    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [currentCarpet.id, storageKey]);

  return (
    <div className="relative w-full max-w-[425px] sm:max-w-[465px] md:max-w-[495px] mx-auto px-1 sm:px-2 select-none">
      {/* Non-intrusive Intro Floating Banner: ONLY shown ONCE per carpet tier for 10s, positioned completely ABOVE the board so cups are never covered */}
      {showIntroBanner && (
        <div className="w-[94%] max-w-[390px] mx-auto mb-1.5 z-40 flex items-center justify-between px-3 py-1 rounded-full bg-[#180A04]/95 border border-amber-400 text-amber-200 shadow-2xl backdrop-blur-md animate-fade-in transition-all">
          <div className="flex items-center gap-1.5 overflow-hidden">
            <span className="text-sm">🧶</span>
            <span className="font-lalezar text-[11px] sm:text-xs text-yellow-300 whitespace-nowrap">
              {currentCarpet.name}
            </span>
            <span className="text-[9px] text-amber-300/80 font-vazir truncate hidden xs:inline">
              ({currentCarpet.origin})
            </span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[9px] font-lalezar text-amber-300 bg-amber-950/80 border border-amber-600/70 px-1.5 py-0.5 rounded-md">
              مرحله {toPersianDigits(minLevelInTier)} تا {toPersianDigits(maxLevelInTier)}
            </span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowIntroBanner(false);
              }}
              className="w-5 h-5 rounded-full bg-amber-900/80 hover:bg-amber-800 text-amber-200 text-xs flex items-center justify-center cursor-pointer transition-colors active:scale-90"
              title="بستن"
              aria-label="بستن معرفی قالی"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* 1. Subtle Wooden Table Edge beneath Carpet */}
      <div className="absolute -inset-x-2 -bottom-2.5 h-6 bg-gradient-to-b from-[#2E1609] to-[#160B04] rounded-[34px] shadow-2xl border-t border-[#542B14] pointer-events-none" />

      {/* 2. Top Handwoven Carpet Fringes (ریشه‌های ابریشمی بالای قالیچه) */}
      <div className="relative w-[92%] mx-auto h-2 sm:h-2.5 overflow-hidden flex items-start justify-between px-1 pointer-events-none z-10">
        {Array.from({ length: 42 }).map((_, i) => (
          <div
            key={`top-fringe-${i}`}
            className="w-[1.8px] sm:w-[2.2px] h-full rounded-b-xs shadow-xs"
            style={{
              backgroundColor: i % 4 === 0 ? '#E2D9C8' : currentCarpet.fringeColor,
              opacity: 0.85 + (i % 3) * 0.05,
              transform: `rotate(${(i % 5 - 2) * 1.5}deg)`,
            }}
          />
        ))}
      </div>

      {/* 3. Main Persian Carpet Board Body (No click interceptors so user can freely play) */}
      <div
        className="relative w-full rounded-[30px] xs:rounded-[34px] sm:rounded-[38px] p-2 xs:p-2.5 sm:p-3 pb-4 xs:pb-5 sm:pb-6 flex flex-col items-center justify-center transition-all duration-700 overflow-hidden shadow-[0_16px_36px_rgba(0,0,0,0.85),inset_0_2px_12px_rgba(255,255,255,0.15)] border-4 sm:border-[5px]"
        style={{
          background: currentCarpet.fieldGradient,
          borderColor: currentCarpet.borderColor,
          boxShadow: isNightMode
            ? `0 14px 32px rgba(0,0,0,0.9), inset 0 0 45px rgba(0,0,0,0.65), 0 0 16px ${currentCarpet.primaryColor}40`
            : `0 16px 36px rgba(0,0,0,0.85), inset 0 0 35px rgba(0,0,0,0.45), 0 0 20px ${currentCarpet.primaryColor}55`,
        }}
      >
        {/* Authentic Carpet Texture Micro-Grid (بافت تار و پود دستباف) */}
        <div
          className="absolute inset-0 pointer-events-none opacity-25"
          style={{
            backgroundImage: `radial-gradient(circle at 1.5px 1.5px, ${currentCarpet.accentColor} 0.6px, transparent 0)`,
            backgroundSize: '5px 5px',
          }}
        />

        {/* Outer Guard Border with Intricate Rosette Stitching (حاشیه بیرونی شیرازه) */}
        <div
          className="absolute inset-1.5 xs:inset-2 sm:inset-2.5 rounded-[24px] xs:rounded-[28px] sm:rounded-[32px] border-2 sm:border-[2.5px] pointer-events-none"
          style={{
            borderColor: currentCarpet.innerBorderColor,
            boxShadow: `inset 0 0 6px rgba(0,0,0,0.6), 0 0 4px ${currentCarpet.accentColor}40`,
          }}
        />

        {/* Main Persian Floral Arabesque Border (حاشیه اصلی با نقش اسلیمی و ختایی) */}
        <div
          className="absolute inset-3 xs:inset-3.5 sm:inset-4 rounded-[20px] xs:rounded-[24px] sm:rounded-[27px] border-2 border-dashed pointer-events-none flex items-center justify-between overflow-hidden"
          style={{
            borderColor: `${currentCarpet.accentColor}80`,
          }}
        >
          {/* Subtle Corner Medallions (لچک‌های چهارگوشه قالی) */}
          <div className="absolute top-0 left-0 w-12 sm:w-16 h-12 sm:h-16 border-r-2 border-b-2 rounded-br-3xl pointer-events-none" style={{ borderColor: `${currentCarpet.accentColor}60`, backgroundColor: `${currentCarpet.innerBorderColor}40` }} />
          <div className="absolute top-0 right-0 w-12 sm:w-16 h-12 sm:h-16 border-l-2 border-b-2 rounded-bl-3xl pointer-events-none" style={{ borderColor: `${currentCarpet.accentColor}60`, backgroundColor: `${currentCarpet.innerBorderColor}40` }} />
          <div className="absolute bottom-0 left-0 w-12 sm:w-16 h-12 sm:h-16 border-r-2 border-t-2 rounded-tr-3xl pointer-events-none" style={{ borderColor: `${currentCarpet.accentColor}60`, backgroundColor: `${currentCarpet.innerBorderColor}40` }} />
          <div className="absolute bottom-0 right-0 w-12 sm:w-16 h-12 sm:h-16 border-l-2 border-t-2 rounded-tl-3xl pointer-events-none" style={{ borderColor: `${currentCarpet.accentColor}60`, backgroundColor: `${currentCarpet.innerBorderColor}40` }} />
        </div>

        {/* Center Grand Toranj Medallion (ترنج بزرگ مرکز قالی با گل شاه‌عباسی و شمسه) */}
        <div className="absolute inset-7 xs:inset-8 sm:inset-10 rounded-[28px] pointer-events-none flex items-center justify-center">
          {currentCarpet.toranjType === 'kheshti' ? (
            /* Bakhtiari Kheshti Garden Panel Inlay */
            <div className="w-full h-full grid grid-cols-4 grid-rows-2 gap-1.5 opacity-25 p-2 border border-amber-300/30 rounded-2xl">
              {Array.from({ length: 8 }).map((_, idx) => (
                <div
                  key={`panel-${idx}`}
                  className="rounded-lg border border-yellow-200/40 flex items-center justify-center text-xs text-amber-200/60 font-lalezar"
                  style={{
                    backgroundColor: idx % 2 === 0 ? '#1E3A8A33' : '#064E3B33',
                  }}
                >
                  {idx % 2 === 0 ? '🌲' : '🌺'}
                </div>
              ))}
            </div>
          ) : currentCarpet.toranjType === 'geometric' ? (
            /* Qashqai & Heriz Stepped Diamond Medallion */
            <div className="relative w-36 sm:w-44 h-36 sm:h-44 rotate-45 border-2 border-amber-300/40 rounded-xl bg-gradient-to-br from-amber-400/10 via-transparent to-black/20 flex items-center justify-center pointer-events-none">
              <div className="w-24 h-24 border border-dashed border-amber-200/50 rounded-lg flex items-center justify-center">
                <span className="text-3xl text-amber-200/35 font-lalezar select-none -rotate-45">❖</span>
              </div>
            </div>
          ) : (
            /* Classic Kashan / Isfahan / Tabriz Ornate Royal Toranj */
            <div className="relative w-36 sm:w-44 h-36 sm:h-44 rounded-full border-2 border-amber-300/40 flex items-center justify-center bg-gradient-to-radial from-amber-400/15 via-transparent to-black/25 pointer-events-none">
              {/* Petals / Rays Ring */}
              <div className="absolute inset-2 rounded-full border border-dashed border-amber-200/40 animate-spin-very-slow" />
              {/* Center Medallion Star */}
              <div className="w-20 sm:w-24 h-20 sm:h-24 rounded-full border-2 border-amber-400/50 bg-[#0F172A]/40 flex flex-col items-center justify-center shadow-lg">
                <span className="text-amber-200/50 text-2xl sm:text-3xl font-lalezar select-none">𖣔</span>
                <span className="text-[8px] text-amber-300/60 font-lalezar tracking-widest mt-0.5">دستباف</span>
              </div>
            </div>
          )}
        </div>

        {/* Ambient Warm Glare on Carpet Velvet Sheen */}
        <div className="absolute top-0 inset-x-8 h-8 rounded-full bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />

        {/* Estekans Container: Balanced 2-Row / 1-Row Grid with Perspective Elevation */}
        {(() => {
          const childrenArray = React.Children.toArray(children);
          const isMultiRow = childrenArray.length >= 6;
          const backRowCount = isMultiRow ? Math.ceil(childrenArray.length / 2) : childrenArray.length;
          const backRowCups = isMultiRow ? childrenArray.slice(0, backRowCount) : childrenArray;
          const frontRowCups = isMultiRow ? childrenArray.slice(backRowCount) : [];

          return isMultiRow ? (
            <div className="relative z-20 w-full flex flex-col items-center justify-center gap-y-2.5 xs:gap-y-3 sm:gap-y-4 pt-1 pb-1.5 xs:pb-2">
              {/* Back Row (Elevated Perspective - 100% Unobstructed) */}
              <div className="w-full flex items-end justify-center gap-x-1.5 xs:gap-x-2.5 sm:gap-x-4 z-10">
                {backRowCups}
              </div>
              {/* Front Row (Staggered naturally in the gaps of the back row) */}
              <div className="w-full flex items-end justify-center gap-x-2.5 xs:gap-x-3.5 sm:gap-x-5 z-20">
                {frontRowCups}
              </div>
            </div>
          ) : (
            <div className="relative z-20 w-full flex flex-wrap items-end justify-center gap-x-1.5 xs:gap-x-2.5 sm:gap-x-3.5 gap-y-2 pt-1 pb-1">
              {children}
            </div>
          );
        })()}


      </div>

      {/* 5. Bottom Handwoven Carpet Fringes (ریشه‌های ابریشمی پایین قالیچه) */}
      <div className="relative w-[92%] mx-auto h-2 sm:h-2.5 overflow-hidden flex items-end justify-between px-1 pointer-events-none z-10">
        {Array.from({ length: 42 }).map((_, i) => (
          <div
            key={`bottom-fringe-${i}`}
            className="w-[1.8px] sm:w-[2.2px] h-full rounded-t-xs shadow-xs"
            style={{
              backgroundColor: i % 4 === 0 ? '#E2D9C8' : currentCarpet.fringeColor,
              opacity: 0.85 + (i % 3) * 0.05,
              transform: `rotate(${(i % 5 - 2) * -1.5}deg)`,
            }}
          />
        ))}
      </div>
    </div>
  );
});
