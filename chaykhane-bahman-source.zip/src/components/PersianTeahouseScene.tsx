import React, { useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';
import { PersianCarpetBoard } from './PersianCarpetBoard';

interface PersianTeahouseSceneProps {
  children: React.ReactNode;
  isNightMode?: boolean;
  onOpenRenovations?: () => void;
  onOpenRadio?: () => void;
  onOpenDaftarHesab?: () => void;
  onOpenPatogh?: () => void;
  currentLevel?: number;
  unlockAll?: boolean;
}

export const PersianTeahouseScene: React.FC<PersianTeahouseSceneProps> = React.memo(({
  children,
  isNightMode = false,
  currentLevel = 1,
}) => {
  const [samovarSteamBurst, setSamovarSteamBurst] = useState<boolean>(false);
  const [samovarTip, setSamovarTip] = useState<string | null>(null);

  const handleSamovarClick = () => {
    soundEngine.playGlassClink();
    soundEngine.vibrate(20);
    setSamovarSteamBurst(true);
    setSamovarTip('سماور زغالی همیشه قل‌قل می‌کنه! چای قندپهلو آماده‌ست ☕');

    setTimeout(() => {
      setSamovarSteamBurst(false);
    }, 1500);

    setTimeout(() => {
      setSamovarTip(null);
    }, 3500);
  };

  return (
    <div className="relative w-full h-full flex flex-col justify-between overflow-hidden select-none">
      {/* 1. Atmospheric Overlays over the Teahouse Background Photo */}
      <div className="absolute inset-0 pointer-events-none z-0">
        {/* Soft Vignette & Room Depth Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-transparent to-[#1F0E05]/60" />

        {/* Hanging Lantern Warm Light Flicker (Top-Left Ceiling) */}
        <div
          className="absolute top-[8%] left-[18%] sm:left-[21%] w-20 h-20 rounded-full bg-amber-400/20 filter blur-xl animate-lamp-flicker pointer-events-none"
          title="نور چراغ آویز"
        />

        {/* Samovar Charcoal Grate Glow (Left Bench Side Table) */}
        <div
          className="absolute top-[48%] left-[24%] sm:left-[26%] w-12 h-12 rounded-full bg-orange-600/30 filter blur-md animate-ember-glow pointer-events-none"
          title="گرمای زغال سماور"
        />

        {/* Continuous Soft Steam Plumes rising from the Samovar Teapot */}
        <div className="absolute top-[34%] left-[25%] sm:left-[27%] -translate-x-1/2 pointer-events-none z-10 flex flex-col items-center">
          {/* Steam Cloud 1 */}
          <div className="w-5 h-5 rounded-full bg-white/35 filter blur-xs animate-samovar-steam-1 absolute -top-1" />
          {/* Steam Cloud 2 */}
          <div className="w-6 h-6 rounded-full bg-white/25 filter blur-xs animate-samovar-steam-2 absolute -top-3" />
          {/* Steam Cloud 3 */}
          <div className="w-8 h-8 rounded-full bg-amber-100/20 filter blur-sm animate-samovar-steam-3 absolute -top-5" />
          
          {/* Extra Steam Burst on Tap */}
          {samovarSteamBurst && (
            <div className="absolute -top-8 w-12 h-12 rounded-full bg-white/60 filter blur-md animate-smoke-cloud-1" />
          )}
        </div>
      </div>

      {/* Interactive Samovar Hotspot (Lets player tap the iconic samovar in the background) */}
      <button
        onClick={handleSamovarClick}
        className="absolute top-[35%] left-[17%] sm:left-[20%] w-24 h-32 rounded-3xl bg-transparent hover:bg-yellow-400/10 active:scale-95 transition-all cursor-pointer z-10 border border-transparent hover:border-yellow-400/40 flex flex-col items-center justify-start group"
        title="سماور زغالی عمو بهمن (کلیک کنید تا قل‌قل کنه)"
        aria-label="سماور زغالی عمو بهمن"
      >
        <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-stone-900/90 text-yellow-300 text-[10px] px-2 py-0.5 rounded-full font-lalezar shadow -mt-5 whitespace-nowrap border border-yellow-500/50">
          سماور زغالی ☕
        </span>
      </button>

      {/* Floating Samovar Speech/Tip on tap */}
      {samovarTip && (
        <div className="absolute top-[30%] left-1/2 -translate-x-1/2 z-30 animate-fade-in pointer-events-none px-3 max-w-[85%]">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-[#2A1408]/95 via-[#3D1D0D]/95 to-[#2A1408]/95 border-2 border-yellow-400 text-yellow-200 text-xs font-vazir shadow-2xl">
            <span className="text-sm">☕</span>
            <span className="font-semibold text-[11px] sm:text-xs">{samovarTip}</span>
          </div>
        </div>
      )}

      {/* Cozy Night Mode Warm Oil Lantern Atmosphere */}
      {isNightMode && (
        <div className="absolute inset-0 pointer-events-none z-10 transition-opacity duration-700">
          <div className="absolute inset-0 bg-radial from-amber-400/15 via-amber-800/10 to-transparent" />
          <div className="absolute bottom-28 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full bg-yellow-400/15 filter blur-3xl" />
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-1/4 left-1/3 w-1.5 h-1.5 rounded-full bg-amber-200/60 filter blur-xs animate-float" />
            <div className="absolute top-1/2 left-2/3 w-2 h-2 rounded-full bg-yellow-300/50 filter blur-xs animate-float-delayed" />
            <div className="absolute top-1/3 right-1/4 w-1 h-1 rounded-full bg-amber-100/70 filter blur-xs animate-float" />
          </div>
        </div>
      )}

      {/* 2. Middle Spacer: Keeps the Teahouse Room, Charcoal Samovar, Teapot & Stained Glass Completely Open & Visible */}
      <div className="relative z-10 flex-1 min-h-[190px] xs:min-h-[220px] sm:min-h-[250px] pointer-events-none" />

      {/* 3. Foreground Table & Authentic Persian Carpet for Estekans (تغییر فرش اصیل هر ۵ مرحله) */}
      <div className="relative z-30 w-full flex flex-col items-center justify-end pb-1.5 sm:pb-2 shrink-0">
        <PersianCarpetBoard currentLevel={currentLevel} isNightMode={isNightMode}>
          {children}
        </PersianCarpetBoard>
      </div>
    </div>
  );
});
