import React, { useEffect, useState } from 'react';
import { soundEngine } from '../audio/SoundEngine';

interface FlyingCoin {
  id: number;
  startX: number;
  startY: number;
  delay: number;
}

interface RewardSequenceProps {
  isActive: boolean;
  amount: number;
  onComplete: () => void;
}

export const RewardSequence: React.FC<RewardSequenceProps> = ({
  isActive,
  amount,
  onComplete,
}) => {
  const [coins, setCoins] = useState<FlyingCoin[]>([]);

  useEffect(() => {
    if (!isActive) {
      setCoins([]);
      return;
    }

    // Generate 12 flying gold coins starting from center tray towards top-right coin counter
    const newCoins: FlyingCoin[] = [];
    for (let i = 0; i < 12; i++) {
      newCoins.push({
        id: i,
        startX: 45 + (Math.random() - 0.5) * 20, // percentage from left
        startY: 65 + (Math.random() - 0.5) * 15, // percentage from top
        delay: i * 65,
      });
    }
    setCoins(newCoins);

    // Play coin chimes in rapid succession
    const audioInterval = setInterval(() => {
      soundEngine.playCoin();
    }, 90);

    const timer = setTimeout(() => {
      clearInterval(audioInterval);
      onComplete();
    }, 1200);

    return () => {
      clearInterval(audioInterval);
      clearTimeout(timer);
    };
  }, [isActive, onComplete]);

  if (!isActive) return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-50 overflow-hidden select-none">
      {coins.map((coin) => (
        <div
          key={coin.id}
          className="absolute w-6 h-6 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-300 border border-yellow-100 flex items-center justify-center text-amber-950 font-black text-xs shadow-[0_0_12px_rgba(255,215,0,0.9)] animate-flying-coin"
          style={{
            left: `${coin.startX}%`,
            top: `${coin.startY}%`,
            animationDelay: `${coin.delay}ms`,
            animationDuration: '750ms',
            animationFillMode: 'forwards',
          }}
        >
          ★
        </div>
      ))}
    </div>
  );
};
