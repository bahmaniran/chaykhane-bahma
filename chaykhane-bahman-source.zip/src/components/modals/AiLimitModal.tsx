import React, { useState, useEffect } from 'react';
import { X, Clock, Brain, Sparkles, CheckCircle2 } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits } from '../../utils/persianNumbers';
import { getAiQuotaStatus, formatAiTimeRemaining } from '../../services/AiSolverService';
import bahmanAvatarImg from '../../assets/images/bahman_exact_avatar_1791919274915.webp';

interface AiLimitModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
}

export const AiLimitModal: React.FC<AiLimitModalProps> = ({
  isOpen,
  onClose,
  currentLevel,
}) => {
  const [quota, setQuota] = useState(() => getAiQuotaStatus());

  useEffect(() => {
    if (!isOpen) return;
    setQuota(getAiQuotaStatus());

    const interval = setInterval(() => {
      setQuota(getAiQuotaStatus());
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#150702]/85 backdrop-blur-md animate-fade-in select-none"
      style={{ paddingTop: 'max(env(safe-area-inset-top, 24px), 1.5rem)' }}
    >
      <div className="relative w-full max-w-sm rounded-[32px] p-5 bg-gradient-to-b from-[#34180A] via-[#241005] to-[#170802] border-4 border-amber-500 shadow-[0_20px_60px_rgba(245,158,11,0.35)] text-[#FFFBF0] overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-amber-500/20 to-transparent pointer-events-none" />

        {/* Header Bar */}
        <div className="relative flex items-center justify-between pb-3 border-b border-amber-700/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-yellow-400 via-amber-500 to-amber-700 p-0.5 flex items-center justify-center shadow-lg border border-yellow-200/50">
              <Brain className="w-5 h-5 text-amber-950" />
            </div>
            <div>
              <h3 className="font-lalezar text-base text-yellow-300">
                سهمیه هوش مصنوعی عمو بهمن
              </h3>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                قانون ۳ مرحله در هر ۱ ساعت برای هر کاربر
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-amber-950/80 hover:bg-amber-900 border border-amber-600/60 text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Uncle Bahman Speech Box */}
        <div className="relative mt-4 flex items-center gap-3 p-3 rounded-2xl bg-[#1b0a04] border border-amber-600/40 shadow-inner">
          <img
            src={bahmanAvatarImg}
            alt="عمو بهمن"
            className="w-14 h-14 rounded-2xl border-2 border-yellow-400 object-cover shadow-md shrink-0"
          />
          <div className="text-right">
            <span className="font-lalezar text-xs text-yellow-300 block mb-0.5">
              کلام معرفتی عمو بهمن:
            </span>
            <p className="text-[11px] text-amber-100 font-vazir leading-relaxed">
              «پهلوون، سهمیه ۳ مرحله‌ای این ساعتت تموم شد! هوش و دست و پنجه خودت بالاتر از صدتا هوش مصنوعیه. استکان‌ها رو خودت مرتب کن تا حریف بطلبی!»
            </p>
          </div>
        </div>

        {/* Quota Gauge Display */}
        <div className="relative mt-4 p-4 rounded-2xl bg-gradient-to-r from-[#200c05] via-[#2d1308] to-[#200c05] border border-amber-500/60 shadow-lg text-center">
          <div className="flex items-center justify-between text-xs text-amber-200 mb-2 font-vazir">
            <span>وضعیت سهمیه این ساعت:</span>
            <span className="font-lalezar text-yellow-300 text-sm">
              {toPersianDigits(quota.stagesUsed)} از {toPersianDigits(3)} مرحله
            </span>
          </div>

          {/* 3 Steps Progress Dots */}
          <div className="grid grid-cols-3 gap-2 my-2.5">
            {[1, 2, 3].map((step) => {
              const isUsed = step <= quota.stagesUsed;
              return (
                <div
                  key={step}
                  className={`py-2 px-1 rounded-xl border flex flex-col items-center justify-center transition-all ${
                    isUsed
                      ? 'bg-amber-600/30 border-amber-400 text-yellow-300 shadow-sm'
                      : 'bg-[#120502] border-amber-800/40 text-stone-500'
                  }`}
                >
                  <span className="text-xs mb-0.5">{isUsed ? '✓' : '○'}</span>
                  <span className="text-[10px] font-lalezar">مرحله {toPersianDigits(step)}</span>
                </div>
              );
            })}
          </div>

          {/* Real-time Countdown Timer */}
          <div className="mt-3 pt-3 border-t border-amber-700/40 flex items-center justify-center gap-2 text-xs">
            <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="text-amber-200/90 font-vazir text-[11px]">
              زمان تا شارژ مجدد سهمیه:
            </span>
            <span className="font-lalezar text-yellow-300 text-sm dir-ltr tracking-wider font-bold">
              {formatAiTimeRemaining(quota.minutesRemaining, quota.secondsRemaining)}
            </span>
          </div>
        </div>

        {/* AI Engine Status Badge */}
        <div className="mt-3.5 p-2.5 rounded-xl bg-[#140602] border border-amber-800/50 flex items-center justify-between text-[10px] text-amber-300/80 font-vazir">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>موتور پردازش: جمینای + اوپن‌روتر + سرورهای ابری</span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600/50">
            فعال و آماده
          </span>
        </div>

        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="w-full mt-4 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:brightness-110 active:scale-95 text-stone-950 font-lalezar text-sm shadow-xl transition-all cursor-pointer border border-yellow-200 font-bold"
        >
          یا علی، خودم حلش می‌کنم! 💪
        </button>
      </div>
    </div>
  );
};
