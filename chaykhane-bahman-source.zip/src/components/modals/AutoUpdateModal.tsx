import React, { useState } from 'react';
import {
  Download,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  X,
  ExternalLink,
  ShieldCheck,
  Smartphone,
  Coffee,
  RotateCw,
} from 'lucide-react';
import { ServerConfig, APP_VERSION } from '../../services/backendApi';
import { toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';
import teahouseBg from '../../assets/images/teahouse_exact_scene_1791919273685.webp';
import bahmanAvatar from '../../assets/images/bahman_exact_avatar_1791919274915.webp';

interface AutoUpdateModalProps {
  isOpen: boolean;
  onClose?: () => void;
  config: ServerConfig | null;
}

export const AutoUpdateModal: React.FC<AutoUpdateModalProps> = ({
  isOpen,
  onClose,
  config,
}) => {
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [downloadStatus, setDownloadStatus] = useState<string>('');
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !config) return null;

  const isForceUpdate = Boolean(config.force_update);
  const directApkUrl = config.direct_apk_url || 'https://ghurfe.ir/api/bahman-latest.apk';
  const newVersion = config.current_version || '1.1.0';

  const defaultChangelog = 
`• ارتقای کامل سرعت بازی و رفع هرگونه لگ در موبایل
• اضافه شدن مراحل جذاب و چالش‌های هفتگی جدید
• بهبود چیدمان استکان‌ها و سینی قلم‌زنی
• هماهنگی با لیگ محله و جدول رده‌بندی کشوری`;

  const changelogText = config.changelog?.trim() || defaultChangelog;

  const triggerDirectBrowserDownload = () => {
    try {
      window.open(directApkUrl, '_system');
    } catch {}

    const a = document.createElement('a');
    a.href = directApkUrl;
    a.setAttribute('download', 'bahman-latest.apk');
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleStartDownload = async () => {
    soundEngine.playClick();
    setIsDownloading(true);
    setProgress(0);
    setErrorMsg(null);
    setIsCompleted(false);
    setDownloadStatus('در حال اتصال به سرور مستقیم عمو بهمن...');

    try {
      const response = await fetch(directApkUrl);

      if (!response.ok) {
        throw new Error(`خطای دریافت فایل: ${response.status}`);
      }

      const contentLength = response.headers.get('content-length');
      const totalBytes = contentLength ? parseInt(contentLength, 10) : 0;

      if (response.body && totalBytes > 0) {
        const reader = response.body.getReader();
        let receivedBytes = 0;
        const chunks: BlobPart[] = [];

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          if (value) {
            chunks.push(value);
            receivedBytes += value.length;
          }

          const pct = Math.min(100, Math.round((receivedBytes / totalBytes) * 100));
          setProgress(pct);
          setDownloadStatus(`در حال دریافت فایل نصبی: ${toPersianDigits(pct)}٪`);
        }

        const blob = new Blob(chunks, { type: 'application/vnd.android.package-archive' });
        const blobUrl = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = 'bahman-latest.apk';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        setIsCompleted(true);
        setProgress(100);
        setDownloadStatus('دانلود فایل APK کامل شد! روی فایل دانلود شده در گوشی بزنید تا نصب شود.');
        soundEngine.playSanturVictory();
      } else {
        // Fallback simulation with direct trigger if CORS / headers prevent readable stream
        for (let p = 15; p <= 90; p += 15) {
          await new Promise((r) => setTimeout(r, 180));
          setProgress(p);
          setDownloadStatus(`در حال دریافت مستقیم بسته نصبی: ${toPersianDigits(p)}٪`);
        }

        triggerDirectBrowserDownload();

        setProgress(100);
        setIsCompleted(true);
        setDownloadStatus('دانلود از طریق مرورگر آغاز شد. پس از اتمام، فایل را لمس و نصب نمایید.');
        soundEngine.playSanturVictory();
      }
    } catch {
      // Graceful fallback: trigger direct window open & anchor click
      triggerDirectBrowserDownload();
      setProgress(100);
      setIsCompleted(true);
      setDownloadStatus('فایل نصبی مستقیم در دانلودهای دستگاه ذخیره شد.');
      soundEngine.playSanturVictory();
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-[#180A03]/85 backdrop-blur-md animate-fade-in select-none"
      dir="rtl"
    >
      <div className="relative w-full max-w-md rounded-[28px] p-5 sm:p-6 bg-gradient-to-b from-[#381B0C] via-[#2A1408] to-[#1C0D05] border-2 border-amber-500/60 shadow-[0_20px_50px_rgba(25,10,3,0.85)] text-stone-100 overflow-hidden">
        {/* Warm Persian Ornamental Background Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-32 bg-amber-600/20 blur-3xl rounded-full pointer-events-none" />
        <div className="absolute -bottom-10 right-0 w-44 h-44 bg-yellow-600/15 blur-2xl rounded-full pointer-events-none" />

        {/* Top Header Controls */}
        <div className="flex items-center justify-between mb-4 relative z-10">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-inner">
              <Coffee className="w-4 h-4" />
            </span>
            <span className="text-xs font-vazir text-amber-300/80">
              چایخانه سنتی عمو بهمن
            </span>
          </div>

          {/* Close 'X' button only when update is not forced */}
          {!isForceUpdate && onClose && (
            <button
              onClick={() => {
                soundEngine.playClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-stone-900/80 hover:bg-stone-800 border border-amber-900/60 flex items-center justify-center text-stone-400 hover:text-amber-200 transition-colors"
              title="بستن پنجره"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Main Badge & Title */}
        <div className="text-center mb-3 relative z-10">
          {/* Authentic Persian Teahouse Visual Banner */}
          <div className="relative rounded-2xl overflow-hidden border-2 border-amber-500/60 shadow-lg bg-[#1B0C05] mb-3">
            <div className="relative h-28 w-full overflow-hidden">
              <img
                src={teahouseBg}
                alt="چایخانه سنتی عمو بهمن"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#160B05] via-[#160B05]/30 to-transparent" />
              
              {/* Uncle Bahman avatar with gold border badge */}
              <div className="absolute bottom-2 right-2.5 flex items-center gap-2">
                <div className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 shadow-xl">
                  <img
                    src={bahmanAvatar}
                    alt="اوستا بهمن"
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div className="text-right drop-shadow-md">
                  <span className="font-lalezar text-xs text-yellow-300 block">
                    اوستا بهمن می‌گوید:
                  </span>
                  <span className="text-[10px] font-vazir text-amber-100 block">
                    «قوری‌ها رو تازه‌دم کردیم، نسخه جدید آماده شد!»
                  </span>
                </div>
              </div>

              {/* Version Pill on image */}
              <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm border border-amber-400/50 px-2 py-0.5 rounded-full text-[10px] font-vazir text-yellow-300 shadow">
                نسخه {toPersianDigits(newVersion)}
              </div>
            </div>
          </div>

          <h2 className="text-lg sm:text-xl font-lalezar text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-100 mb-1">
            نسخه جدید چایخانه عمو بهمن رسید!
          </h2>

          <div className="flex items-center justify-center gap-2 text-xs font-vazir text-amber-200/80">
            <span>نسخه فعلی شما: {toPersianDigits(APP_VERSION)}</span>
            <span className="text-amber-500">•</span>
            <span className="text-yellow-400 font-bold">
              نسخه تازه: {toPersianDigits(newVersion)}
            </span>
          </div>

          {isForceUpdate && (
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/50 text-red-300 text-[11px] font-vazir">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              <span>به‌روزرسانی اجباری برای ادامه بازی و هماهنگی با محله</span>
            </div>
          )}
        </div>

        {/* Changelog Card */}
        <div className="relative z-10 mb-4 bg-stone-950/60 border border-amber-600/30 rounded-2xl p-3.5 max-h-40 overflow-y-auto shadow-inner text-right">
          <div className="flex items-center gap-1.5 mb-2 text-xs font-bold text-amber-300">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>تغییرات و امکانات نسخه جدید:</span>
          </div>
          <div className="text-xs text-stone-300 font-vazir leading-relaxed whitespace-pre-line space-y-1">
            {changelogText}
          </div>
        </div>

        {/* Download Progress Display */}
        {(isDownloading || isCompleted || progress > 0) && (
          <div className="relative z-10 mb-4 bg-stone-900/90 border border-amber-500/40 rounded-2xl p-3 space-y-2">
            <div className="flex items-center justify-between text-xs font-vazir">
              <span className="text-amber-200 font-bold">
                {isCompleted ? 'دریافت تکمیل شد' : 'پیشرفت دانلود:'}
              </span>
              <span className="text-yellow-300 font-lalezar text-sm">
                {toPersianDigits(progress)}٪
              </span>
            </div>

            {/* Glowing Progress Track */}
            <div className="w-full h-3 bg-stone-950 rounded-full overflow-hidden p-0.5 border border-amber-900/80">
              <div
                className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(251,191,36,0.6)]"
                style={{ width: `${progress}%` }}
              />
            </div>

            {downloadStatus && (
              <p className="text-[11px] text-stone-300 text-center font-vazir flex items-center justify-center gap-1">
                {isCompleted ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : (
                  <RotateCw className="w-3.5 h-3.5 text-amber-400 animate-spin shrink-0" />
                )}
                <span>{downloadStatus}</span>
              </p>
            )}
          </div>
        )}

        {errorMsg && (
          <div className="relative z-10 mb-3 p-2 bg-red-950/70 border border-red-600/40 rounded-xl text-red-200 text-xs text-center font-vazir">
            {errorMsg}
          </div>
        )}

        {/* Feature Highlights / Direct Install Note */}
        <div className="relative z-10 mb-5 p-2.5 rounded-xl bg-amber-950/30 border border-amber-600/20 flex items-center justify-around text-[10px] text-amber-200/80 font-vazir">
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>نصب امن و مستقیم</span>
          </div>
          <div className="w-px h-3 bg-amber-700/40" />
          <div className="flex items-center gap-1">
            <Smartphone className="w-3.5 h-3.5 text-yellow-400" />
            <span>بدون نیاز به مارکت</span>
          </div>
          <div className="w-px h-3 bg-amber-700/40" />
          <div className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>حفظ کامل اطلاعات بازی</span>
          </div>
        </div>

        {/* Google Play Protect Helper Tip (مطابق تصویر سپر ایمنی گوگل) */}
        <div className="relative z-10 mb-4 p-2.5 rounded-xl bg-amber-950/70 border border-amber-600/40 text-[10px] text-amber-200/90 font-vazir flex items-start gap-1.5 leading-relaxed">
          <ShieldCheck className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
          <span>
            <b>راهنمای نصب اندروید:</b> در صورت مشاهده پیام <u>«سپر ایمنی Google Play»</u>، کافیست روی <u>«جزئیات بیشتر»</u> زده و گزینه <u>«نصب به هر حال (Install anyway)»</u> را لمس نمایید.
          </span>
        </div>

        {/* Action Buttons */}
        <div className="relative z-10 space-y-2">
          {/* Prominent Primary Button */}
          <button
            onClick={handleStartDownload}
            disabled={isDownloading}
            className={`w-full py-3.5 px-4 rounded-2xl font-lalezar text-base sm:text-lg flex items-center justify-center gap-2 shadow-[0_8px_20px_rgba(245,158,11,0.35)] transition-all transform active:scale-95 ${
              isDownloading
                ? 'bg-amber-700/60 text-stone-300 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:via-yellow-300 hover:to-amber-400 text-stone-950 hover:shadow-[0_10px_25px_rgba(245,158,11,0.5)]'
            }`}
          >
            {isDownloading ? (
              <>
                <RotateCw className="w-5 h-5 animate-spin" />
                <span>در حال دانلود مستقیم...</span>
              </>
            ) : isCompleted ? (
              <>
                <ExternalLink className="w-5 h-5" />
                <span>دانلود مجدد و نصب سریع</span>
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span>دانلود مستقیم و نصب سریع (بدون نیاز به مارکت)</span>
              </>
            )}
          </button>

          {/* Close Button: HIDE if force_update is true! */}
          {!isForceUpdate && onClose && (
            <button
              onClick={() => {
                soundEngine.playClick();
                onClose();
              }}
              disabled={isDownloading}
              className="w-full py-2.5 px-4 rounded-xl font-vazir text-xs text-amber-200/70 hover:text-amber-100 hover:bg-stone-900/50 transition-colors"
            >
              فعلاً نه / بعداً
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
