import React, { useState } from 'react';
import { X, Sparkles, Store, Coins, Check, Clock } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import {
  DEFAULT_DECORATIONS,
  getDailyTipStatus,
  claimDailyTip,
} from '../../services/TeahouseStore';
import { TeahouseDecoration } from '../../types';

interface DecorationRenovationModalProps {
  isOpen: boolean;
  onClose: () => void;
  coins: number;
  ownedIds: string[];
  equippedSamovar: string;
  equippedCarpet: string;
  onBuyItem: (item: TeahouseDecoration) => void;
  onEquipItem: (item: TeahouseDecoration) => void;
  onCoinsAwarded: (amount: number) => void;
}

export const DecorationRenovationModal: React.FC<DecorationRenovationModalProps> = ({
  isOpen,
  onClose,
  coins,
  ownedIds,
  equippedSamovar,
  equippedCarpet,
  onBuyItem,
  onEquipItem,
  onCoinsAwarded,
}) => {
  const [activeTab, setActiveTab] = useState<'samovar' | 'carpet' | 'antique'>('samovar');

  if (!isOpen) return null;

  const tipStatus = getDailyTipStatus(ownedIds);
  const filtered = DEFAULT_DECORATIONS.filter((d) => d.category === activeTab);

  const handleClaimTip = () => {
    const res = claimDailyTip(ownedIds);
    if (res.success) {
      soundEngine.playCoins();
      onCoinsAwarded(res.coins);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Store className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                دکور چایخانه و دخل روزانه
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                ارتقای دکوراسیون و افزایش سود دخل
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Daily Tip Jar Banner (دخل روزانه) */}
        <div className="my-3 p-3 rounded-2xl bg-gradient-to-r from-amber-950/90 to-[#381B09] border border-yellow-400/70 shadow-md flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-500 to-amber-600 p-0.5 flex items-center justify-center text-amber-950 font-lalezar text-xl shadow">
              🏺
            </div>
            <div>
              <span className="font-lalezar text-xs text-yellow-200 block">
                دخل روزانه چایخانه: +{formatPersianCoins(tipStatus.amount)} سکه
              </span>
              <span className="text-[9px] text-amber-200/70 font-vazir">
                هر دکور خریداری‌شده سود دخل را بالا می‌برد
              </span>
            </div>
          </div>

          {tipStatus.canClaim ? (
            <button
              onClick={handleClaimTip}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-lalezar text-xs shadow-md animate-bounce hover:brightness-110 active:scale-95 cursor-pointer"
            >
              برداشت دخل
            </button>
          ) : (
            <div className="flex items-center gap-1 text-[10px] text-amber-300/80 font-vazir bg-black/40 px-2 py-1 rounded-xl">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>{toPersianDigits(tipStatus.hoursLeft)} ساعت مانده</span>
            </div>
          )}
        </div>

        {/* Category Tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-[#1C0D05] border border-amber-700/50 mb-3 text-center">
          {[
            { id: 'samovar', label: 'سماورها' },
            { id: 'carpet', label: 'فرش و تخت' },
            { id: 'antique', label: 'عتیقه‌جات' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                soundEngine.playClick();
                setActiveTab(tab.id as any);
              }}
              className={`py-1 rounded-lg font-lalezar text-xs transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 shadow-md font-bold'
                  : 'text-amber-300 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-0.5 custom-scrollbar">
          {filtered.map((item) => {
            const isOwned = ownedIds.includes(item.id);
            const isEquipped =
              (item.category === 'samovar' && equippedSamovar === item.id) ||
              (item.category === 'carpet' && equippedCarpet === item.id);

            return (
              <div
                key={item.id}
                className="p-3 rounded-2xl bg-[#28140A] hover:bg-[#341B0E] border border-amber-600/40 flex items-center justify-between transition-all shadow-sm"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-11 h-11 rounded-2xl bg-[#170903] border border-amber-600/50 flex items-center justify-center text-2xl shadow-inner">
                    {item.icon}
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5">
                      <span className="font-lalezar text-xs text-yellow-200">
                        {item.name}
                      </span>
                      {isEquipped && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600 font-vazir">
                          نصب شده
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-amber-200/70 font-vazir block mt-0.5">
                      {item.description}
                    </span>
                    <span className="text-[9px] text-emerald-400 font-vazir block">
                      دخل روزانه: +{toPersianDigits(item.passiveCoinsPerDay)} سکه در روز
                    </span>
                  </div>
                </div>

                <div>
                  {isOwned ? (
                    item.category !== 'antique' ? (
                      <button
                        onClick={() => {
                          soundEngine.playClick();
                          onEquipItem(item);
                        }}
                        disabled={isEquipped}
                        className={`px-3 py-1 rounded-xl font-lalezar text-xs transition-all ${
                          isEquipped
                            ? 'bg-stone-800 text-stone-500 cursor-default'
                            : 'bg-amber-700 hover:bg-amber-600 text-yellow-100 cursor-pointer shadow active:scale-95'
                        }`}
                      >
                        {isEquipped ? 'برپا است' : 'استفاده'}
                      </button>
                    ) : (
                      <span className="text-[10px] text-emerald-300 font-vazir">خریداری شده</span>
                    )
                  ) : (
                    <button
                      onClick={() => {
                        if (coins >= item.price) {
                          soundEngine.playCoins();
                          onBuyItem(item);
                        } else {
                          soundEngine.playGlassClink();
                        }
                      }}
                      disabled={coins < item.price}
                      className={`px-3 py-1 rounded-xl font-lalezar text-xs flex items-center gap-1 transition-all ${
                        coins >= item.price
                          ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-amber-950 hover:brightness-110 active:scale-95 cursor-pointer shadow'
                          : 'bg-stone-800 text-stone-500 cursor-not-allowed opacity-60'
                      }`}
                    >
                      <Coins className="w-3 h-3 text-amber-950" />
                      <span>{formatPersianCoins(item.price)}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            موجودی شما: {formatPersianCoins(coins)} سکه ★
          </p>
        </div>
      </div>
    </div>
  );
};
