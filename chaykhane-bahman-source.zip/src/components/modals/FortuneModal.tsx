import React, { useState } from 'react';
import { X, RefreshCw, Share2, Award, CheckCircle, Sparkles } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits } from '../../utils/persianNumbers';

interface FortuneModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardCoins: (amount: number) => void;
}

const PERSIAN_PROVERBS = [
  'چای داغ و رفیق ناب، غم عالم را می‌برد به خواب!',
  'آب در کوزه و ما تشنه‌لبان می‌گردیم، یار در خانه و ما گرد جهان می‌گردیم.',
  'به پایان آمد این دفتر، حکایت همچنان باقیست.',
  'جوجه را آخر پاییز می‌شمارند، اما چای دیشلمه را سر صبح می‌نوشند!',
  'سحرخیز باش تا کامروا باشی و چای قندپهلو نوش جان کنی.',
  'از تو حرکت، از خدا برکت؛ اول استکان‌ها رو بچین بعد نیت کن!',
  'هر که بامش بیش، برفش بیشتر؛ هر که چایش ناب، رفیقش پایدارتر.',
  'دشمن دانا به از نادان رفیق، چای دبش هم به از نوشابه شیک!',
  'گر صبر کنی ز غوره حلوا سازی، ز خاکشیر هم شربت مصفا سازی.',
  'با دوستان مروت، با دشمنان مدارا، با مهمان چایخانه قندپهلو!',
  'دل که پاک باشد، استکان چای هم زلال و زرین می‌شود.',
  'نابرده رنج گنج میسر نمی‌شود، مزد آن گرفت جان برادر که چای ریخت!',
  'ماهی را هر وقت از آب بگیری تازه است، چای را هر وقت دم کنی غنیمت است.',
  'کبوتر با کبوتر، باز با باز؛ استکان با نعلبکی، قند هم دمساز!',
  'خنده بر هر درد بی‌درمان دواست، چای داغ عمو بهمن هم شفاست.',
  'آهسته برو همیشه برو، چای داغ رو فوت کن نریزه!',
  'آسمان ریسمان نباف پهلوون، بیا یه استکان چای دبش نوش جان کن.',
  'قطره قطره جمع گردد وانگهی دریا شود؛ لایه لایه رنگ بچین تا مرحله حل شود.',
  'تا پول داری رفیقتم، قربان بند کیفتم؛ اما پیش عمو بهمن معرفت مهمه!',
  'یکی برای همه، همه برای یکی؛ استکان‌ها یک‌رنگ شوند تا پیروز شوی.',
  'هر چه دلم خواست نه آن می‌شود، هر چه خدا خواست همان می‌شود.',
  'عاقبت گرگ‌زاده گرگ شود، گرچه با آدمی بزرگ شود.',
  'در ناامیدی بسی امید است، پایان شب سیه سپید است.',
  'کار نیکو کردن از پر کردن است، چای ناب ریختن هنر عمو بهمن است.',
  'شکر نعمت نعمتت افزون کند، کفر نعمت از کفت بیرون کند.',
  'دیوار موش داره، موش هم گوش داره، ولی عطر چای دارچین رازی نداره!',
  'دیر رسیدن بهتر از هرگز نرسیدن است، به خصوص وقتی چای تازه دمه.',
  'بادنجان بم آفت ندارد، استکان کمر باریک قندپهلو تاوان ندارد!',
  'کوزه گر از کوزه شکسته آب می‌خورد، قهوه‌چی چای خودش را با عشق می‌نوشد.',
  'دست بالای دست بسیار است، طعم شربت زعفران ماندگار است.',
  'مرغ همسایه غازه، ولی عرق بهارنارنج عمو بهمن یکه‌تازه!',
  'چو تخته بند تن کبریا شکستی، به بزم چایخانه عمو بهمن نشستی.',
  'یک دست صدا ندارد، شربت بدون گلاب صفا ندارد.',
  'آشپز که دو تا شد، آش یا شور می‌شود یا بی‌نمک؛ چایخانه فقط یک اوستا می‌خواهد!',
  'هر گلی یک بویی دارد، هر شربتی یک خنکایی.',
  'بوی جوی مولیان آید همی، یاد یار مهربان آید همی.',
  'صدقه رفع بلا می‌کند، یک استکان چای خستگی را جلا می‌دهد.',
  'همیشه در سفر باش و پخته شو، ولی شب بیا چایخانه آرام شو.',
  'نوش‌دارو پس از مرگ سهراب، چای قندپهلو وقتِ دلتنگی یار!',
  'دلت را به وسعت دریا کن، غم‌ها را با چای دارچین رها کن.',
];

const POETRY_RIDDLES = [
  {
    id: 1,
    verse1: 'مزرع سبز فلک دیدم و داس مه نو...',
    verse2Blanks: 'یادم از کشته خویش آمد و هنگام ...',
    options: ['درو', 'بهار', 'سفر'],
    correctAnswer: 0,
    poet: 'حافظ شیرازی',
  },
  {
    id: 2,
    verse1: 'بنی آدم اعضای یکدیگرند...',
    verse2Blanks: 'که در آفرینش ز یک ...',
    options: ['گوهرند', 'ریشه‌اند', 'پیکرند'],
    correctAnswer: 0,
    poet: 'سعدی شیرازی',
  },
  {
    id: 3,
    verse1: 'توانا بود هر که دانا بود...',
    verse2Blanks: 'ز دانش دل پیر ...',
    options: ['شاداب بود', 'برنا بود', 'گویا بود'],
    correctAnswer: 1,
    poet: 'فردوسی طوسی',
  },
  {
    id: 4,
    verse1: 'ابر و باد و مه و خورشید و فلک در کارند...',
    verse2Blanks: 'تا تو نانی به کف آریّ و به ... نخوری',
    options: ['غفلت', 'حسرت', 'تنهایی'],
    correctAnswer: 0,
    poet: 'سعدی شیرازی',
  },
  {
    id: 5,
    verse1: 'گر نگه‌دار من آن است که من می‌دانم...',
    verse2Blanks: 'شیشه را در بغل ... نگه می‌دارد',
    options: ['سنگ', 'دریا', 'طوفان'],
    correctAnswer: 0,
    poet: 'جامی',
  },
  {
    id: 6,
    verse1: 'خیام اگر ز باده مستی خوش باش...',
    verse2Blanks: 'با ماه‌رخی اگر نشستی ...',
    options: ['خوش باش', 'هشیار باش', 'خندان باش'],
    correctAnswer: 0,
    poet: 'خیام نیشابوری',
  },
];

export const FortuneModal: React.FC<FortuneModalProps> = ({
  isOpen,
  onClose,
  onRewardCoins,
}) => {
  const [fortuneIndex, setFortuneIndex] = useState(0);
  const [riddleIndex, setRiddleIndex] = useState(0);
  const [isSwirling, setIsSwirling] = useState(false);
  const [tab, setTab] = useState<'fortune' | 'poetry'>('fortune');
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);

  if (!isOpen) return null;

  const currentFortune = PERSIAN_PROVERBS[fortuneIndex % PERSIAN_PROVERBS.length];
  const currentRiddle = POETRY_RIDDLES[riddleIndex % POETRY_RIDDLES.length];

  const handleNextRiddle = () => {
    soundEngine.playClick();
    setSelectedAnswer(null);
    setIsAnswered(false);
    setRiddleIndex((prev) => (prev + 1) % POETRY_RIDDLES.length);
  };

  const handleSwirl = () => {
    soundEngine.playGlassClink();
    setIsSwirling(true);
    setTimeout(() => {
      setFortuneIndex((prev) => (prev + 1 + Math.floor(Math.random() * 5)) % PERSIAN_PROVERBS.length);
      setIsSwirling(false);
    }, 600);
  };

  const handleShare = async () => {
    soundEngine.playClick();
    const textToShare = `📜 فال چای عمو بهمن:\n«${currentFortune}»\nبازی چایخانه عمو بهمن`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'فال چای عمو بهمن',
          text: textToShare,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(textToShare);
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2500);
    } catch {
      // Ignored
    }
  };

  const handleCheckAnswer = (idx: number) => {
    if (isAnswered) return;
    setSelectedAnswer(idx);
    setIsAnswered(true);

    if (idx === currentRiddle.correctAnswer) {
      soundEngine.playSanturVictory();
      onRewardCoins(100);
    } else {
      soundEngine.playClick();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[30px] p-5 bg-gradient-to-b from-[#381E10] via-[#2A1408] to-[#1E0E06] border-4 border-[#0D9488] shadow-2xl text-[#FFFBF0]">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="absolute top-4 left-4 w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Tabs */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <button
            onClick={() => {
              soundEngine.playClick();
              setTab('fortune');
            }}
            className={`px-4 py-1.5 rounded-full font-lalezar text-sm transition-all ${
              tab === 'fortune'
                ? 'bg-amber-500 text-amber-950 shadow-md font-bold'
                : 'bg-[#3D1F0E] text-amber-200/80 hover:text-amber-100'
            }`}
          >
            ☕ فال چای
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setTab('poetry');
            }}
            className={`px-4 py-1.5 rounded-full font-lalezar text-sm transition-all ${
              tab === 'poetry'
                ? 'bg-teal-500 text-teal-950 shadow-md font-bold'
                : 'bg-[#3D1F0E] text-teal-200/80 hover:text-teal-100'
            }`}
          >
            ✨ مشاعره امشب (+۱۰۰ سکه)
          </button>
        </div>

        {tab === 'fortune' ? (
          <div className="flex flex-col items-center text-center">
            {/* Swirling Teacup Cup Icon */}
            <div
              onClick={handleSwirl}
              className={`w-24 h-24 my-2 rounded-full p-2 bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-700 shadow-xl cursor-pointer flex items-center justify-center transition-transform ${
                isSwirling ? 'rotate-[720deg] scale-110 duration-700' : 'hover:scale-105 duration-200'
              }`}
              title="برای چرخش و فال جدید کلیک کنید"
            >
              <div className="w-full h-full rounded-full bg-[#1A0B04] border-2 border-amber-300 flex flex-col items-center justify-center">
                <span className="text-3xl">☕</span>
                <span className="text-[10px] font-lalezar text-amber-300">بچرخان</span>
              </div>
            </div>

            {/* Fortune Card Box */}
            <div className="w-full bg-[#FFFBF0] text-[#2C1A11] p-4 rounded-2xl border-2 border-amber-400 shadow-md my-3 min-h-[100px] flex flex-col items-center justify-center">
              <span className="text-amber-700 text-xs font-bold font-lalezar mb-1">
                «حکمت و پند چایخانه»
              </span>
              <p className="font-vazir text-sm sm:text-base font-semibold leading-relaxed text-[#3B1E08]">
                {currentFortune}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 w-full mt-2">
              <button
                onClick={handleSwirl}
                disabled={isSwirling}
                className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-lalezar text-sm font-bold flex items-center justify-center gap-1.5 shadow hover:brightness-110 active:scale-98 transition-all"
              >
                <RefreshCw className={`w-4 h-4 ${isSwirling ? 'animate-spin' : ''}`} />
                <span>فال دیگر</span>
              </button>

              <button
                onClick={handleShare}
                className="py-2.5 px-3 rounded-xl bg-[#3E2211] hover:bg-[#573018] text-amber-200 border border-amber-500/50 font-lalezar text-sm flex items-center justify-center gap-1.5 transition-all"
                title="فرستادن برای رفقا"
              >
                <Share2 className="w-4 h-4" />
                <span>فرستادن برای رفقا</span>
              </button>
            </div>

            {copiedToast && (
              <div className="mt-2 text-xs text-emerald-400 font-vazir animate-fade-in">
                متن فال در کلیپ‌بورد کپی شد! ✓
              </div>
            )}
          </div>
        ) : (
          /* Poetry Riddle Tab */
          <div className="flex flex-col items-center text-center">
            <div className="w-full bg-[#1A0B04] p-3.5 rounded-2xl border border-teal-500/50 mb-3 text-right">
              <div className="flex items-center justify-between text-xs text-teal-300 font-lalezar mb-1">
                <span>شاعر: {currentRiddle.poet}</span>
                <span>جایزه: ۱۰۰ سکه طلا ★</span>
              </div>
              <p className="font-nastaliq text-base sm:text-lg text-amber-200 font-bold mb-1 leading-loose">
                {currentRiddle.verse1}
              </p>
              <p className="font-nastaliq text-base sm:text-lg text-teal-100 font-bold leading-loose">
                {currentRiddle.verse2Blanks}
              </p>
            </div>

            {/* Options */}
            <div className="w-full space-y-2 mb-3">
              {currentRiddle.options.map((opt, idx) => {
                const isSelected = selectedAnswer === idx;
                const isCorrect = idx === currentRiddle.correctAnswer;
                let btnStyle = 'bg-[#2A150A] border-[#4E2914] text-amber-100 hover:bg-[#3D1F0E]';

                if (isAnswered) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-900 border-emerald-400 text-emerald-100 font-bold';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-950 border-rose-500 text-rose-200';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleCheckAnswer(idx)}
                    className={`w-full py-2.5 px-4 rounded-xl border text-sm font-vazir font-semibold transition-all flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{toPersianDigits(idx + 1)}. {opt}</span>
                    {isAnswered && isCorrect && <CheckCircle className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>

            {isAnswered && (
              <div className="w-full flex flex-col items-center gap-2 mt-1">
                <div className="text-xs font-vazir text-amber-200">
                  {selectedAnswer === currentRiddle.correctAnswer
                    ? '🎉 آفرین طبع شعر والایی داری! ۱۰۰ سکه اضافه شد.'
                    : 'این بار نشد، شعر بعدی رو امتحان کن!'}
                </div>
                <button
                  onClick={handleNextRiddle}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-lalezar text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>بیت بعدی مشاعره</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
