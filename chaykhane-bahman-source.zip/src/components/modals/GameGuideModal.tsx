import React, { useState } from 'react';
import {
  X,
  HelpCircle,
  Sparkles,
  RotateCcw,
  PlusCircle,
  Lightbulb,
  CheckCircle2,
  Flame,
  Snowflake,
  BookOpen,
} from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';

interface GameGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type GuideTab = 'basics' | 'sugar' | 'helpers' | 'features';

export const GameGuideModal: React.FC<GameGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<GuideTab>('basics');

  if (!isOpen) return null;

  const handleClose = () => {
    soundEngine.playClick();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none"
      style={{ paddingTop: 'max(env(safe-area-inset-top, 32px), 2rem)' }}
    >
      <div className="relative w-full max-w-md max-h-[88vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <HelpCircle className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                راهنمای چایخانه عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                قوانین بازی، حل آسان قند و کار با دکمه‌های کمکی
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
            title="بستن راهنما"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-4 gap-1 mt-3 mb-2 p-1 rounded-2xl bg-[#200F05] border border-amber-900/60 text-[10px] font-lalezar">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('basics');
            }}
            className={`py-1.5 rounded-xl transition-all ${
              activeTab === 'basics'
                ? 'bg-amber-500 text-amber-950 shadow font-bold'
                : 'text-amber-300/80 hover:text-white'
            }`}
          >
            نحوه بازی
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('sugar');
            }}
            className={`py-1.5 rounded-xl transition-all ${
              activeTab === 'sugar'
                ? 'bg-amber-500 text-amber-950 shadow font-bold'
                : 'text-amber-300/80 hover:text-white'
            }`}
          >
            قند و موانع
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('helpers');
            }}
            className={`py-1.5 rounded-xl transition-all ${
              activeTab === 'helpers'
                ? 'bg-amber-500 text-amber-950 shadow font-bold'
                : 'text-amber-300/80 hover:text-white'
            }`}
          >
            دکمه راهنما
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('features');
            }}
            className={`py-1.5 rounded-xl transition-all ${
              activeTab === 'features'
                ? 'bg-amber-500 text-amber-950 shadow font-bold'
                : 'text-amber-300/80 hover:text-white'
            }`}
          >
            امکانات
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 text-right font-vazir text-xs leading-relaxed">
          {activeTab === 'basics' && (
            <div className="space-y-2 animate-fade-in">
              <div className="p-3 rounded-2xl bg-[#28140A] border border-amber-500/30">
                <div className="flex items-center gap-2 mb-1.5 text-amber-300 font-lalezar text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>هدف اصلی بازی چایخانه</span>
                </div>
                <p className="text-amber-100/90 text-[11px]">
                  تمام لایه‌های نوشیدنی (چای، زعفران، خاکشیر، دوغ و...) را به گونه‌ای در استکان‌ها مرتب کنید که هر استکان فقط شامل یک نوشیدنی یکدست باشد.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-[#28140A] border border-amber-500/30 space-y-2">
                <div className="text-amber-300 font-lalezar text-sm">قانون ریختن نوشیدنی</div>
                <div className="flex items-start gap-2 text-[11px] text-amber-100/90">
                  <span className="w-5 h-5 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-xs shrink-0 font-bold">۱</span>
                  <span>روی استکان اول ضربه بزنید تا بلند شود (استکان مبدأ).</span>
                </div>
                <div className="flex items-start gap-2 text-[11px] text-amber-100/90">
                  <span className="w-5 h-5 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-xs shrink-0 font-bold">۲</span>
                  <span>روی استکان دوم ضربه بزنید تا چای ریخته شود (باید یا کاملاً خالی باشد یا بالاترین لایه همرنگ باشد).</span>
                </div>
                <div className="flex items-start gap-2 text-[11px] text-amber-100/90">
                  <span className="w-5 h-5 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-xs shrink-0 font-bold">★</span>
                  <span className="text-yellow-300">
                    ترفند حرفه‌ای: با «دو بار ضربه سریع» روی یک استکان، چای خودکار به بهترین استکان مقصد ریخته می‌شود!
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'sugar' && (
            <div className="space-y-2 animate-fade-in">
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/60 via-[#32170A] to-amber-950/60 border border-yellow-500/50">
                <div className="flex items-center gap-2 mb-1 text-yellow-300 font-lalezar text-sm">
                  <span className="text-lg">🍬</span>
                  <span>قند حبه روی استکان (ذوب آسان و سریع)</span>
                </div>
                <p className="text-amber-100/90 text-[11px] leading-relaxed">
                  قندهای حبه که روی استکان قرار دارند برای چای قندپهلو هستند. برای حل شدن قند:
                </p>
                <div className="mt-2 space-y-1.5 bg-[#1B0B04] p-2 rounded-xl border border-amber-700/50 text-[11px]">
                  <div className="flex items-center gap-1.5 text-emerald-300">
                    <span>✓</span>
                    <span><strong>با یک ضربه ساده:</strong> روی استکان قنددار ضربه بزنید تا با قاشق چایخوری سریع ذوب و چای شیرین شود!</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-teal-300">
                    <span>✓</span>
                    <span><strong>با ریختن چای داغ:</strong> با ریختن هر نوشیدنی داغ، قند حبه فوراً ذوب شده و مسیر باز می‌شود.</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-2xl bg-[#28140A] border border-amber-600/30">
                  <div className="flex items-center gap-1.5 text-amber-300 font-lalezar text-xs mb-1">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>استکان بخارگرفته</span>
                  </div>
                  <p className="text-[10px] text-amber-200/80">
                    رنگ زیر بخار مخفی است. با ریختن لایه بالایی، بخار کنار رفته و رنگ چای آشکار می‌شود.
                  </p>
                </div>
                <div className="p-2.5 rounded-2xl bg-[#28140A] border border-cyan-600/30">
                  <div className="flex items-center gap-1.5 text-cyan-300 font-lalezar text-xs mb-1">
                    <Snowflake className="w-3.5 h-3.5 text-cyan-400" />
                    <span>چای در حال سرد شدن</span>
                  </div>
                  <p className="text-[10px] text-cyan-100/80">
                    تعداد حرکات محدودی برای جا‌به‌جایی دارد. قبل از یخ زدن آن را خالی و مرتب کنید.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'helpers' && (
            <div className="space-y-2 animate-fade-in">
              <div className="p-3 rounded-2xl bg-[#28140A] border border-amber-500/40">
                <div className="flex items-center gap-2 mb-1.5 text-yellow-300 font-lalezar text-sm">
                  <Lightbulb className="w-4 h-4 text-yellow-400" />
                  <span>دکمه راهنما (نشانه‌گذاری + اجرای خودکار)</span>
                </div>
                <p className="text-amber-100/90 text-[11px] mb-2">
                  هر جا در چیدمان استکان‌ها معطل شدید، دکمه «راهنما» در نوار پایین همیشه به داد شما می‌رسد:
                </p>
                <div className="space-y-1.5 text-[11px] bg-[#1E0E06] p-2.5 rounded-xl border border-amber-700/60">
                  <div className="flex items-center gap-1.5 text-amber-200">
                    <span className="text-yellow-400 font-bold">ضربه اول:</span>
                    <span>استکان مبدأ (طلایی) و مقصد (سبز) را با نشانه‌گر مشخص می‌کند.</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-300">
                    <span className="text-emerald-400 font-bold">ضربه دوم:</span>
                    <span>اگر مجدد دکمه راهنما را بزنید، حرکت پیشنهادی به صورت خودکار اجرا می‌شود!</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-2xl bg-[#28140A] border border-amber-600/30">
                  <div className="flex items-center gap-1.5 text-amber-300 font-lalezar text-xs mb-1">
                    <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                    <span>برگشت حرکت</span>
                  </div>
                  <p className="text-[10px] text-amber-200/80">
                    اگر اشتباه ریختید، می‌توانید آخرین حرکت خود را بدون محدودیت به عقب برگردانید.
                  </p>
                </div>
                <div className="p-2.5 rounded-2xl bg-[#28140A] border border-amber-600/30">
                  <div className="flex items-center gap-1.5 text-amber-300 font-lalezar text-xs mb-1">
                    <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
                    <span>استکان جدید</span>
                  </div>
                  <p className="text-[10px] text-amber-200/80">
                    یک استکان خالی نو در سینی می‌گذارد تا دست شما برای مرتب‌سازی باز شود.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'features' && (
            <div className="space-y-2 animate-fade-in">
              <div className="p-3 rounded-2xl bg-[#28140A] border border-amber-500/30 space-y-1.5">
                <div className="flex items-center gap-2 text-yellow-300 font-lalezar text-xs">
                  <BookOpen className="w-3.5 h-3.5 text-yellow-400" />
                  <span>بخش‌های ویژه چایخانه</span>
                </div>
                <div className="text-[11px] text-amber-100/90 space-y-1">
                  <div>• <strong>جدول رقبا:</strong> رتبه‌بندی استانی و شهری، با امکان ارسال ایموجی‌های باصفا به رقبا.</div>
                  <div>• <strong>دفتر حساب و نسیه:</strong> وام ۳۰۰ سکه‌ای از عمو بهمن که با ۳ برد پیاپی صاف می‌شود.</div>
                  <div>• <strong>میز دخل عمو بهمن:</strong> از مرحله ۳ باز می‌شود و شامل انعام روزانه و امکانات است.</div>
                  <div>• <strong>رادیو لامپی:</strong> ترانه‌های سنتی طهران قدیم در سه موج متفاوت.</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Button */}
        <div className="mt-3 pt-2.5 border-t border-[#522E18] flex items-center justify-between">
          <span className="text-[10px] text-amber-300/70 font-vazir">
            نوش جان و دمِ شما گرم پهلوون!
          </span>
          <button
            onClick={handleClose}
            className="px-5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:brightness-110 text-amber-950 font-lalezar text-xs font-bold shadow-md active:scale-95 transition-all cursor-pointer"
          >
            فهمیدم، بزن بریم ↵
          </button>
        </div>
      </div>
    </div>
  );
};
