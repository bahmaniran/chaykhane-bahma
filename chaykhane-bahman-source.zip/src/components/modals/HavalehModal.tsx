import React, { useState } from 'react';
import { X, Send, Gift, Copy, Check, Share2, Award, Sparkles, Coins } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import {
  canSendHavaleh,
  createHavalehVoucher,
  redeemHavalehCode,
  checkDailyGenerosityReward,
  claimDailyGenerosityReward,
  HavalehVoucher,
} from '../../services/HavalehService';

interface HavalehModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
  coins: number;
  onCoinsChange: (newCoins: number) => void;
  senderId?: string;
  unlockAll?: boolean;
  onGenerosityAward?: (message: string) => void;
}

export const HavalehModal: React.FC<HavalehModalProps> = ({
  isOpen,
  onClose,
  currentLevel,
  coins,
  onCoinsChange,
  senderId = 'device_guest',
  unlockAll = false,
  onGenerosityAward,
}) => {
  const [activeTab, setActiveTab] = useState<'send' | 'redeem'>('send');
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [generatedVoucher, setGeneratedVoucher] = useState<HavalehVoucher | null>(null);
  const [redeemInput, setRedeemInput] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [messageText, setMessageText] = useState<{ type: 'error' | 'success'; text: string } | null>(
    null
  );

  if (!isOpen) return null;

  const handleGenerate = () => {
    setMessageText(null);
    const check = canSendHavaleh(currentLevel, coins, selectedAmount, unlockAll);
    if (!check.allowed) {
      soundEngine.playGlassClink();
      setMessageText({ type: 'error', text: check.reason || 'امکان صدور حواله نیست.' });
      return;
    }

    // Deduct coins
    const newCoins = coins - selectedAmount;
    onCoinsChange(newCoins);

    // Create signed voucher
    const voucher = createHavalehVoucher(selectedAmount, senderId);
    setGeneratedVoucher(voucher);
    soundEngine.playCoin();

    // Check daily generosity reward
    const generosity = checkDailyGenerosityReward();
    if (generosity.canClaim) {
      claimDailyGenerosityReward();
      if (onGenerosityAward) {
        onGenerosityAward('«دمت گرم پهلوون! سفره‌دار باشی، مدال مرام و معرفت و ۱ قند کمکی نوش جونت!»');
      }
    }
  };

  const getShareText = (amount: number, code: string) => {
    return `«پهلوون! عمو بهمن حسابت رو صاف کرد ☕🎁 من ${toPersianDigits(
      amount
    )} سکه طلا برات حواله کردم تا تو چایخانه کم نیاری! این کد رو تو بخش 'حواله سکه' بازی وارد کن و سکه‌هات رو بگیر: ${code}»`;
  };

  const handleShareOrCopy = async () => {
    if (!generatedVoucher) return;
    const shareText = getShareText(generatedVoucher.amount, generatedVoucher.code);

    soundEngine.playClick();
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'حواله طلایی چایخانه عمو بهمن',
          text: shareText,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Ignored
    }
  };

  const handleRedeem = () => {
    setMessageText(null);
    if (!redeemInput.trim()) {
      setMessageText({ type: 'error', text: 'لطفاً کد حواله را وارد کن پهلوون!' });
      return;
    }

    const res = redeemHavalehCode(redeemInput, senderId);
    if (res.success && res.amount) {
      soundEngine.playSanturVictory();
      onCoinsChange(coins + res.amount);
      setMessageText({ type: 'success', text: res.message });
      setRedeemInput('');
    } else {
      soundEngine.playGlassClink();
      setMessageText({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Gift className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                حواله چایخانه عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                مهمون کردن رفقا با سکه طلا و صفای قهوه‌خانه
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 mt-3 bg-[#180A04] rounded-2xl border border-amber-900/60">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('send');
              setMessageText(null);
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'send'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>فرستادن سکه (حواله)</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('redeem');
              setMessageText(null);
            }}
            className={`flex-1 py-1.5 rounded-xl font-lalezar text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'redeem'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow'
                : 'text-amber-200/70 hover:text-amber-100'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>دریافت هدیه</span>
          </button>
        </div>

        {/* Tab 1: Send Coin Havaleh */}
        {activeTab === 'send' && (
          <div className="my-3 space-y-3">
            {!generatedVoucher ? (
              <>
                <p className="text-[11px] text-amber-200/90 font-vazir leading-relaxed text-right">
                  «رفیقت ته جیبش خالی شده و استکان‌هاش لنگ سکه‌ست؟ یه برگه حواله براش صادر کن تا با مرام تو بازی کنه!»
                </p>

                {/* Amount Selection */}
                <div className="grid grid-cols-3 gap-2">
                  {[50, 100, 250].map((amt) => (
                    <button
                      key={amt}
                      onClick={() => {
                        soundEngine.playClick();
                        setSelectedAmount(amt);
                      }}
                      className={`p-2.5 rounded-2xl border-2 flex flex-col items-center justify-center transition-all cursor-pointer ${
                        selectedAmount === amt
                          ? 'bg-gradient-to-b from-amber-700 via-amber-800 to-amber-950 border-yellow-400 shadow-[0_0_12px_rgba(245,158,11,0.5)] scale-102'
                          : 'bg-[#2A1408] border-amber-900/80 hover:border-amber-700 text-amber-200'
                      }`}
                    >
                      <span className="font-lalezar text-base text-yellow-300">
                        {toPersianDigits(amt)}
                      </span>
                      <span className="text-[10px] text-amber-300/80 font-vazir">سکه طلا</span>
                    </button>
                  ))}
                </div>

                {/* Requirements info */}
                <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-800/60 text-[10px] text-amber-300 font-vazir flex items-center justify-between">
                  <span>مرحله لازم: حداقل ۵</span>
                  <span>حداقل موجودی بعد از ارسال: ۲۰۰ سکه</span>
                </div>

                {/* Generate Button */}
                <button
                  onClick={handleGenerate}
                  className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 font-lalezar text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-transform cursor-pointer"
                >
                  صدور حواله و ارسال ({toPersianDigits(selectedAmount)} سکه)
                </button>
              </>
            ) : (
              /* Stylized Vintage Voucher Ticket */
              <div className="space-y-3">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#FEF3C7] via-[#FDE68A] to-[#F59E0B] text-amber-950 border-2 border-dashed border-[#B45309] shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-amber-700 via-yellow-500 to-amber-700" />
                  <div className="flex items-center justify-between border-b border-amber-900/20 pb-2">
                    <span className="font-lalezar text-xs text-amber-900">برگه حواله طلا ☕</span>
                    <span className="text-[10px] font-vazir text-amber-800 font-bold">چایخانه عمو بهمن</span>
                  </div>

                  <div className="text-center my-3">
                    <span className="text-[11px] font-vazir text-amber-900 block">مبلغ قابل وصول:</span>
                    <div className="font-lalezar text-2xl text-amber-950 tracking-wider">
                      {formatPersianCoins(generatedVoucher.amount)} سکه طلا
                    </div>
                    <div className="mt-2 inline-block px-3 py-1 rounded-xl bg-amber-900/15 border border-amber-900/30 font-vazir text-xs font-bold tracking-widest text-amber-950 select-all">
                      {generatedVoucher.code}
                    </div>
                  </div>

                  <div className="text-[9px] text-amber-900/80 font-vazir text-center border-t border-amber-900/20 pt-1.5">
                    این حواله یکبارمصرف و دارای امضای امنیتی عمو بهمن است.
                  </div>
                </div>

                {/* Daily Generosity Badge */}
                <div className="flex items-center gap-2 p-2 rounded-xl bg-emerald-950/70 border border-emerald-600/70 text-emerald-200 text-[10px] font-vazir">
                  <Award className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>مدال مرام و معرفت: روزی ۱ بار مهمون کردن = ۱ قند کمکی رایگان!</span>
                </div>

                {/* Share / Copy Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={handleShareOrCopy}
                    className="flex-1 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 font-lalezar text-xs font-bold flex items-center justify-center gap-1.5 shadow-md hover:brightness-110 active:scale-95 transition-transform cursor-pointer"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
                    <span>{copied ? 'متن کپی شد!' : 'ارسال به رفیق (اشتراک)'}</span>
                  </button>

                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      setGeneratedVoucher(null);
                    }}
                    className="px-3 py-2.5 rounded-2xl bg-[#351909] border border-amber-700/60 text-amber-200 font-lalezar text-xs cursor-pointer hover:bg-[#48220C]"
                  >
                    حواله جدید
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Redeem Gift Code */}
        {activeTab === 'redeem' && (
          <div className="my-3 space-y-3">
            <p className="text-[11px] text-amber-200/90 font-vazir leading-relaxed text-right">
              «رفیقت برات کد حواله فرستاده؟ کد رو این زیر پیست کن تا عمو بهمن سکه‌ها رو نقداً بریزه تو جیبت!»
            </p>

            <div className="relative">
              <input
                type="text"
                placeholder="مثال: BAHMAN-100-X7F9-K2M4"
                value={redeemInput}
                onChange={(e) => setRedeemInput(e.target.value.toUpperCase())}
                className="w-full px-3 py-2.5 rounded-2xl bg-[#140702] border-2 border-amber-700/80 text-yellow-300 text-center font-vazir text-sm tracking-wider placeholder:text-amber-800 focus:outline-none focus:border-yellow-400 font-bold"
                dir="ltr"
              />
            </div>

            <button
              onClick={handleRedeem}
              className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-700 text-white font-lalezar text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-transform cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Gift className="w-4 h-4" />
              <span>وصول حواله و دریافت سکه‌ها</span>
            </button>
          </div>
        )}

        {/* Feedback Message */}
        {messageText && (
          <div
            className={`p-2 rounded-xl text-[11px] font-vazir text-center border animate-fade-in ${
              messageText.type === 'error'
                ? 'bg-red-950/80 border-red-500/70 text-red-200'
                : 'bg-emerald-950/80 border-emerald-500/70 text-emerald-200'
            }`}
          >
            {messageText.text}
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            صفای قهوه‌خانه • سکه‌ها با امضای امنیتی عمو بهمن تضمین شده‌اند
          </p>
        </div>
      </div>
    </div>
  );
};
