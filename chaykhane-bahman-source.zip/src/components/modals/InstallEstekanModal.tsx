import React, { useState } from 'react';
import { X, Download, Smartphone, Share2, PlusSquare, CheckCircle, Sparkles } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { usePWAInstall } from '../../hooks/usePWAInstall';

interface InstallEstekanModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallEstekanModal: React.FC<InstallEstekanModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [installSuccess, setInstallSuccess] = useState<boolean>(false);
  const [showManualGuide, setShowManualGuide] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    soundEngine.playClick();
    if (isInstallable) {
      const outcome = await install();
      if (outcome === 'accepted') {
        soundEngine.playSanturVictory();
        setInstallSuccess(true);
      } else {
        setShowManualGuide(true);
      }
    } else {
      setShowManualGuide(true);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-4 bg-[#140803]/85 backdrop-blur-md animate-fade-in select-none"
      dir="rtl"
    >
      <div className="relative w-full max-w-sm rounded-[28px] p-5 sm:p-6 bg-gradient-to-b from-[#381B0C] via-[#2A1408] to-[#1C0D05] border-2 border-yellow-500/80 shadow-[0_20px_50px_rgba(25,10,3,0.9)] text-stone-100 overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-28 bg-amber-500/25 blur-3xl rounded-full pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="absolute top-4 left-4 w-8 h-8 rounded-full bg-stone-900/80 hover:bg-stone-800 border border-amber-600/50 flex items-center justify-center text-amber-200 transition-all cursor-pointer active:scale-90 z-20"
          title="بستن پنجره"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header with New Estekan Icon */}
        <div className="flex flex-col items-center text-center mt-1 mb-4 relative z-10">
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-yellow-400 shadow-[0_8px_20px_rgba(245,158,11,0.5)] mb-3 group">
            <img
              src="/pwa-192x192.png"
              alt="آیکون اپلیکیشن استکان"
              className="w-full h-full object-cover transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 ring-1 ring-inset ring-white/30 rounded-2xl pointer-events-none" />
          </div>

          <h2 className="font-lalezar text-xl sm:text-2xl text-yellow-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
            نصب اپلیکیشن «استکان»
          </h2>
          <p className="text-xs font-vazir text-amber-200/80 mt-1">
            چای‌خانه سنتی عمو بهمن • اجرای بدون لگ و آفلاین
          </p>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 text-[11px] font-vazir font-semibold mt-2 shadow-inner">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>حجم فوق‌سبک (کمتر از ۴ مگابایت)</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="space-y-3 relative z-10">
          {isInstalled || installSuccess ? (
            <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-500/80 text-center space-y-2">
              <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
              <p className="font-lalezar text-base text-emerald-200">
                اپلیکیشن استکان نصب شد!
              </p>
              <p className="text-xs font-vazir text-emerald-300/80">
                آیکون زرین استکان روی صفحه گوشی شما قرار گرفت. از این پس بازی را مستقیماً از روی صفحه اصلی باز کنید.
              </p>
            </div>
          ) : isIOS ? (
            /* iOS Safari Instructions */
            <div className="p-3.5 rounded-2xl bg-[#241006] border border-amber-600/50 space-y-2.5 text-right font-vazir text-xs">
              <div className="flex items-center gap-2 text-yellow-300 font-lalezar text-sm pb-1 border-b border-amber-800/60">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>راهنمای نصب روی آیفون و آیپد (iOS):</span>
              </div>
              <div className="flex items-center gap-2.5 text-stone-200">
                <span className="w-5 h-5 rounded-full bg-amber-600/40 text-yellow-300 flex items-center justify-center font-bold text-xs shrink-0">
                  ۱
                </span>
                <span className="flex items-center gap-1">
                  در پایین مرورگر سافاری روی دکمه <Share2 className="w-3.5 h-3.5 text-sky-400 inline mx-0.5" /> <strong>اشتراک‌گذاری (Share)</strong> بزنید.
                </span>
              </div>
              <div className="flex items-center gap-2.5 text-stone-200">
                <span className="w-5 h-5 rounded-full bg-amber-600/40 text-yellow-300 flex items-center justify-center font-bold text-xs shrink-0">
                  ۲
                </span>
                <span className="flex items-center gap-1">
                  گزینه <PlusSquare className="w-3.5 h-3.5 text-emerald-400 inline mx-0.5" /> <strong>Add to Home Screen (افزودن به صفحه اصلی)</strong> را انتخاب کنید.
                </span>
              </div>
              <div className="flex items-center gap-2.5 text-stone-200">
                <span className="w-5 h-5 rounded-full bg-amber-600/40 text-yellow-300 flex items-center justify-center font-bold text-xs shrink-0">
                  ۳
                </span>
                <span>
                  روی <strong>Add</strong> بزنید تا آیکون استکان روی صفحه شما نصب شود!
                </span>
              </div>
            </div>
          ) : (
            /* Android / Chrome Flow */
            <div className="space-y-2.5">
              <button
                onClick={handleInstallClick}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-600 hover:brightness-110 active:scale-95 text-stone-950 font-lalezar text-base font-bold flex items-center justify-center gap-2 shadow-[0_8px_20px_rgba(16,185,129,0.4)] border border-emerald-300 transition-all cursor-pointer"
              >
                <Download className="w-5 h-5 text-stone-950 stroke-[2.5]" />
                <span>نصب مستقیم روی گوشی</span>
              </button>

              {(!isInstallable || showManualGuide) && (
                <div className="p-3 rounded-xl bg-[#241006] border border-amber-600/40 text-right text-[11px] font-vazir text-amber-200/90 space-y-1.5 animate-fade-in">
                  <div className="font-bold text-yellow-300 flex items-center gap-1">
                    <span>💡 راهنمای نصب فوری در مرورگر:</span>
                  </div>
                  <p>
                    ۱. روی دکمه <strong>سه‌نقطه (⋮)</strong> در بالای مرورگر کروم بزنید.
                  </p>
                  <p>
                    ۲. گزینه <strong>«نصب برنامه»</strong> یا <strong>«افزودن به صفحه اصلی» (Install App / Add to Home screen)</strong> را لمس نمایید.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="mt-4 pt-3 border-t border-amber-900/60 text-center text-[10px] text-amber-400/60 font-vazir flex items-center justify-between">
          <span>بدون نیاز به مارکت‌های خارجی</span>
          <span>پشتیبانی کامل از حالت آفلاین</span>
        </div>
      </div>
    </div>
  );
};
