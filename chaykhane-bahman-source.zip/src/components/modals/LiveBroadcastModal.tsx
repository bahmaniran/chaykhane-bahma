import React from 'react';
import {
  Bell,
  Sparkles,
  Gift,
  AlertTriangle,
  Info,
  CheckCircle2,
  X,
  ExternalLink,
} from 'lucide-react';
import { RemoteBroadcastMessage } from '../../services/LivePatchService';
import { toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';

interface LiveBroadcastModalProps {
  isOpen: boolean;
  onClose: () => void;
  broadcast: RemoteBroadcastMessage | null;
  onClaimReward?: (coins: number) => void;
}

export const LiveBroadcastModal: React.FC<LiveBroadcastModalProps> = React.memo(({
  isOpen,
  onClose,
  broadcast,
  onClaimReward,
}) => {
  if (!isOpen || !broadcast) return null;

  const isReward = broadcast.type === 'reward' && (broadcast.rewardCoins ?? 0) > 0;
  const isUrgent = broadcast.type === 'urgent';

  const handleAction = () => {
    soundEngine.playCoin();
    if (isReward && broadcast.rewardCoins && onClaimReward) {
      onClaimReward(broadcast.rewardCoins);
    }
    if (broadcast.ctaUrl) {
      try {
        window.open(broadcast.ctaUrl, '_blank');
      } catch {}
    }
    onClose();
  };

  const getIcon = () => {
    if (isReward) return <Gift className="w-6 h-6 text-yellow-300 animate-bounce" />;
    if (isUrgent) return <AlertTriangle className="w-6 h-6 text-amber-300 animate-pulse" />;
    return <Bell className="w-6 h-6 text-amber-300" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.35)] text-[#FFFBF0] overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/15 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center">
                {getIcon()}
              </div>
            </div>
            <div>
              <span className="text-[10px] text-amber-300/80 font-vazir block">پیام زنده از سرور چایخانه</span>
              <h2 className="font-lalezar text-base text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 leading-tight">
                {broadcast.title || 'اعلان جدید اوستا'}
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-4 space-y-3">
          <div className="p-3.5 rounded-2xl bg-[#1C0D05]/80 border border-amber-600/30 text-right">
            <p className="text-xs text-amber-100/90 leading-relaxed font-vazir whitespace-pre-wrap">
              {broadcast.content}
            </p>
          </div>

          {/* Reward pill if available */}
          {isReward && (
            <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-900/60 via-yellow-950/70 to-amber-900/60 border border-yellow-500/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-yellow-300 animate-spin" />
                <span className="font-lalezar text-xs text-yellow-200">هدیه ویژه اوستا برای شما:</span>
              </div>
              <span className="font-lalezar text-sm text-yellow-300 bg-amber-950/80 px-2.5 py-0.5 rounded-xl border border-yellow-400/40">
                +{toPersianDigits(broadcast.rewardCoins || 0)} سکه
              </span>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="pt-2 flex gap-2">
          <button
            onClick={handleAction}
            className="flex-1 py-2.5 rounded-2xl font-lalezar text-sm text-[#180A03] bg-gradient-to-r from-yellow-300 via-amber-300 to-yellow-400 hover:brightness-110 active:scale-95 shadow-lg flex items-center justify-center gap-1.5 cursor-pointer transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{broadcast.ctaText || (isReward ? 'دریافت جایزه و بستن' : 'متوجه شدم')}</span>
            {broadcast.ctaUrl && <ExternalLink className="w-3.5 h-3.5 ml-1" />}
          </button>
        </div>
      </div>
    </div>
  );
});
