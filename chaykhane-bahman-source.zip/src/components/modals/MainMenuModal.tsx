import React from 'react';
import {
  X,
  Radio,
  Store,
  Users,
  Sparkles,
  Calendar,
  Gift,
  Phone,
  Eye,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  UserCheck,
  ChevronLeft,
  Award,
  BookOpen,
  Dice5,
  Share2,
  Download,
  HelpCircle,
  Brain,
} from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { PlayerProfile } from '../../types';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import { APP_VERSION } from '../../services/backendApi';
import { APP_CURRENT_VERSION } from '../../services/UpdateService';
import { getAvatarById } from '../../constants/avatars';
import { getBadgeById } from '../../services/PahlavaniAchievements';
import teahouseBannerImg from '../../assets/images/teahouse_exact_scene_1791919273685.webp';
import bahmanAvatarImg from '../../assets/images/bahman_exact_avatar_1791919274915.webp';
import ghafourAvatarImg from '../../assets/images/ghafour_exact_avatar_1791919275034.webp';

interface MainMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerProfile?: PlayerProfile;
  currentLevel: number;
  coins: number;
  soundEnabled: boolean;
  colorblindMode: boolean;
  weeklyStagesCompleted?: number;
  hasDailyRewardAvailable?: boolean;
  hasDiceRollAvailable?: boolean;
  hasDailyTipAvailable?: boolean;
  isDebtActive?: boolean;
  onOpenRegister?: () => void;
  onOpenShop: () => void;
  onOpenNeighborhood: () => void;
  onOpenSpecialGuest: () => void;
  onOpenWeeklyChallenge?: () => void;
  onOpenDailyReward?: () => void;
  onOpenRadio: () => void;
  onOpenGuide?: () => void;
  onOpenContact?: () => void;
  onOpenDaftarHesab?: () => void;
  onOpenNaghali?: () => void;
  onOpenRenovations?: () => void;
  onOpenPatogh?: () => void;
  onOpenSiniGardani?: () => void;
  onOpenTakhtehNard?: () => void;
  onOpenPahlavaniCard?: () => void;
  onOpenNightMystery?: () => void;
  onOpenAchievements?: () => void;
  onOpenAiLimit?: () => void;
  onOpenInstall?: () => void;
  onCheckUpdate?: () => void;
  hasUpdateAvailable?: boolean;
  isNightMode?: boolean;
  onToggleNightMode?: () => void;
  onToggleSound: () => void;
  onToggleColorblind: () => void;
}

export const MainMenuModal: React.FC<MainMenuModalProps> = ({
  isOpen,
  onClose,
  playerProfile,
  currentLevel,
  coins,
  soundEnabled,
  isNightMode,
  colorblindMode,
  weeklyStagesCompleted = 0,
  hasDailyRewardAvailable = false,
  hasDiceRollAvailable = true,
  hasDailyTipAvailable = false,
  isDebtActive = false,
  hasUpdateAvailable = false,
  onOpenRegister,
  onOpenShop,
  onOpenNeighborhood,
  onOpenSpecialGuest,
  onOpenWeeklyChallenge,
  onOpenDailyReward,
  onOpenRadio,
  onOpenGuide,
  onOpenContact,
  onOpenDaftarHesab,
  onOpenNaghali,
  onOpenRenovations,
  onOpenPatogh,
  onOpenSiniGardani,
  onOpenTakhtehNard,
  onOpenPahlavaniCard,
  onOpenNightMystery,
  onOpenAchievements,
  onOpenAiLimit,
  onOpenInstall,
  onCheckUpdate,
  onToggleSound,
  onToggleNightMode,
  onToggleColorblind,
}) => {
  if (!isOpen) return null;

  const handleAction = (action?: () => void) => {
    if (!action) return;
    soundEngine.playClick();
    onClose();
    setTimeout(() => {
      action();
    }, 120);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none"
      style={{ paddingTop: 'max(env(safe-area-inset-top, 24px), 1.5rem)' }}
    >
      <div className="relative w-full max-w-sm max-h-[88vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300 font-lalezar text-sm">
                ☰
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                منوی چایخانه عمو بهمن
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                رویدادها، نسیه، پاتوق‌ها و امکانات بازی
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
            title="بستن منو"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto pr-0.5 pl-0.5 py-2.5 space-y-3 custom-scrollbar">
          {/* Authentic Persian Traditional Teahouse Hero Showcase Banner */}
          <div className="relative rounded-2xl overflow-hidden border-2 border-amber-500/60 shadow-lg bg-[#1B0C05]">
            <div className="relative h-28 w-full overflow-hidden">
              <img
                src={teahouseBannerImg}
                alt="صفای چایخانه سنتی عمو بهمن"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover brightness-90 transform hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1B0C05] via-[#1B0C05]/40 to-transparent" />
              
              {/* Uncle Bahman authentic seal */}
              <div className="absolute bottom-2 right-2.5 flex items-center gap-2">
                <div className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 shadow-lg">
                  <img
                    src={bahmanAvatarImg}
                    alt="اوستا بهمن"
                    referrerPolicy="no-referrer"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div className="text-right drop-shadow-md">
                  <span className="font-lalezar text-xs text-yellow-300 block">
                    چایخانه سنتی عمو بهمن
                  </span>
                  <span className="text-[9px] font-vazir text-amber-100/90 block">
                    «خوش‌آمدی پهلوون! صفا آوردی به محله»
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* User Profile Banner with Selected Avatar, Province & City */}
          {(() => {
            const playerAvatar = getAvatarById(playerProfile?.avatarId);
            const userProv = playerProfile?.province || 'تهران';
            const userCity = playerProfile?.city || 'تهران';

            return (
              <div className="p-3 rounded-2xl bg-gradient-to-r from-[#3D1E0C] to-[#251107] border border-amber-500/50 shadow-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    {/* User Selected Avatar */}
                    <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 flex items-center justify-center shadow shrink-0">
                      {playerAvatar.image ? (
                        <img
                          src={playerAvatar.image}
                          alt={playerAvatar.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        <div className={`w-full h-full rounded-full bg-gradient-to-tr ${playerAvatar.bgGradient} flex items-center justify-center text-lg`}>
                          {playerAvatar.emoji}
                        </div>
                      )}
                    </div>

                    <div className="text-right">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-lalezar text-sm text-yellow-200">
                          {playerProfile?.isRegistered && playerProfile.firstName
                            ? `${playerProfile.firstName} ${playerProfile.lastName}`
                            : 'اوستای چایخانه'}
                        </span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-yellow-300 border border-amber-600 font-vazir">
                          {playerAvatar.badge}
                        </span>
                        {(() => {
                          const activeBadge = getBadgeById(playerProfile?.activeBadgeId);
                          if (activeBadge) {
                            return (
                              <span className="text-[9px] px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-amber-950 font-lalezar font-bold shadow flex items-center gap-1">
                                <span>{activeBadge.icon}</span>
                                <span>{activeBadge.title}</span>
                              </span>
                            );
                          }
                          return null;
                        })()}
                      </div>
                      <div className="text-[10px] text-amber-200/80 font-vazir flex items-center gap-1.5 mt-0.5">
                        <span>مرحله {toPersianDigits(currentLevel)}</span>
                        <span>•</span>
                        <span>{formatPersianCoins(coins)} سکه ★</span>
                        <span>•</span>
                        <span className="text-teal-300 font-bold">{userCity} ({userProv})</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions: Edit Profile Box / View Card / Badges */}
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => onOpenRegister && handleAction(onOpenRegister)}
                      className="px-2.5 py-1 rounded-xl bg-amber-600 hover:bg-amber-500 text-amber-950 font-lalezar text-[11px] font-bold shadow transition-all active:scale-95 cursor-pointer"
                    >
                      باکس عضویت ✏️
                    </button>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onOpenPahlavaniCard && handleAction(onOpenPahlavaniCard)}
                        className="flex-1 px-1.5 py-0.5 rounded-xl bg-[#200F05] text-amber-300 hover:text-white border border-amber-700 font-vazir text-[9px] transition-all cursor-pointer text-center"
                      >
                        کارت
                      </button>
                      {onOpenAchievements && (
                        <button
                          onClick={() => handleAction(onOpenAchievements)}
                          className="flex-1 px-1.5 py-0.5 rounded-xl bg-amber-900/80 text-yellow-300 hover:text-white border border-yellow-500/60 font-vazir text-[9px] transition-all cursor-pointer flex items-center justify-center gap-0.5 shadow-sm"
                          title="مدال‌ها و دستاوردها"
                        >
                          <Award className="w-2.5 h-2.5 text-yellow-400" />
                          <span>مدال</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Prominent Install Estekan App Card */}
          {onOpenInstall && (
            <div
              onClick={() => handleAction(onOpenInstall)}
              className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950 via-[#133324] to-emerald-950 border-2 border-emerald-400 flex items-center justify-between cursor-pointer hover:brightness-110 active:scale-98 transition-all shadow-[0_4px_16px_rgba(16,185,129,0.3)] animate-pulse"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl overflow-hidden border-2 border-yellow-400 shrink-0 shadow">
                  <img src="/pwa-192x192.png" alt="استکان" className="w-full h-full object-cover" />
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1.5">
                    <span className="font-lalezar text-sm text-yellow-300 block">
                      نصب مستقیم اپلیکیشن «استکان» روی گوشی
                    </span>
                    <span className="text-[9px] bg-emerald-500 text-stone-950 font-bold px-1.5 py-0.2 rounded-full font-sans">
                      PWA
                    </span>
                  </div>
                  <span className="text-[10px] text-emerald-200/90 font-vazir block">
                    با آیکون زرین استکان • اجرای سریع بدون لگ و آفلاین
                  </span>
                </div>
              </div>
              <span className="text-xs font-lalezar px-2.5 py-1.5 rounded-xl bg-emerald-500 text-stone-950 font-bold shadow hover:bg-emerald-400 transition-colors">
                نصب 📲
              </span>
            </div>
          )}

          {/* Section 1: Mini-games & Events */}
          <div>
            <div className="text-[11px] font-lalezar text-amber-400 mb-1.5 px-1 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-yellow-400" />
              <span>بازی‌ها و رویدادهای ویژه</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {/* Backgammon Dice Roll */}
              <button
                onClick={() => onOpenTakhtehNard && handleAction(onOpenTakhtehNard)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🎲
                  </div>
                  {hasDiceRollAvailable && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-yellow-400 text-amber-950 font-lalezar animate-bounce">
                      تاس رایگان!
                    </span>
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    تخته‌نرد عمو بهمن
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    جفت شیش و سکه رایگان
                  </span>
                </div>
              </button>

              {/* Shab-haye Naghali (9-piece painting) */}
              <button
                onClick={() => onOpenNaghali && handleAction(onOpenNaghali)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🪘
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-900 text-yellow-200 font-vazir">
                    ۹ قطعه
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    شب‌های نقالی شاهنامه
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    تابلو نقاشی و استکان طلایی
                  </span>
                </div>
              </button>

              {/* Sini-Gardani Mini-game */}
              <button
                onClick={() => onOpenSiniGardani && handleAction(onOpenSiniGardani)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🍽️
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 font-vazir">
                    ۲۰ ثانیه
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    مینی‌گیم سینی‌گردانی
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    تعادل سینی و انعام تا ۱۵۰ سکه
                  </span>
                </div>
              </button>

              {/* Monday Challenge */}
              <button
                onClick={() => onOpenWeeklyChallenge && handleAction(onOpenWeeklyChallenge)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-yellow-300">
                    <Calendar className="w-4 h-4" />
                  </div>
                  {weeklyStagesCompleted < 5 && (
                    <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    چالش دوشنبه‌ها
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    ۵ مرحله با پاداش ۳ برابر
                  </span>
                </div>
              </button>
            </div>

            {/* Night Mystery Safe & Detective Case Card */}
            {onOpenNightMystery && (
              <button
                onClick={() => handleAction(onOpenNightMystery)}
                className="w-full mt-2 p-2.5 rounded-2xl bg-gradient-to-r from-[#28183A] via-[#1E112E] to-[#140B20] hover:border-purple-400 border border-purple-500/60 text-right flex items-center justify-between transition-all active:scale-[0.98] cursor-pointer shadow-md group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-purple-950 border border-purple-400 flex items-center justify-center text-sm shadow">
                    🔐
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5">
                      <span className="font-lalezar text-xs text-purple-200">
                        پرونده‌های شبانه لاله‌زار
                      </span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-purple-900/80 text-yellow-300 font-vazir border border-purple-500/50">
                        تا ۲۵۰ سکه
                      </span>
                    </div>
                    <span className="text-[9px] text-purple-300/70 font-vazir block">
                      گاوصندوق رمزدار و معمای سرقت قندان فیروزه‌ای
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-purple-400 group-hover:-translate-x-1 transition-transform" />
              </button>
            )}

            {/* Pahlavani Achievements & Badges Modal Card */}
            {onOpenAchievements && (
              <button
                onClick={() => handleAction(onOpenAchievements)}
                className="w-full mt-2 p-2.5 rounded-2xl bg-gradient-to-r from-[#3D1E0C] via-[#2A1308] to-[#1E0E06] hover:border-yellow-400 border-2 border-amber-500/80 text-right flex items-center justify-between transition-all active:scale-[0.98] cursor-pointer shadow-md group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 p-0.5 flex items-center justify-center shadow">
                    <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-yellow-300">
                      <Award className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5">
                      <span className="font-lalezar text-xs text-yellow-300">
                        مدال‌ها و دستاوردهای پهلوانی
                      </span>
                      <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 font-vazir border border-amber-600/70">
                        {toPersianDigits(playerProfile?.unlockedBadgeIds?.length || 0)} نشان
                      </span>
                    </div>
                    <span className="text-[9px] text-amber-200/80 font-vazir block">
                      سلطان ۱۰۰ مرحله، اوستای چای‌ریزی، دکور کامل و جوایز سکه
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition-transform" />
              </button>
            )}
          </div>

          {/* Section 2: Economy & Clans */}
          <div>
            <div className="text-[11px] font-lalezar text-amber-400 mb-1.5 px-1 flex items-center gap-1">
              <Store className="w-3.5 h-3.5 text-yellow-400" />
              <span>بازار، نسیه و پاتوق‌ها</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {/* Renovations & Daily Tip Jar */}
              <button
                onClick={() => onOpenRenovations && handleAction(onOpenRenovations)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-sm">
                    🏺
                  </div>
                  {hasDailyTipAvailable && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-amber-950 font-lalezar animate-pulse">
                      دخل آماده!
                    </span>
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    دکور و دخل روزانه
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    ارتقای سماور و سود دخل
                  </span>
                </div>
              </button>

              {/* Daftar-e-Hesab (Credit & Debt) */}
              <button
                onClick={() => onOpenDaftarHesab && handleAction(onOpenDaftarHesab)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm relative"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-yellow-300">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  {isDebtActive ? (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-red-900 text-red-200 font-vazir">
                      بدهکار
                    </span>
                  ) : (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 font-vazir">
                      ۳۰۰ سکه
                    </span>
                  )}
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    نسیه از عمو بهمن
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    دفتر حساب با ۳ برد پیاپی
                  </span>
                </div>
              </button>

              {/* Patogh & Neighborhood Clans (Live server) */}
              <button
                onClick={() => onOpenPatogh && handleAction(onOpenPatogh)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-amber-300">
                    <Users className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 font-vazir">
                    سرور زنده
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    پاتوق‌ها و محله‌ها
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    کلن‌ها، رقابت و سرک کشیدن
                  </span>
                </div>
              </button>

              {/* Retro Radio & Gramophone */}
              <button
                onClick={() => handleAction(onOpenRadio)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#381C0E] border border-amber-500/50 text-right flex flex-col justify-between transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <div className="w-7 h-7 rounded-full bg-amber-950 border border-amber-500 flex items-center justify-center text-amber-300">
                    <Radio className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 font-vazir">
                    ۳ موج
                  </span>
                </div>
                <div>
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    رادیو لامپی ۳ موج
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    تهران قدیم، کوچه‌بازاری و آگهی
                  </span>
                </div>
              </button>
            </div>

            {/* Direct Leaderboard / Competitors Table Button */}
            <button
              onClick={() => handleAction(onOpenNeighborhood)}
              className="w-full mt-2 p-2.5 rounded-2xl bg-gradient-to-r from-[#3D1E0C] via-[#2A1408] to-[#1E0D05] hover:border-amber-400 border-2 border-amber-500/70 text-right flex items-center justify-between transition-all active:scale-[0.98] cursor-pointer shadow-md group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-400 p-0.5 flex items-center justify-center text-amber-950 font-bold shadow">
                  🏆
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1.5">
                    <span className="font-lalezar text-xs text-yellow-200">
                      جدول رقبا و رتبه‌بندی استانی
                    </span>
                    <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 font-vazir border border-amber-600">
                      کل کشور، استان و شهر
                    </span>
                  </div>
                  <span className="text-[9px] text-amber-200/70 font-vazir block">
                    مشاهده رتبه، امتیازها و ارسال ایموجی معرفتی به رقبا
                  </span>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Section 3: Settings & Support */}
          <div className="space-y-1.5 pt-1">
            <div className="text-[11px] font-lalezar text-amber-400 mb-1 px-1">
              تنظیمات و پشتیبانی
            </div>

            {/* Colorblind Toggle */}
            <div
              onClick={() => {
                soundEngine.playClick();
                onToggleColorblind();
              }}
              className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-600/30 flex items-center justify-between cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    colorblindMode
                      ? 'bg-amber-500 text-amber-950'
                      : 'bg-amber-950 text-amber-300 border border-amber-600/50'
                  }`}
                >
                  <Eye className="w-4 h-4" />
                </div>
                <div className="text-right">
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    حالت دسترس‌پذیری رنگ‌ها
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    نمایش نمادهای کمکی روی لایه‌ها
                  </span>
                </div>
              </div>
              <span
                className={`text-[10px] font-lalezar px-2 py-0.5 rounded-full ${
                  colorblindMode ? 'bg-amber-500 text-amber-950' : 'bg-amber-950 text-amber-400'
                }`}
              >
                {colorblindMode ? 'روشن' : 'خاموش'}
              </span>
            </div>

            {/* Sound Toggle */}
            <div
              onClick={() => {
                soundEngine.playClick();
                onToggleSound();
              }}
              className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-600/30 flex items-center justify-between cursor-pointer transition-all"
            >
              <div className="flex items-center gap-2">
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    soundEnabled
                      ? 'bg-amber-950 text-amber-300 border border-amber-600/50'
                      : 'bg-red-950 text-red-300 border border-red-600/50'
                  }`}
                >
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </div>
                <div className="text-right">
                  <span className="font-lalezar text-xs text-yellow-200 block">
                    صدای بازی و سماور
                  </span>
                  <span className="text-[9px] text-amber-200/70 font-vazir">
                    موسیقی سنتی و افکت‌های صوتی
                  </span>
                </div>
              </div>
              <span
                className={`text-[10px] font-lalezar px-2.5 py-0.5 rounded-full ${
                  soundEnabled ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60' : 'bg-red-950 text-red-300 border border-red-700/60'
                }`}
              >
                {soundEnabled ? 'روشن' : 'بی‌صدا'}
              </span>
            </div>

            {/* Cozy Night Mode Toggle (حالت شب و چراغ روغنی / روز) */}
            {onToggleNightMode && (
              <div
                onClick={() => {
                  soundEngine.playClick();
                  onToggleNightMode();
                }}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-600/30 flex items-center justify-between cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center ${
                      isNightMode
                        ? 'bg-indigo-950 text-indigo-300 border border-indigo-600/60'
                        : 'bg-amber-950 text-amber-300 border border-amber-600/50'
                    }`}
                  >
                    {isNightMode ? <Moon className="w-4 h-4 text-indigo-300" /> : <Sun className="w-4 h-4 text-amber-300" />}
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-yellow-200 block">
                      حالت شب و چراغ روغنی
                    </span>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      نور ملایم گرم و آرامش چایخانه در شب
                    </span>
                  </div>
                </div>
                <span
                  className={`text-[10px] font-lalezar px-2.5 py-0.5 rounded-full ${
                    isNightMode
                      ? 'bg-indigo-950 text-indigo-300 border border-indigo-700/60'
                      : 'bg-amber-950 text-amber-300 border border-amber-700/60'
                  }`}
                >
                  {isNightMode ? 'حالت شب 🌙' : 'حالت روز ☀️'}
                </span>
              </div>
            )}

            {/* AI Solver Brain Quota Row (قانون ۳ مرحله در هر ساعت) */}
            {onOpenAiLimit && (
              <div
                onClick={() => handleAction(onOpenAiLimit)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-500/40 flex items-center justify-between cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-amber-950 text-amber-300 border border-amber-500/50 flex items-center justify-center">
                    <Brain className="w-4 h-4 text-yellow-400" />
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-yellow-200 block">
                      هوش مصنوعی و سهمیه حل ۳ مرحله
                    </span>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      موتور هوشمند چندگانه (۳ مرحله در هر ۱ ساعت)
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-lalezar px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-700/60">
                  وضعیت سهمیه ↵
                </span>
              </div>
            )}

            {/* Game Guide & Rules Row */}
            {onOpenGuide && (
              <div
                onClick={() => handleAction(onOpenGuide)}
                className="p-2.5 rounded-2xl bg-[#28140A] hover:bg-[#33190C] border border-amber-500/40 flex items-center justify-between cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-amber-950 text-amber-300 border border-amber-500/50 flex items-center justify-center">
                    <HelpCircle className="w-4 h-4 text-yellow-400" />
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-yellow-200 block">
                      راهنمای بازی و قوانین چایخانه
                    </span>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      قند حبه، دکمه‌های کمکی و ترفندها
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-lalezar px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-700/60">
                  مشاهده ↵
                </span>
              </div>
            )}

            {/* Direct In-App APK Update Row */}
            {onCheckUpdate && (
              <div
                onClick={() => handleAction(onCheckUpdate)}
                className={`p-2.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                  hasUpdateAvailable
                    ? 'bg-gradient-to-r from-amber-600/30 via-yellow-600/20 to-amber-600/30 border-yellow-400 ring-1 ring-yellow-400/50 shadow-md animate-pulse'
                    : 'bg-[#28140A] hover:bg-[#381C0E] border-amber-600/30'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center ${
                      hasUpdateAvailable
                        ? 'bg-gradient-to-tr from-yellow-400 to-amber-500 text-amber-950 font-bold shadow'
                        : 'bg-amber-950 border border-amber-500/60 text-amber-300'
                    }`}
                  >
                    <Download className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5">
                      <span className="font-lalezar text-xs text-yellow-200 block">
                        بروزرسانی مستقیم درون‌برنامه‌ای
                      </span>
                      {hasUpdateAvailable && (
                        <span className="text-[9px] bg-red-600 text-white px-1.5 py-0.2 rounded-full font-bold">
                          نسخه جدید!
                        </span>
                      )}
                    </div>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      دانلود فایل APK بدون نیاز به بازار و گوگل‌پلی (نسخه فعلی {toPersianDigits(APP_VERSION)})
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-amber-300" />
              </div>
            )}

            {/* Contact Row */}
            {onOpenContact && (
              <div
                onClick={() => handleAction(onOpenContact)}
                className="p-2.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 to-[#193223] border border-emerald-500/50 flex items-center justify-between cursor-pointer hover:brightness-110 transition-all"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-900 border border-emerald-400/60 flex items-center justify-center text-emerald-300">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-emerald-200 block">
                      ارتباط با طراح بازی: مهندس بهمن بامزد
                    </span>
                    <span className="text-[9px] text-emerald-300/80 font-vazir">
                      bahmanbamzad.ir • ۰۹۱۱۵۶۶۴۲۷۱
                    </span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-emerald-300" />
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center flex items-center justify-between px-2 text-[10px] text-amber-300/60 font-vazir">
          <span>طراحی اختصاصی چایخانه عمو بهمن • مهندس بهمن بامزد</span>
          <span className="font-vazir text-amber-400/80">نسخه {toPersianDigits(APP_CURRENT_VERSION)}</span>
        </div>
      </div>
    </div>
  );
};
