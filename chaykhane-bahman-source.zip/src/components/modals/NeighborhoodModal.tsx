import React, { useState, useEffect } from 'react';
import {
  X,
  Trophy,
  Users,
  Shield,
  Sparkles,
  UserCheck,
  RefreshCw,
  Radio,
  Calendar,
  Gift,
  MapPin,
  Heart,
  Smile,
  ShieldAlert,
} from 'lucide-react';
import { MahallehMember, PlayerProfile } from '../../types';
import { formatPersianCoins, toPersianDigits } from '../../utils/persianNumbers';
import { soundEngine } from '../../audio/SoundEngine';
import {
  fetchLiveLeaderboard,
  getStoredPlayerProfile,
  sendEmojiReactionToServer,
  ALLOWED_REACTION_EMOJIS,
  ReactionEmoji,
} from '../../services/backendApi';
import {
  getWeeklyChallengeState,
  getWeeklyLeaderboard,
  getTimeRemainingUntilMonday,
} from '../../game/WeeklyChallengeService';
import { getAvatarById } from '../../constants/avatars';
import {
  getBadgeById,
  incrementEmojisSentCount,
} from '../../services/PahlavaniAchievements';

interface NeighborhoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerLevel: number;
  playerScore?: number;
  onOpenRegister?: () => void;
  playerProfile?: PlayerProfile;
  onOpenWeeklyChallenge?: () => void;
  initialTab?: 'competitors' | 'weekly';
}

const DEFAULT_COMPETITORS: MahallehMember[] = [
  {
    id: 'comp_1',
    name: 'داش آکل شیرازی',
    firstName: 'آکل',
    lastName: 'شیرازی',
    province: 'فارس',
    city: 'شیراز',
    avatarId: 'pahlevan_ghafour',
    score: 4120,
    cupsServed: 142,
    level: 16,
    rank: 1,
    badge: '👑 قهرمان کشور',
    avatarSeed: 1,
    emojisReceived: { '☕': 34, '🔥': 28, '🦁': 19 },
  },
  {
    id: 'comp_2',
    name: 'طیّب خان سنگلجی',
    firstName: 'طیّب',
    lastName: 'حاج‌رضایی',
    province: 'تهران',
    city: 'تهران',
    avatarId: 'tayyeb_khan',
    score: 3680,
    cupsServed: 124,
    level: 14,
    rank: 2,
    badge: '🥈 سماور نقره',
    avatarSeed: 2,
    emojisReceived: { '💪': 42, '🫖': 25, '👏': 16 },
  },
  {
    id: 'comp_3',
    name: 'حاج مصطفی بلورفروش',
    firstName: 'مصطفی',
    lastName: 'بلورچی',
    province: 'اصفهان',
    city: 'اصفهان',
    avatarId: 'osta_bahman',
    score: 3350,
    cupsServed: 110,
    level: 13,
    rank: 3,
    badge: '🥉 سماور برنز',
    avatarSeed: 3,
    emojisReceived: { '🏆': 31, '☕': 22, '🌸': 15 },
  },
  {
    id: 'comp_4',
    name: 'میرزا حبیب تبریزی',
    firstName: 'حبیب',
    lastName: 'ادیب‌زاده',
    province: 'آذربایجان شرقی',
    city: 'تبریز',
    avatarId: 'mirza_habib',
    score: 2940,
    cupsServed: 98,
    level: 11,
    rank: 4,
    badge: 'اوستای کهن',
    avatarSeed: 4,
    emojisReceived: { '👏': 19, '🫖': 14 },
  },
  {
    id: 'comp_5',
    name: 'بی‌بی گلنار گیلانی',
    firstName: 'گلنار',
    lastName: 'لاهیجانی',
    province: 'گیلان',
    city: 'لاهیجان',
    avatarId: 'bibi_jan',
    score: 2710,
    cupsServed: 89,
    level: 10,
    rank: 5,
    badge: 'بانوی چای',
    avatarSeed: 5,
    emojisReceived: { '🌸': 38, '☕': 26 },
  },
  {
    id: 'comp_6',
    name: 'فریدون راننده ترانزیت',
    firstName: 'فریدون',
    lastName: 'شاهرودی',
    province: 'سمنان',
    city: 'شاهرود',
    avatarId: 'sohrab_ranandeh',
    score: 2450,
    cupsServed: 81,
    level: 9,
    rank: 6,
    badge: 'راننده باصفا',
    avatarSeed: 6,
    emojisReceived: { '🔥': 20, '💪': 17 },
  },
  {
    id: 'comp_7',
    name: 'شاطر عباس قمی',
    firstName: 'عباس',
    lastName: 'قناد',
    province: 'قم',
    city: 'قم',
    avatarId: 'shater_abbas',
    score: 2190,
    cupsServed: 74,
    level: 8,
    rank: 7,
    badge: 'شاطر باصفا',
    avatarSeed: 7,
    emojisReceived: { '☕': 18, '👏': 12 },
  },
  {
    id: 'comp_8',
    name: 'مشتی صفر درشکه‌چی',
    firstName: 'صفر',
    lastName: 'امیری',
    province: 'خراسان رضوی',
    city: 'مشهد',
    avatarId: 'mashti_jafar',
    score: 1980,
    cupsServed: 66,
    level: 7,
    rank: 8,
    badge: 'اوستای چایخانه',
    avatarSeed: 8,
    emojisReceived: { '🫖': 14, '❤️': 11 },
  },
];

const EMOJI_LABELS: Record<string, string> = {
  '☕': 'چای داغ',
  '🫖': 'قوری زعفرانی',
  '👏': 'دست‌مریزاد',
  '🏆': 'جام پهلوانی',
  '🔥': 'دمت گرم',
  '💪': 'خداقوت',
  '❤️': 'صفای دلت',
  '🦁': 'شیر بیشه',
  '🌸': 'گلاب ناب',
};

export const NeighborhoodModal: React.FC<NeighborhoodModalProps> = ({
  isOpen,
  onClose,
  playerLevel,
  playerScore = 1850,
  onOpenRegister,
  playerProfile,
  onOpenWeeklyChallenge,
  initialTab = 'competitors',
}) => {
  const [activeTab, setActiveTab] = useState<'competitors' | 'weekly'>(initialTab);
  const [scopeFilter, setScopeFilter] = useState<'all' | 'province' | 'city'>('all');
  const [leaderboard, setLeaderboard] = useState<MahallehMember[]>(DEFAULT_COMPETITORS);
  const [isLiveServer, setIsLiveServer] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [timeRemaining, setTimeRemaining] = useState(getTimeRemainingUntilMonday());

  // Emoji sending state
  const [targetMemberForEmoji, setTargetMemberForEmoji] = useState<MahallehMember | null>(null);
  const [emojiToast, setEmojiToast] = useState<string | null>(null);
  const [flyingEmoji, setFlyingEmoji] = useState<string | null>(null);

  const profile = playerProfile || getStoredPlayerProfile();
  const playerProvince = profile.province || 'تهران';
  const playerCity = profile.city || 'تهران';
  const displayName =
    profile.isRegistered && profile.firstName
      ? `${profile.firstName} ${profile.lastName}`.trim()
      : profile.nickname || 'اوستای چایخانه (شما)';

  // Weekly Challenge state
  const weeklyState = getWeeklyChallengeState();
  const { leaderboard: weeklyLeaderboard, playerRank: weeklyPlayerRank } =
    getWeeklyLeaderboard(displayName, weeklyState.weeklyScore, weeklyState.completedStageIds.length);

  useEffect(() => {
    if (!isOpen) return;
    setTimeRemaining(getTimeRemainingUntilMonday());
    const interval = setInterval(() => {
      setTimeRemaining(getTimeRemainingUntilMonday());
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Load Leaderboard from Live Server or Local DB with Filters
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    setIsLoading(true);

    const filters =
      scopeFilter === 'province'
        ? { province: playerProvince }
        : scopeFilter === 'city'
        ? { province: playerProvince, city: playerCity }
        : undefined;

    fetchLiveLeaderboard(filters)
      .then((res) => {
        if (!isMounted) return;
        setIsLoading(false);

        // Current User Row
        const userEntry: MahallehMember = {
          id: 'user_current',
          name: `${displayName} (شما)`,
          firstName: profile.firstName,
          lastName: profile.lastName,
          avatarId: profile.avatarId || 'osta_bahman',
          province: playerProvince,
          city: playerCity,
          score: playerScore,
          cupsServed: Math.floor(playerScore / 30) + playerLevel,
          level: playerLevel,
          rank: 1,
          badge: profile.isRegistered ? '✨ اوستای ثبت‌شده' : 'عضو نوپا',
          avatarSeed: 4,
          emojisReceived: profile.emojisReceived || { '☕': 5, '🔥': 3 },
        };

        if (res.isLive && res.topUsers.length > 0) {
          setIsLiveServer(true);
          const hasUser = res.topUsers.some((u) => u.name === displayName);
          const fullList = hasUser ? res.topUsers : [...res.topUsers, userEntry];
          const sorted = fullList.sort((a, b) => b.score - a.score).map((u, i) => ({ ...u, rank: i + 1 }));
          setLeaderboard(sorted);
        } else {
          setIsLiveServer(false);
          // Filter default competitors locally by province or city if selected
          let pool = [...DEFAULT_COMPETITORS];
          if (scopeFilter === 'province') {
            pool = pool.filter((c) => c.province === playerProvince);
            if (pool.length < 3) {
              // Add mock co-provincials so the list is always populated
              pool.push(
                {
                  id: 'prov_extra_1',
                  name: `مشتی رضا ${playerProvince}`,
                  province: playerProvince,
                  city: playerCity,
                  avatarId: 'shater_abbas',
                  score: 2300,
                  cupsServed: 78,
                  level: 8,
                  rank: 2,
                  badge: `پهلوان ${playerProvince}`,
                  avatarSeed: 3,
                  emojisReceived: { '☕': 12 },
                },
                {
                  id: 'prov_extra_2',
                  name: `داش کریم ${playerCity}`,
                  province: playerProvince,
                  city: playerCity,
                  avatarId: 'pahlevan_ghafour',
                  score: 1750,
                  cupsServed: 54,
                  level: 6,
                  rank: 3,
                  badge: 'اوستای محل',
                  avatarSeed: 5,
                  emojisReceived: { '🦁': 7 },
                }
              );
            }
          } else if (scopeFilter === 'city') {
            pool = pool.filter((c) => c.city === playerCity);
            if (pool.length < 2) {
              pool.push({
                id: 'city_extra_1',
                name: `اوستا حیدر ${playerCity}`,
                province: playerProvince,
                city: playerCity,
                avatarId: 'osta_bahman',
                score: 1650,
                cupsServed: 48,
                level: 5,
                rank: 2,
                badge: `افتخار ${playerCity}`,
                avatarSeed: 2,
                emojisReceived: { '🫖': 9 },
              });
            }
          }

          const sorted = [...pool, userEntry]
            .sort((a, b) => b.score - a.score)
            .map((u, i) => ({ ...u, rank: i + 1 }));
          setLeaderboard(sorted);
        }
      })
      .catch(() => {
        if (isMounted) {
          setIsLoading(false);
          setIsLiveServer(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, scopeFilter, displayName, playerScore, playerLevel, playerProvince, playerCity, profile]);

  if (!isOpen) return null;

  const handleSendEmoji = async (emoji: ReactionEmoji) => {
    if (!targetMemberForEmoji) return;
    soundEngine.playCoins();
    setFlyingEmoji(emoji);
    setTimeout(() => setFlyingEmoji(null), 1200);

    const target = targetMemberForEmoji;
    setTargetMemberForEmoji(null);

    // Update member's local count immediately for snappy feel
    setLeaderboard((prev) =>
      prev.map((m) => {
        if (m.id === target.id) {
          const emojis = { ...(m.emojisReceived || {}) };
          emojis[emoji] = (emojis[emoji] || 0) + 1;
          return { ...m, emojisReceived: emojis };
        }
        return m;
      })
    );

    setEmojiToast(`ایموجی ${emoji} (${EMOJI_LABELS[emoji]}) برای «${target.name}» فرستاده شد!`);
    setTimeout(() => setEmojiToast(null), 3000);

    incrementEmojisSentCount();
    await sendEmojiReactionToServer(target.id, emoji);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none"
      style={{ paddingTop: 'max(env(safe-area-inset-top, 24px), 1.5rem)' }}
    >
      <div className="relative w-full max-w-md max-h-[88vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#D97706] shadow-2xl text-[#FFFBF0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-400 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Trophy className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                جدول رقبا و رتبه‌بندی چایخانه
              </h2>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px] text-amber-200/70 font-vazir">
                  دیتای آنلاین دیتابیس
                </span>
                {isLiveServer ? (
                  <span className="inline-flex items-center gap-1 text-[9px] bg-emerald-950/80 text-emerald-300 px-2 py-0.2 rounded-full border border-emerald-500 font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    سرور زنده
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[9px] bg-amber-950/80 text-amber-300/80 px-2 py-0.2 rounded-full border border-amber-700">
                    <Radio className="w-2.5 h-2.5" />
                    همگام آنلاین
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Strict Anti-Chat & Content Safety Policy Notice */}
        <div className="mt-2.5 px-3 py-1.5 rounded-xl bg-amber-950/70 border border-amber-600/40 text-[10px] font-vazir text-amber-200 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            <b>قوانین ارتباطات:</b> چت متنی یا خصوصی به دلیل قوانین بسته است؛ تعامل صرفاً با ارسال <b>ایموجی‌های معرفتی</b> انجام می‌شود.
          </span>
        </div>

        {/* Tab 1 (جدول رقبا) vs Tab 2 (چالش هفتگی) */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-[#1A0B04] border border-amber-700/50 my-2.5 text-center">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('competitors');
            }}
            className={`py-1.5 rounded-xl font-lalezar text-xs cursor-pointer transition-all ${
              activeTab === 'competitors'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow-md'
                : 'text-amber-300 hover:text-amber-100'
            }`}
          >
            🏆 جدول رقبا (استانی و کشوری)
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('weekly');
            }}
            className={`py-1.5 rounded-xl font-lalezar text-xs cursor-pointer transition-all ${
              activeTab === 'weekly'
                ? 'bg-gradient-to-r from-teal-600 to-emerald-500 text-white font-bold shadow-md'
                : 'text-teal-300 hover:text-teal-100'
            }`}
          >
            📅 لیگ دوشنبه‌ها
          </button>
        </div>

        {/* Scrollable Container */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-0.5 custom-scrollbar">
          {activeTab === 'competitors' ? (
            <div>
              {/* Province / City Scope Filter Chips */}
              <div className="flex items-center justify-between gap-1.5 p-1 rounded-xl bg-[#200F05] border border-amber-700/40 mb-2.5">
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    setScopeFilter('all');
                  }}
                  className={`flex-1 py-1 rounded-lg font-lalezar text-[11px] transition-all cursor-pointer ${
                    scopeFilter === 'all'
                      ? 'bg-amber-500 text-amber-950 font-bold shadow'
                      : 'text-amber-300 hover:text-amber-100'
                  }`}
                >
                  🇮🇷 کل کشور
                </button>
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    setScopeFilter('province');
                  }}
                  className={`flex-1 py-1 rounded-lg font-lalezar text-[11px] transition-all cursor-pointer ${
                    scopeFilter === 'province'
                      ? 'bg-amber-500 text-amber-950 font-bold shadow'
                      : 'text-amber-300 hover:text-amber-100'
                  }`}
                >
                  📍 استان {playerProvince}
                </button>
                <button
                  onClick={() => {
                    soundEngine.playClick();
                    setScopeFilter('city');
                  }}
                  className={`flex-1 py-1 rounded-lg font-lalezar text-[11px] transition-all cursor-pointer ${
                    scopeFilter === 'city'
                      ? 'bg-amber-500 text-amber-950 font-bold shadow'
                      : 'text-amber-300 hover:text-amber-100'
                  }`}
                >
                  🏙️ شهر {playerCity}
                </button>
              </div>

              {/* Privacy and No-Chat Policy Banner */}
              <div className="mb-2 p-2 rounded-xl bg-[#140803]/90 border border-amber-600/40 text-[10px] text-amber-200 font-vazir flex items-center justify-between gap-1.5 leading-relaxed">
                <div className="flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>
                    <b>قوانین اخلاقی و حریم خصوصی:</b> چت متنی، گروهی یا خصوصی کاملاً غیرفعال است و ارتباط بین رقبا صرفاً با ارسال ایموجی‌های پهلوانی انجام می‌شود.
                  </span>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/50 whitespace-nowrap font-lalezar">
                  فقط ایموجی ✓
                </span>
              </div>

              {/* Unregistered Member Callout Banner */}
              {!profile.isRegistered && onOpenRegister && (
                <div
                  onClick={() => {
                    soundEngine.playClick();
                    onOpenRegister();
                  }}
                  className="p-2.5 rounded-2xl bg-gradient-to-r from-teal-950 via-teal-900 to-[#0A2E2A] border-2 border-teal-400 text-teal-100 flex items-center justify-between cursor-pointer hover:border-yellow-400 transition-all mb-2 shadow-md group"
                >
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-teal-300 shrink-0" />
                    <div className="text-right">
                      <span className="font-lalezar text-xs text-yellow-300 block">
                        عضویت در جدول رقبا (ثبت نام، استان و شهر)
                      </span>
                      <span className="text-[10px] text-teal-200/80 font-vazir">
                        تصویر شاخص سنتی خود را انتخاب کنید و در رده‌بندی بدرخشید
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-lg bg-teal-800 border border-teal-300 text-white font-lalezar group-hover:scale-105 transition-transform">
                    ثبت‌نام ↵
                  </span>
                </div>
              )}

              {/* Registered Member Quick Edit Profile Banner */}
              {profile.isRegistered && onOpenRegister && (
                <div
                  onClick={() => {
                    soundEngine.playClick();
                    onOpenRegister();
                  }}
                  className="p-2 rounded-xl bg-amber-950/60 border border-amber-600/50 text-amber-200 flex items-center justify-between cursor-pointer hover:border-yellow-400 transition-all mb-2 shadow-sm text-xs"
                >
                  <div className="flex items-center gap-1.5 font-vazir text-[11px]">
                    <UserCheck className="w-3.5 h-3.5 text-teal-400" />
                    <span>پروفایل شما: <b>{displayName}</b> • استان {playerProvince}، شهر {playerCity}</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-lg bg-amber-800 text-yellow-300 font-lalezar hover:bg-amber-700">
                    ویرایش مشخصات ✏️
                  </span>
                </div>
              )}

              {/* Table Header */}
              <div className="flex items-center justify-between px-2.5 py-1 text-[10px] text-amber-300/70 font-vazir">
                <span>رتبه و اوستا</span>
                <div className="flex items-center gap-4">
                  <span>موقعیت</span>
                  <span>امتیاز و واکنش</span>
                </div>
              </div>

              {/* Competitors List */}
              <div className="space-y-1.5">
                {leaderboard.map((member) => {
                  const isUser = member.id === 'user_current' || member.name.includes('(شما)');
                  const avatar = getAvatarById(member.avatarId);
                  const emojis = member.emojisReceived || {};
                  const topEmojiKey = Object.keys(emojis).sort((a, b) => (emojis[b] || 0) - (emojis[a] || 0))[0];

                  return (
                    <div
                      key={member.id}
                      className={`p-2.5 rounded-2xl border transition-all ${
                        isUser
                          ? 'bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900 border-amber-400 shadow-md ring-2 ring-amber-400/50'
                          : 'bg-[#1C0D05] border-[#3D1E0C] hover:border-amber-600/70'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        {/* Right: Avatar + Rank + Name */}
                        <div className="flex items-center gap-2">
                          {/* Rank badge */}
                          <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center font-lalezar text-xs shrink-0 ${
                              member.rank === 1
                                ? 'bg-yellow-400 text-yellow-950 font-bold shadow-[0_0_8px_rgba(250,204,21,0.6)]'
                                : member.rank === 2
                                ? 'bg-slate-300 text-slate-900 font-bold'
                                : member.rank === 3
                                ? 'bg-amber-700 text-amber-100 font-bold'
                                : 'bg-[#33190C] text-amber-300'
                            }`}
                          >
                            {toPersianDigits(member.rank)}
                          </div>

                          {/* Avatar icon */}
                          <div className="w-9 h-9 rounded-full overflow-hidden bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow flex items-center justify-center shrink-0">
                            {avatar.image ? (
                              <img
                                src={avatar.image}
                                alt={avatar.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              <div className={`w-full h-full rounded-full bg-gradient-to-tr ${avatar.bgGradient} flex items-center justify-center text-sm`}>
                                {avatar.emoji}
                              </div>
                            )}
                          </div>

                          {/* Name + Title */}
                          <div className="text-right">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-lalezar text-xs text-amber-100">
                                {member.name}
                              </span>
                              {isUser && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-yellow-300 border border-amber-600 font-vazir">
                                  شما
                                </span>
                              )}
                              {isUser && (() => {
                                const activeBadge = getBadgeById(profile?.activeBadgeId);
                                if (activeBadge) {
                                  return (
                                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-lalezar font-bold shadow flex items-center gap-0.5">
                                      <span>{activeBadge.icon}</span>
                                      <span>{activeBadge.title}</span>
                                    </span>
                                  );
                                }
                                return null;
                              })()}
                            </div>
                            <span className="text-[9px] text-amber-300/70 font-vazir block">
                              {avatar.name} • {member.badge}
                            </span>
                          </div>
                        </div>

                        {/* Left: Location + Score + Emoji reaction button */}
                        <div className="flex items-center gap-2">
                          {/* Province / City Chip */}
                          <div className="flex flex-col items-end text-[9px] text-amber-300/80 font-vazir">
                            <span className="flex items-center gap-0.5">
                              <MapPin className="w-2.5 h-2.5 text-teal-400" />
                              <span>{member.city || 'تهران'}</span>
                            </span>
                            <span className="text-amber-400/60 text-[8px]">{member.province || 'تهران'}</span>
                          </div>

                          {/* Score */}
                          <div className="min-w-[50px] text-left">
                            <span className="font-lalezar text-xs text-yellow-300 block">
                              {formatPersianCoins(member.score)} ★
                            </span>
                            <span className="text-[9px] text-amber-200/60 font-vazir block">
                              مرحله {toPersianDigits(member.level || member.cupsServed || 1)}
                            </span>
                          </div>

                          {/* Emoji Reaction Action Button */}
                          {!isUser && (
                            <button
                              onClick={() => {
                                soundEngine.playClick();
                                setTargetMemberForEmoji(member);
                              }}
                              className="px-2 py-1 rounded-xl bg-gradient-to-r from-amber-700 via-amber-600 to-yellow-600 hover:brightness-110 active:scale-95 text-amber-950 font-lalezar text-xs flex items-center gap-1 shadow cursor-pointer border border-yellow-300"
                              title="ارسال ایموجی معرفتی به رقیب"
                            >
                              <span>{topEmojiKey || '☕'}</span>
                              <span className="hidden sm:inline">ارسال</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Emojis received row if any */}
                      {Object.keys(emojis).length > 0 && (
                        <div className="mt-1.5 pt-1.5 border-t border-amber-900/40 flex items-center gap-2 text-[10px] text-amber-200/70 font-vazir">
                          <span className="text-[9px] text-amber-400/60">واکنش‌ها:</span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {Object.entries(emojis).map(([em, count]) => (
                              <span
                                key={em}
                                className="px-1.5 py-0.5 rounded-md bg-[#120703] border border-amber-800/40 text-[10px] flex items-center gap-0.5 text-amber-200"
                              >
                                <span>{em}</span>
                                <span className="font-lalezar text-yellow-300 text-[9px]">{toPersianDigits(count)}</span>
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* TAB 2: WEEKLY LEAGUE CHALLENGE */
            <div className="space-y-2.5 animate-fade-in">
              {/* Weekly Performance Card */}
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/80 via-[#2A150A] to-amber-950/80 border-2 border-amber-400/80 shadow-md">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] text-amber-300 font-vazir">
                    کارنامه هفتگی شما ({displayName}):
                  </span>
                  <span className="font-lalezar text-xs text-yellow-300 bg-[#160803] px-2 py-0.5 rounded-lg border border-amber-700">
                    رتبه #{toPersianDigits(weeklyPlayerRank)} در جدول
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center pt-1">
                  <div className="bg-[#180A04]/80 p-1.5 rounded-xl border border-amber-900/60">
                    <span className="text-[9px] text-amber-300/70 block font-vazir">امتیاز چالش</span>
                    <span className="font-lalezar text-sm text-yellow-300 font-bold">
                      {toPersianDigits(weeklyState.weeklyScore)} ★
                    </span>
                  </div>

                  <div className="bg-[#180A04]/80 p-1.5 rounded-xl border border-amber-900/60">
                    <span className="text-[9px] text-amber-300/70 block font-vazir">مراحل حل‌شده</span>
                    <span className="font-lalezar text-sm text-amber-100 font-bold">
                      {toPersianDigits(weeklyState.completedStageIds.length)} از ۵
                    </span>
                  </div>

                  <div className="bg-[#180A04]/80 p-1.5 rounded-xl border border-amber-900/60">
                    <span className="text-[9px] text-amber-300/70 block font-vazir">پاداش نهایی</span>
                    <span className="font-lalezar text-xs text-emerald-400 font-bold">
                      {weeklyPlayerRank === 1
                        ? '۲۵۰۰ سکه 👑'
                        : weeklyPlayerRank <= 3
                        ? '۱۵۰۰ سکه 🥈'
                        : weeklyPlayerRank <= 10
                        ? '۵۰۰ سکه 🎖️'
                        : '۲۵۰ سکه'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Weekly Reward Tiers */}
              <div className="p-2.5 rounded-2xl bg-[#180A04] border border-[#3E1E0F] text-[10px] font-vazir text-amber-200/80">
                <div className="flex items-center gap-1 text-amber-300 font-lalezar text-xs mb-1">
                  <Gift className="w-3.5 h-3.5" />
                  <span>جوایز اهدایی در بامداد هر دوشنبه:</span>
                </div>
                <div className="flex items-center justify-between text-[10px] pt-1 border-t border-amber-950/80">
                  <span>🥇 رتبه ۱: ۲۵۰۰ سکه</span>
                  <span>🥈 رتبه ۲: ۱۵۰۰ سکه</span>
                  <span>🥉 رتبه ۳: ۱۰۰۰ سکه</span>
                  <span>🎖️ ۴ تا ۱۰: ۵۰۰ سکه</span>
                </div>
              </div>

              {/* Weekly Competitors List */}
              <div className="space-y-1.5">
                {weeklyLeaderboard.map((member) => {
                  const isUser = member.isCurrentPlayer;

                  return (
                    <div
                      key={member.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                        isUser
                          ? 'bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900 border-amber-400 shadow-md text-amber-100 ring-2 ring-amber-400/60'
                          : 'bg-[#1F0F06] border-[#3D1E0C] text-[#FFE8D6]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center font-lalezar text-xs shrink-0 ${
                            member.rank === 1
                              ? 'bg-yellow-400 text-yellow-950 font-bold'
                              : member.rank === 2
                              ? 'bg-slate-300 text-slate-900 font-bold'
                              : member.rank === 3
                              ? 'bg-amber-700 text-amber-100 font-bold'
                              : 'bg-[#33190C] text-amber-300'
                          }`}
                        >
                          {toPersianDigits(member.rank)}
                        </div>

                        <div className="text-right">
                          <span className="font-lalezar text-xs block text-amber-100">
                            {member.name}
                          </span>
                          <span className="text-[9px] text-amber-300/70 font-vazir block">
                            {member.badge} • {member.neighborhood}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs font-vazir">
                        <span className="text-amber-200/90 font-vazir text-[11px] bg-[#2A1308] px-2 py-0.5 rounded-md border border-amber-800/60 font-semibold">
                          {toPersianDigits(member.stagesCompleted)}/۵
                        </span>
                        <span className="font-lalezar text-yellow-300 font-bold min-w-[55px] text-left">
                          {formatPersianCoins(member.score)} ★
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Flying Emoji Animation Overlay */}
        {flyingEmoji && (
          <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none">
            <span className="text-6xl animate-bounce drop-shadow-[0_0_25px_rgba(255,215,0,0.8)]">
              {flyingEmoji}
            </span>
          </div>
        )}

        {/* Emoji Toast Alert */}
        {emojiToast && (
          <div className="mt-2 p-2 rounded-xl bg-emerald-950 border border-emerald-400 text-emerald-200 text-xs font-vazir text-center shadow-lg animate-fade-in">
            {emojiToast}
          </div>
        )}

        {/* Emoji Picker Popup for Target Member */}
        {targetMemberForEmoji && (
          <div className="fixed inset-0 z-50 flex items-end justify-center p-3 bg-black/60 backdrop-blur-xs animate-fade-in">
            <div className="w-full max-w-sm rounded-[28px] p-4 bg-gradient-to-b from-[#2E1609] to-[#180A04] border-4 border-amber-400 shadow-2xl text-center text-[#FFFBF0]">
              <div className="flex items-center justify-between pb-2 border-b border-amber-900/60 mb-2">
                <span className="font-lalezar text-xs text-yellow-300">
                  ارسال ایموجی به «{targetMemberForEmoji.name}»
                </span>
                <button
                  onClick={() => setTargetMemberForEmoji(null)}
                  className="w-6 h-6 rounded-full bg-[#422110] text-amber-200 flex items-center justify-center cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <span className="text-[10px] text-amber-200/80 font-vazir block mb-2">
                یک ایموجی معرفتی را برای ابراز ارادت انتخاب کنید:
              </span>

              {/* 9 Traditional Teahouse Emojis */}
              <div className="grid grid-cols-3 gap-2">
                {ALLOWED_REACTION_EMOJIS.map((em) => (
                  <button
                    key={em}
                    onClick={() => handleSendEmoji(em)}
                    className="p-2 rounded-2xl bg-[#3D1E0C] hover:bg-[#522910] border border-amber-500/50 hover:border-yellow-400 transition-all flex flex-col items-center justify-center gap-1 active:scale-90 cursor-pointer shadow"
                  >
                    <span className="text-2xl">{em}</span>
                    <span className="text-[10px] font-lalezar text-yellow-200">
                      {EMOJI_LABELS[em]}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-2.5 pt-2 border-t border-[#3E1F0F] text-center text-[10px] text-amber-300/80 font-vazir flex items-center justify-between">
          <span className="font-lalezar text-yellow-300">چایخانه عمو بهمن</span>
          <span className="font-vazir text-amber-200 font-semibold">
            رده‌بندی ملی و استانی
          </span>
          <span className="text-emerald-400 font-bold">
            پایان دور: دوشنبه
          </span>
        </div>
      </div>
    </div>
  );
};
