import React, { useState } from 'react';
import {
  X,
  Award,
  Sparkles,
  Check,
  Shield,
  CheckCircle2,
  Lock,
  ChevronLeft,
  Coins,
  Crown,
  Flame,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import {
  PAHLAVANI_ACHIEVEMENTS,
  PahlavaniAchievement,
  PahlavaniBadge,
  PahlavaniStats,
  getClaimedAchievementIds,
  claimAchievement,
  equipPlayerBadge,
  getBadgeById,
  buildPahlavaniStats,
} from '../../services/PahlavaniAchievements';
import { PlayerProfile } from '../../types';

interface PahlavaniAchievementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
  coins: number;
  ownedDecorations: string[];
  weeklyCompletedStages: number;
  playerProfile: PlayerProfile;
  onProfileUpdated: (profile: PlayerProfile) => void;
  onRewardCoins: (amount: number) => void;
}

export const PahlavaniAchievementsModal: React.FC<PahlavaniAchievementsModalProps> = ({
  isOpen,
  onClose,
  currentLevel,
  coins,
  ownedDecorations,
  weeklyCompletedStages,
  playerProfile,
  onProfileUpdated,
  onRewardCoins,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [claimedIds, setClaimedIds] = useState<string[]>(() => getClaimedAchievementIds());
  const [activeBadgeId, setActiveBadgeId] = useState<string | undefined>(
    playerProfile.activeBadgeId
  );
  const [claimedAnimationId, setClaimedAnimationId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Build current stats snapshot
  const stats: PahlavaniStats = buildPahlavaniStats({
    currentLevel,
    coins,
    ownedDecorations,
    weeklyCompletedStages,
  });

  const categories = [
    { id: 'all', label: 'همه مأموریت‌ها' },
    { id: 'levels', label: 'مراحل چایخانه' },
    { id: 'tea', label: 'چای‌ریزی' },
    { id: 'decor', label: 'دکور و عتیقه' },
    { id: 'sugar', label: 'قند و موانع' },
    { id: 'wealth', label: 'دخل و ثروت' },
  ];

  const filteredAchievements = PAHLAVANI_ACHIEVEMENTS.filter((item) => {
    if (selectedCategory === 'all') return true;
    return item.category === selectedCategory;
  });

  const totalUnlockedBadges = playerProfile.unlockedBadgeIds?.length || 0;
  const currentActiveBadge = getBadgeById(activeBadgeId || playerProfile.activeBadgeId);

  const handleClaim = (achievement: PahlavaniAchievement) => {
    soundEngine.playCoins();
    soundEngine.playSanturVictory();

    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#10B981', '#F43F5E', '#38BDF8'],
      });
    } catch {}

    const result = claimAchievement(achievement.id);
    if (result.success) {
      setClaimedAnimationId(achievement.id);
      setTimeout(() => setClaimedAnimationId(null), 1500);

      const nextClaimed = [...claimedIds, achievement.id];
      setClaimedIds(nextClaimed);

      // Award coins
      onRewardCoins(result.rewardCoins);

      // Update player profile
      const currentUnlocked = Array.isArray(playerProfile.unlockedBadgeIds)
        ? [...playerProfile.unlockedBadgeIds]
        : [];
      if (!currentUnlocked.includes(achievement.badge.id)) {
        currentUnlocked.push(achievement.badge.id);
      }

      const nextActive = playerProfile.activeBadgeId || achievement.badge.id;
      setActiveBadgeId(nextActive);

      const updatedProfile: PlayerProfile = {
        ...playerProfile,
        unlockedBadgeIds: currentUnlocked,
        activeBadgeId: nextActive,
      };
      onProfileUpdated(updatedProfile);
    }
  };

  const handleEquipBadge = (badge: PahlavaniBadge) => {
    soundEngine.playClick();
    const res = equipPlayerBadge(badge.id);
    if (res.success) {
      setActiveBadgeId(badge.id);
      const updatedProfile: PlayerProfile = {
        ...playerProfile,
        activeBadgeId: badge.id,
      };
      onProfileUpdated(updatedProfile);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-md animate-fade-in select-none"
      style={{
        paddingTop: 'max(env(safe-area-inset-top, 24px), 1.5rem)',
        paddingBottom: 'max(env(safe-area-inset-bottom, 24px), 1.5rem)',
      }}
    >
      <div className="relative w-full max-w-lg max-h-[92vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#381B0C] via-[#2A1308] to-[#1A0A04] border-4 border-[#F59E0B] shadow-[0_20px_60px_rgba(245,158,11,0.35)] text-[#FFFBF0] overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-amber-800/60">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-700 p-0.5 shadow-lg flex items-center justify-center shrink-0">
              <div className="w-full h-full rounded-[14px] bg-[#220E04] flex items-center justify-center text-yellow-300">
                <Award className="w-5 h-5" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-lalezar text-base sm:text-lg text-yellow-300 leading-tight">
                  مدال‌ها و دستاوردهای پهلوانی
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-600/70 font-vazir font-bold">
                  {toPersianDigits(totalUnlockedBadges)} از {toPersianDigits(PAHLAVANI_ACHIEVEMENTS.length)} نشان
                </span>
              </div>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                مأموریت‌های ویژه، جوایز سکه و نصب نشان افتخار روی پروفایل
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-all cursor-pointer active:scale-95"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Active Badge Showcase Header */}
        <div className="my-2.5 p-3 rounded-2xl bg-gradient-to-r from-[#291307] via-[#351909] to-[#291307] border border-amber-500/60 shadow-inner flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            {currentActiveBadge ? (
              <div
                className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${currentActiveBadge.gradient} p-0.5 flex items-center justify-center shrink-0 shadow-md ${currentActiveBadge.glowShadow}`}
              >
                <div className="w-full h-full rounded-[14px] bg-[#1E0C04]/90 flex items-center justify-center text-2xl">
                  {currentActiveBadge.icon}
                </div>
              </div>
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-amber-950/80 border border-amber-700/60 flex items-center justify-center text-2xl shrink-0">
                🛡️
              </div>
            )}
            <div className="min-w-0">
              <span className="text-[9px] text-amber-400 font-vazir block">
                نشان منتخب نصب‌شده روی پروفایل:
              </span>
              <span className="font-lalezar text-sm text-yellow-200 truncate block">
                {currentActiveBadge ? currentActiveBadge.title : 'هنوز نشانی نصب نشده است'}
              </span>
              <span className="text-[9px] text-amber-200/80 font-vazir truncate block">
                {currentActiveBadge ? currentActiveBadge.motto : 'با تکمیل دستاوردها نشان افتخار بگیرید'}
              </span>
            </div>
          </div>

          <div className="text-left shrink-0">
            <span className="text-[10px] px-2.5 py-1 rounded-xl bg-amber-900/60 text-yellow-300 border border-amber-600/70 font-lalezar flex items-center gap-1">
              <Crown className="w-3 h-3 text-yellow-400" />
              <span>پروفایل اوستا</span>
            </span>
          </div>
        </div>

        {/* Category Pills Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 mb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                soundEngine.playClick();
                setSelectedCategory(cat.id);
              }}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-lalezar whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow-md scale-105'
                  : 'bg-[#220E04] text-amber-300 hover:text-white border border-amber-800/60'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Scrollable Achievements List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-0.5 custom-scrollbar">
          {filteredAchievements.map((item) => {
            const rawProgress = item.getProgress(stats);
            const progress = Math.min(item.targetCount, rawProgress);
            const percent = Math.min(100, Math.floor((progress / item.targetCount) * 100));
            const isCompleted = progress >= item.targetCount;
            const isClaimed = claimedIds.includes(item.id);
            const isBadgeEquipped = activeBadgeId === item.badge.id;
            const isAnimating = claimedAnimationId === item.id;

            return (
              <div
                key={item.id}
                className={`p-3 rounded-2xl border transition-all ${
                  isClaimed
                    ? 'bg-[#241107]/80 border-amber-700/50'
                    : isCompleted
                    ? 'bg-gradient-to-r from-[#3A1B08] via-[#48220A] to-[#3A1B08] border-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.25)]'
                    : 'bg-[#1F0D05]/80 border-amber-900/60 opacity-90'
                } ${isAnimating ? 'animate-bounce' : ''}`}
              >
                <div className="flex items-start justify-between gap-3">
                  {/* Badge Icon Medallion */}
                  <div
                    className={`w-13 h-13 rounded-2xl bg-gradient-to-tr ${item.badge.gradient} p-0.5 shadow-lg flex items-center justify-center shrink-0 ${
                      isCompleted ? item.badge.glowShadow : 'grayscale opacity-75'
                    }`}
                  >
                    <div className="w-full h-full rounded-[14px] bg-[#1E0B03]/90 flex items-center justify-center text-2xl relative">
                      {item.badge.icon}
                      {!isCompleted && (
                        <div className="absolute inset-0 bg-black/60 rounded-[14px] flex items-center justify-center">
                          <Lock className="w-4 h-4 text-amber-400/80" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Title & Info */}
                  <div className="flex-1 min-w-0 text-right">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-lalezar text-sm text-yellow-300">
                        {item.title}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-amber-300 border border-amber-700 font-vazir">
                        {item.categoryLabel}
                      </span>
                    </div>

                    <p className="text-[10px] text-amber-200/80 font-vazir mt-0.5 leading-relaxed">
                      {item.description}
                    </p>

                    {/* Badge Honor Name */}
                    <div className="mt-1 flex items-center gap-1 text-[9px] text-amber-400/90 font-vazir">
                      <Shield className="w-3 h-3 text-yellow-400" />
                      <span>جایزه نشان:</span>
                      <span className="font-bold text-yellow-200">{item.badge.title}</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-2">
                      <div className="flex items-center justify-between text-[9px] font-vazir mb-1 text-amber-300">
                        <span>
                          پیشرفت: {toPersianDigits(progress)} از {toPersianDigits(item.targetCount)} {item.unit}
                        </span>
                        <span className="font-bold text-yellow-400">{toPersianDigits(percent)}٪</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-[#120703] border border-amber-900/60 overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 rounded-full ${
                            isCompleted
                              ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-yellow-400'
                              : 'bg-gradient-to-r from-amber-700 to-amber-500'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="mt-3 pt-2.5 border-t border-amber-800/40 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1 text-xs font-lalezar text-yellow-300">
                    <Coins className="w-3.5 h-3.5 text-yellow-400" />
                    <span>+{formatPersianCoins(item.rewardCoins)} سکه طلا</span>
                  </div>

                  <div>
                    {isClaimed ? (
                      <div className="flex items-center gap-2">
                        {isBadgeEquipped ? (
                          <span className="px-2.5 py-1 rounded-xl bg-emerald-950 text-emerald-300 border border-emerald-600 font-lalezar text-[11px] flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>نشان فعال پروفایل</span>
                          </span>
                        ) : (
                          <button
                            onClick={() => handleEquipBadge(item.badge)}
                            className="px-2.5 py-1 rounded-xl bg-[#2D160A] hover:bg-[#42200E] text-yellow-300 border border-amber-600/70 font-lalezar text-[11px] transition-all cursor-pointer active:scale-95 shadow"
                          >
                            نصب روی پروفایل 🛡️
                          </button>
                        )}
                      </div>
                    ) : isCompleted ? (
                      <button
                        onClick={() => handleClaim(item)}
                        className="px-3 py-1 rounded-xl bg-gradient-to-r from-yellow-500 via-amber-400 to-yellow-600 hover:brightness-110 text-amber-950 font-lalezar text-xs font-bold shadow-lg transition-all active:scale-95 cursor-pointer animate-pulse flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>دریافت نشان و پاداش</span>
                      </button>
                    ) : (
                      <span className="px-2.5 py-1 rounded-xl bg-[#140803] text-amber-400/60 border border-amber-900/60 font-vazir text-[10px] flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>در حال انجام</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Banner */}
        <div className="mt-3 pt-2 border-t border-amber-800/60 flex items-center justify-between text-[10px] text-amber-300/80 font-vazir">
          <span>💡 هر نشانی که کسب کنید در کارت ویزیت و پروفایل شما می‌درخشد.</span>
          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="px-3 py-1 rounded-xl bg-[#32170A] hover:bg-[#48200E] text-amber-200 border border-amber-700/60 font-lalezar text-xs cursor-pointer"
          >
            بستن پنجره
          </button>
        </div>
      </div>
    </div>
  );
};
