import React, { useState } from 'react';
import { X, Share2, Copy, Check, Gift, Award } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';
import {
  getOrCreateReferralCode,
  redeemFriendReferral,
  DEFAULT_DECORATIONS,
} from '../../services/TeahouseStore';
import { getStoredPlayerProfile } from '../../services/backendApi';
import { getAvatarById } from '../../constants/avatars';
import { getBadgeById } from '../../services/PahlavaniAchievements';
import ghafourAvatar from '../../assets/images/ghafour_exact_avatar_1791919275034.webp';

interface PahlavaniCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  nickname: string;
  level: number;
  coins: number;
  ownedDecorations: string[];
  onRewardCoins: (amount: number) => void;
  onOpenAchievements?: () => void;
}

export const PahlavaniCardModal: React.FC<PahlavaniCardModalProps> = ({
  isOpen,
  onClose,
  nickname,
  level,
  coins,
  ownedDecorations,
  onRewardCoins,
  onOpenAchievements,
}) => {
  const [copied, setCopied] = useState(false);
  const [friendCode, setFriendCode] = useState('');
  const [redeemMsg, setRedeemMsg] = useState<{ text: string; error?: boolean } | null>(null);

  if (!isOpen) return null;

  const playerProfile = getStoredPlayerProfile();
  const playerAvatar = getAvatarById(playerProfile.avatarId);
  const userProv = playerProfile.province || 'تهران';
  const userCity = playerProfile.city || 'تهران';

  const myReferralCode = getOrCreateReferralCode();
  let patoghName = `${userCity} (${userProv})`;
  try {
    if (localStorage.getItem('bahman_player_patogh_id') === 'shiraz_pahlavan') {
      patoghName = 'پهلوانان شیراز';
    }
  } catch {}

  // Calculate decor value
  const totalDecorValue = ownedDecorations.reduce((sum, id) => {
    const item = DEFAULT_DECORATIONS.find((d) => d.id === id);
    return sum + (item ? item.price : 0);
  }, 0);

  const title =
    level >= 15 ? 'سلطان چای‌ریزی طهران' : level >= 8 ? 'پهلوان نامدار محله' : 'شاگرد زرنگ چایخانه';

  const shareText = `☕ پهلوون! به چایخانه عمو بهمن بیا و با من چای بریز! با کد دعوت من (${myReferralCode}) ۵۰۰ سکه هدیه بگیر: https://bahmanbamzad.ir`;

  const handleShare = () => {
    soundEngine.playClick();
    if (navigator.share) {
      navigator.share({
        title: 'چایخانه عمو بهمن',
        text: shareText,
        url: 'https://bahmanbamzad.ir',
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleCopyCode = () => {
    soundEngine.playClick();
    navigator.clipboard?.writeText(myReferralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleRedeem = () => {
    if (!friendCode.trim()) return;
    const res = redeemFriendReferral(friendCode);
    if (res.success) {
      soundEngine.playCoins();
      onRewardCoins(500);
      setRedeemMsg({ text: res.message });
      setFriendCode('');
    } else {
      soundEngine.playGlassClink();
      setRedeemMsg({ text: res.message, error: true });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300 text-sm">
                🪪
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                کارت پهلوانی و پُز دادن
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                شناسنامه رسمی چای‌ریزان چایخانه
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Vintage Persian Business Card Poster */}
        <div className="my-3 p-4 rounded-2xl bg-gradient-to-b from-[#FFFBEB] to-[#FEF3C7] text-stone-900 border-4 border-[#8B5226] shadow-xl relative overflow-hidden text-center">
          {/* Persian arabesque flourishes */}
          <div className="text-amber-900 text-sm font-lalezar tracking-wide">❧ شناسنامه چایخانه عمو بهمن ☙</div>

          <div className="w-16 h-16 mx-auto my-1.5 rounded-full bg-gradient-to-tr from-amber-700 via-yellow-500 to-amber-600 p-0.5 shadow-md flex items-center justify-center">
            {playerAvatar.image ? (
              <img
                src={playerAvatar.image}
                alt={playerAvatar.name}
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <div className={`w-full h-full rounded-full bg-gradient-to-tr ${playerAvatar.bgGradient} flex items-center justify-center text-3xl`}>
                {playerAvatar.emoji}
              </div>
            )}
          </div>

          <h3 className="font-lalezar text-xl text-amber-950 font-bold">
            {nickname || 'پهلوان ناشناس'}
          </h3>
          <span className="text-[11px] font-lalezar text-amber-800 bg-amber-200/80 px-2.5 py-0.5 rounded-full border border-amber-400 inline-block mt-0.5">
            {title}
          </span>

          {/* Active Pahlavani Badge */}
          {(() => {
            const activeBadge = getBadgeById(playerProfile.activeBadgeId);
            if (activeBadge) {
              return (
                <div className="flex items-center justify-center gap-1.5 mt-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-200/90 via-yellow-200 to-amber-200/90 border border-amber-500/70 shadow-sm text-amber-950">
                  <span className="text-base">{activeBadge.icon}</span>
                  <span className="font-lalezar text-xs font-bold">{activeBadge.title}</span>
                </div>
              );
            }
            return (
              <div className="text-[10px] text-amber-800/70 font-vazir mt-1">
                نشان پهلوانی فعال: کسب نشده
              </div>
            );
          })()}

          <div className="grid grid-cols-2 gap-2 my-2.5 text-right text-[11px] font-vazir text-stone-800 bg-amber-100/60 p-2 rounded-xl border border-amber-300/80">
            <div>🏛️ پاتوق: <span className="font-bold">{patoghName}</span></div>
            <div>🏆 مرحله فعلی: <span className="font-bold">{toPersianDigits(level)}</span></div>
            <div>💰 موجودی: <span className="font-bold">{formatPersianCoins(coins)}</span></div>
            <div>🏺 ارزش دکور: <span className="font-bold">{formatPersianCoins(totalDecorValue)}</span></div>
          </div>

          {/* Open Achievements Button */}
          {onOpenAchievements && (
            <button
              onClick={() => {
                soundEngine.playClick();
                onOpenAchievements();
              }}
              className="w-full mb-2 py-1.5 px-3 rounded-xl bg-gradient-to-r from-amber-700 via-amber-600 to-yellow-600 hover:brightness-110 text-white font-lalezar text-xs shadow flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <Award className="w-3.5 h-3.5 text-yellow-300" />
              <span>مشاهده و تعویض مدال‌های پهلوانی</span>
            </button>
          )}

          {/* Referral Code Box */}
          <div className="p-2 rounded-xl bg-amber-900 text-yellow-200 flex items-center justify-between shadow-inner">
            <span className="text-[10px] font-vazir">کد معرف اختصاصی:</span>
            <span className="font-lalezar text-sm tracking-wider">{myReferralCode}</span>
          </div>
        </div>

        {/* Share & Copy Buttons */}
        <div className="grid grid-cols-2 gap-2 mb-3">
          <button
            onClick={handleShare}
            className="py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-lalezar text-xs font-bold shadow flex items-center justify-center gap-1.5 hover:brightness-110 active:scale-95 transition-all cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>اشتراک در شبکه‌ها</span>
          </button>
          <button
            onClick={handleCopyCode}
            className="py-2 rounded-xl bg-[#3D1E0C] hover:bg-[#522810] border border-amber-500/60 text-yellow-200 font-lalezar text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'کپی شد!' : 'کپی کد معرف'}</span>
          </button>
        </div>

        {/* Redeem Friend's Code */}
        <div className="p-2.5 rounded-2xl bg-[#1C0D05] border border-amber-600/40 text-right">
          <span className="text-[11px] font-lalezar text-yellow-300 block mb-1">
            کد دعوت رفیق داری؟ ۵۰۰ سکه هدیه بگیر:
          </span>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={friendCode}
              onChange={(e) => setFriendCode(e.target.value)}
              placeholder="مثلاً: CHAY-4520"
              className="flex-1 px-2.5 py-1.5 rounded-xl bg-[#140803] border border-amber-700/60 text-yellow-200 text-xs font-vazir outline-none focus:border-yellow-400"
            />
            <button
              onClick={handleRedeem}
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-lalezar text-xs shadow active:scale-95 cursor-pointer"
            >
              ثبت کد
            </button>
          </div>
          {redeemMsg && (
            <span
              className={`text-[10px] font-vazir block mt-1 ${
                redeemMsg.error ? 'text-red-400' : 'text-emerald-300'
              }`}
            >
              {redeemMsg.text}
            </span>
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            کارت ویزیت چایخانه عمو بهمن • هر دعوت = ۵۰۰ سکه
          </p>
        </div>
      </div>
    </div>
  );
};
