import React, { useState, useEffect, useMemo } from 'react';
import { X, Volume2, RadioTower, Sparkles, MapPin, Music2, Disc3 } from 'lucide-react';
import { RadioTrackId } from '../../types';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits } from '../../utils/persianNumbers';
import {
  RADIO_STATIONS,
  FOLK_RADIO_STATIONS,
  PROVINCE_RADIO_STATIONS,
  ALL_RADIO_STATIONS,
  RadioStationInfo,
  RadioStationId,
  RadioCategory,
  getActiveRadioStation,
  setActiveRadioStation,
} from '../../services/TeahouseStore';
import { FolkAtmosphericBackground } from '../FolkAtmosphericBackground';

interface RadioModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTrack: RadioTrackId;
  volume: number;
  onTrackChange: (track: RadioTrackId) => void;
  onVolumeChange: (vol: number) => void;
}

export const RadioModal: React.FC<RadioModalProps> = ({
  isOpen,
  onClose,
  volume,
  onTrackChange,
  onVolumeChange,
}) => {
  const [sliderVol, setSliderVol] = useState(volume);
  const [activeStationId, setActiveStationId] = useState<RadioStationId>(() => getActiveRadioStation());
  const [activeCategory, setActiveCategory] = useState<RadioCategory>(() => {
    const current = ALL_RADIO_STATIONS.find((s) => s.id === getActiveRadioStation());
    return current?.category || 'classical';
  });
  const [tickerIndex, setTickerIndex] = useState(0);

  // Identify current station
  const currentStation = useMemo(() => {
    return ALL_RADIO_STATIONS.find((s) => s.id === activeStationId) || ALL_RADIO_STATIONS[0];
  }, [activeStationId]);

  // Rotate ticker messages periodically
  useEffect(() => {
    setTickerIndex(0);
    const timer = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % currentStation.tickerMessages.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [currentStation]);

  if (!isOpen) return null;

  const handleSelectStation = (station: RadioStationInfo) => {
    soundEngine.playClick();
    setActiveStationId(station.id);
    setActiveRadioStation(station.id);
    setActiveCategory(station.category);
    onTrackChange(station.trackId);
  };

  const handleSlider = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSliderVol(val);
    onVolumeChange(val);
  };

  const stationsToDisplay =
    activeCategory === 'provinces'
      ? PROVINCE_RADIO_STATIONS
      : activeCategory === 'folk'
      ? FOLK_RADIO_STATIONS
      : RADIO_STATIONS;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-[#140803]/85 backdrop-blur-md animate-fade-in select-none">
      <div className="relative w-full max-w-md max-h-[94vh] flex flex-col bg-gradient-to-b from-[#3A2112] via-[#26140A] to-[#180B04] rounded-[28px] border-4 border-[#8B5226] shadow-[0_12px_45px_rgba(0,0,0,0.85),0_0_0_1px_rgba(245,158,11,0.2)] text-[#FFFBF0] overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-3.5 sm:p-4 border-b border-[#522E15] bg-[#2E180B]/90">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-600 to-yellow-400 p-[1.5px] shadow-md">
              <div className="w-full h-full rounded-[14px] bg-[#2B1408] flex items-center justify-center">
                <RadioTower className="w-5 h-5 text-yellow-300 animate-pulse" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base sm:text-lg text-yellow-300 leading-none">
                رادیو لامپی چایخانه عمو بهمن
              </h2>
              <span className="text-[11px] text-amber-200/70 font-vazir block mt-0.5">
                دستگاه‌های اصیل سنتی و موسیقی نواحی و اقوام ایران
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-[#44230F] hover:bg-[#5C3015] border border-amber-800/60 text-amber-200 flex items-center justify-center cursor-pointer transition-colors active:scale-95"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3">
          {/* Live Vintage Radio Screen with Province Atmospheric Artwork */}
          <div className="relative rounded-2xl border-2 border-[#5C3317] shadow-inner overflow-hidden min-h-[145px] sm:min-h-[160px] flex flex-col justify-between p-3 bg-[#110703]">
            {/* Unique Atmospheric Landscape Background */}
            <div className="absolute inset-0 z-0">
              <FolkAtmosphericBackground theme={currentStation.bgTheme} />
            </div>

            {/* Top Screen Bar */}
            <div className="relative z-10 flex items-center justify-between pb-1.5 border-b border-white/15 backdrop-blur-[2px] bg-black/30 -mx-3 -mt-3 px-3 pt-2 rounded-t-2xl">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400" />
                </span>
                <span className="text-xs sm:text-sm font-lalezar text-yellow-200 drop-shadow">
                  {currentStation.name}
                </span>
              </div>

              <span className="text-[10px] text-teal-200 font-vazir bg-teal-950/85 px-2.5 py-0.5 rounded-full border border-teal-500/60 backdrop-blur-sm shadow">
                {currentStation.dastgahTag}
              </span>
            </div>

            {/* Province and Instrument Tag when in Folk mode */}
            {currentStation.province && (
              <div className="relative z-10 flex items-center gap-2 my-1">
                <span className="inline-flex items-center gap-1 text-[10px] text-amber-200 bg-amber-950/85 px-2 py-0.5 rounded-md border border-amber-600/60 backdrop-blur-sm">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>{currentStation.province}</span>
                </span>
                {currentStation.instruments && (
                  <span className="inline-flex items-center gap-1 text-[10px] text-yellow-100 bg-black/60 px-2 py-0.5 rounded-md border border-white/10 backdrop-blur-sm">
                    <Music2 className="w-3 h-3 text-yellow-400" />
                    <span>سازها: {currentStation.instruments}</span>
                  </span>
                )}
              </div>
            )}

            {/* Animated Ticker Message */}
            <div className="relative z-10 my-auto py-1 flex items-center justify-center text-center">
              <p className="font-vazir text-xs sm:text-[13px] text-white font-medium drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] animate-fade-in line-clamp-2 px-1">
                {currentStation.tickerMessages[tickerIndex]}
              </p>
            </div>

            {/* Retro Equalizer Wave Bars */}
            <div className="relative z-10 flex items-end justify-between pt-1 border-t border-white/15 -mx-3 -mb-3 px-3 pb-2 backdrop-blur-[2px] bg-black/40 rounded-b-2xl">
              <span className="text-[9px] text-amber-200/80 font-vazir flex items-center gap-1">
                <Disc3 className="w-3 h-3 animate-spin text-amber-400" />
                <span>موتور پخش صوتی زنده وب‌آدیو</span>
              </span>
              <div className="flex items-end gap-1 h-3.5">
                {[45, 85, 60, 100, 75, 90, 50, 95, 65, 80, 55, 90].map((h, i) => (
                  <div
                    key={i}
                    className="w-1 rounded-full bg-gradient-to-t from-amber-600 via-amber-400 to-yellow-200 animate-pulse"
                    style={{
                      height: `${h}%`,
                      animationDelay: `${i * 90}ms`,
                      animationDuration: '1.2s',
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Category Tabs: Classical Dastgahs vs Folk Music vs Provinces */}
          <div className="grid grid-cols-3 gap-1 sm:gap-1.5 p-1 bg-[#1A0C05] rounded-2xl border border-[#4D2710]">
            <button
              onClick={() => {
                soundEngine.playClick();
                setActiveCategory('classical');
              }}
              className={`flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1 py-1.5 sm:py-2 px-1 sm:px-2 rounded-xl font-lalezar text-[11px] sm:text-xs cursor-pointer transition-all ${
                activeCategory === 'classical'
                  ? 'bg-gradient-to-r from-amber-700 via-amber-600 to-amber-700 text-yellow-100 shadow-md border border-yellow-400/60 font-bold'
                  : 'text-amber-200/70 hover:text-amber-100 hover:bg-[#281308]'
              }`}
            >
              <span>🎻</span>
              <span>دستگاه‌ها</span>
              <span className="text-[9px] font-vazir opacity-70">
                ({toPersianDigits(RADIO_STATIONS.length)})
              </span>
            </button>

            <button
              onClick={() => {
                soundEngine.playClick();
                setActiveCategory('folk');
              }}
              className={`flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1 py-1.5 sm:py-2 px-1 sm:px-2 rounded-xl font-lalezar text-[11px] sm:text-xs cursor-pointer transition-all ${
                activeCategory === 'folk'
                  ? 'bg-gradient-to-r from-teal-800 via-emerald-700 to-teal-800 text-teal-100 shadow-md border border-teal-400/70 font-bold'
                  : 'text-teal-200/70 hover:text-teal-100 hover:bg-[#12241C]'
              }`}
            >
              <span>🌾</span>
              <span>نواحی</span>
              <span className="text-[9px] font-vazir opacity-70">
                ({toPersianDigits(FOLK_RADIO_STATIONS.length)})
              </span>
            </button>

            <button
              onClick={() => {
                soundEngine.playClick();
                setActiveCategory('provinces');
              }}
              className={`flex flex-col sm:flex-row items-center justify-center gap-0.5 sm:gap-1 py-1.5 sm:py-2 px-1 sm:px-2 rounded-xl font-lalezar text-[11px] sm:text-xs cursor-pointer transition-all relative ${
                activeCategory === 'provinces'
                  ? 'bg-gradient-to-r from-rose-800 via-amber-700 to-orange-800 text-amber-100 shadow-md border border-amber-400/70 font-bold'
                  : 'text-amber-300/70 hover:text-amber-100 hover:bg-[#2A150A]'
              }`}
            >
              <span>🗺️</span>
              <span>استان‌ها</span>
              <span className="text-[9px] font-vazir opacity-70">
                ({toPersianDigits(PROVINCE_RADIO_STATIONS.length)})
              </span>
              <span className="absolute -top-1.5 -left-1 px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 text-amber-950 text-[8px] font-vazir font-extrabold shadow animate-bounce">
                جدید
              </span>
            </button>
          </div>

          {/* Station Cards List */}
          <div className="space-y-2">
            {stationsToDisplay.map((station) => {
              const isCurrent = activeStationId === station.id;
              return (
                <div
                  key={station.id}
                  onClick={() => handleSelectStation(station)}
                  className={`group relative overflow-hidden flex items-center justify-between p-2.5 sm:p-3 rounded-2xl border cursor-pointer transition-all ${
                    isCurrent
                      ? 'bg-gradient-to-r from-amber-950/95 via-[#3A1B0A] to-amber-900/90 border-yellow-400 shadow-[0_0_18px_rgba(245,158,11,0.35)] text-yellow-100 scale-[1.01]'
                      : 'bg-[#200E06]/85 border-[#4D2710] hover:bg-[#2B1409] hover:border-amber-700 text-[#FFE8D6]/80'
                  }`}
                >
                  {/* Atmospheric Mini Preview Thumbnail for Folk & Classical Tracks */}
                  <div className="flex items-center gap-3 relative z-10">
                    <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-amber-600/50 shadow flex-shrink-0">
                      <FolkAtmosphericBackground theme={station.bgTheme} showOverlay={false} />
                      <div className="absolute inset-0 bg-black/25 flex items-center justify-center text-lg">
                        {station.emoji}
                      </div>
                      {isCurrent && (
                        <div className="absolute bottom-0 inset-x-0 bg-amber-500/90 text-amber-950 text-[8px] font-lalezar text-center font-bold">
                          در حال پخش
                        </div>
                      )}
                    </div>

                    <div className="text-right">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h3 className="text-xs sm:text-sm font-bold font-lalezar text-yellow-200 group-hover:text-yellow-100">
                          {station.name}
                        </h3>
                        {station.province && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-950/80 text-amber-300 border border-amber-700/60 font-vazir">
                            {station.province.split(' ')[0]}
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-amber-200/70 font-vazir line-clamp-1">
                        {station.genre}
                      </p>
                      {station.instruments && (
                        <p className="text-[9px] text-teal-300/80 font-vazir line-clamp-1">
                          سازها: {station.instruments}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Play Action / Active Badge */}
                  <div className="relative z-10 flex-shrink-0 pr-1">
                    {isCurrent ? (
                      <span className="text-[10px] sm:text-[11px] text-yellow-300 font-bold font-lalezar bg-amber-950/95 px-2.5 py-1 rounded-full border border-yellow-400 shadow flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-yellow-300 animate-spin" />
                        <span>کوک شده ✓</span>
                      </span>
                    ) : (
                      <span className="text-[10px] text-amber-400/70 font-vazir bg-[#140803] px-2.5 py-1 rounded-full border border-amber-900/60 group-hover:border-amber-600 transition-colors">
                        انتخاب و پخش
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Volume Slider Control */}
        <div className="p-3 sm:p-3.5 bg-[#1B0D06] border-t border-[#4D2710] flex-shrink-0">
          <div className="flex items-center justify-between text-xs text-amber-300 mb-1.5 font-vazir">
            <span className="flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-amber-400" />
              <span>میزان بلندی صدای رادیو</span>
            </span>
            <span className="font-lalezar text-yellow-300">
              {toPersianDigits(Math.round(sliderVol * 100))}%
            </span>
          </div>

          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={sliderVol}
            onChange={handleSlider}
            className="w-full accent-amber-500 cursor-pointer h-2 bg-[#33190C] rounded-lg"
          />
        </div>
      </div>
    </div>
  );
};
