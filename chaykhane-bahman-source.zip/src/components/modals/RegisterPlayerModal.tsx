import React, { useState } from 'react';
import {
  X,
  UserCheck,
  ShieldCheck,
  Sparkles,
  AlertCircle,
  Check,
  MapPin,
  Image as ImageIcon,
  Settings,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Eye,
} from 'lucide-react';
import { PlayerProfile } from '../../types';
import { registerPlayerOnServer } from '../../services/backendApi';
import { soundEngine } from '../../audio/SoundEngine';
import { SUGGESTED_AVATARS, getAvatarById } from '../../constants/avatars';
import { IRAN_PROVINCES } from '../../constants/iranProvinces';
import {
  getBadgeById,
  equipPlayerBadge,
} from '../../services/PahlavaniAchievements';

interface RegisterPlayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: PlayerProfile;
  onProfileUpdated: (profile: PlayerProfile) => void;
  soundEnabled?: boolean;
  onToggleSound?: () => void;
  isNightMode?: boolean;
  onToggleNightMode?: () => void;
  colorblindMode?: boolean;
  onToggleColorblind?: () => void;
  onOpenAchievements?: () => void;
  onOpenNeighborhood?: () => void;
}

export const RegisterPlayerModal: React.FC<RegisterPlayerModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onProfileUpdated,
  soundEnabled = true,
  onToggleSound,
  isNightMode = false,
  onToggleNightMode,
  colorblindMode = false,
  onToggleColorblind,
  onOpenAchievements,
  onOpenNeighborhood,
}) => {
  const [firstName, setFirstName] = useState(currentProfile.firstName || '');
  const [lastName, setLastName] = useState(currentProfile.lastName || '');
  const [nickname, setNickname] = useState(currentProfile.nickname || '');
  const [selectedAvatarId, setSelectedAvatarId] = useState(currentProfile.avatarId || 'osta_bahman');
  const [selectedProvince, setSelectedProvince] = useState(currentProfile.province || 'تهران');
  const [selectedCity, setSelectedCity] = useState(currentProfile.city || 'تهران');
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  const currentProvinceInfo = IRAN_PROVINCES.find((p) => p.name === selectedProvince) || IRAN_PROVINCES[0];

  const handleProvinceChange = (prov: string) => {
    setSelectedProvince(prov);
    const pInfo = IRAN_PROVINCES.find((p) => p.name === prov);
    if (pInfo && pInfo.majorCities.length > 0) {
      setSelectedCity(pInfo.majorCities[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim()) {
      setFeedback({
        type: 'error',
        message: 'لطفاً نام و نام خانوادگی خود را کامل وارد نمایید.',
      });
      return;
    }

    setIsLoading(true);
    setFeedback(null);
    soundEngine.playClick();

    try {
      const res = await registerPlayerOnServer(
        firstName.trim(),
        lastName.trim(),
        selectedAvatarId,
        selectedProvince,
        selectedCity,
        nickname.trim()
      );
      setIsLoading(false);

      const updated: PlayerProfile = {
        ...currentProfile,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        nickname: nickname.trim() || `${firstName.trim()} ${lastName.trim()}`,
        avatarId: selectedAvatarId,
        province: selectedProvince,
        city: selectedCity,
        isRegistered: true,
        registeredAt: Date.now(),
      };
      onProfileUpdated(updated);

      setFeedback({
        type: 'success',
        message: res.message || 'مشخصات شما با موفقیت در دیتابیس ثبت شد!',
      });

      soundEngine.playSanturVictory();
      setTimeout(() => {
        onClose();
      }, 1400);
    } catch {
      setIsLoading(false);
      setFeedback({
        type: 'error',
        message: 'خطایی در اتصال به سرور رخ داد، اما اطلاعات به صورت محلی ثبت شد.',
      });
    }
  };

  const activeAvatar = getAvatarById(selectedAvatarId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none"
      style={{ paddingTop: 'max(env(safe-area-inset-top, 24px), 1.5rem)' }}
    >
      {/* Persian Tile Frame */}
      <div className="relative w-full max-w-md max-h-[88vh] flex flex-col rounded-[32px] p-2.5 bg-gradient-to-b from-[#0D9488] via-[#096057] to-[#04332F] border-4 border-[#5EEAD4] shadow-[0_15px_50px_rgba(0,0,0,0.9)] text-[#FFFBF0] overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="absolute -top-1 -right-1 z-30 w-8 h-8 rounded-full bg-gradient-to-b from-rose-500 to-red-700 hover:brightness-110 text-white flex items-center justify-center border-2 border-white shadow-xl transition-transform active:scale-90 cursor-pointer"
          title="بستن"
        >
          <X className="w-4 h-4 stroke-[2.5]" />
        </button>

        {/* Content Box */}
        <div className="flex-1 overflow-y-auto rounded-[24px] p-4 bg-gradient-to-b from-[#FFFBF0] via-[#FDF8E7] to-[#F7EDCE] border-2 border-[#D97706]/40 flex flex-col text-[#2C1A11] custom-scrollbar">
          {/* Header */}
          <div className="text-center mb-3">
            <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-2xl bg-amber-100 border-2 border-amber-500/70 text-amber-800 mb-1 shadow-inner">
              <UserCheck className="w-4 h-4 text-teal-700" />
              <span className="font-lalezar text-sm text-amber-950">باکس عضویت و شناسنامه چایخانه</span>
              <Settings className="w-4 h-4 text-amber-700" />
            </div>
            <h2 className="font-lalezar text-lg text-[#3E2211]">
              ثبت مشخصات و تصویر شاخص
            </h2>
            <p className="text-[11px] text-amber-900/80 font-vazir mt-0.5 font-medium">
              ذخیره آنلاین در دیتابیس • نام، نام خانوادگی، استان، شهر و تصویر پیشنهادی
            </p>
          </div>

          {/* Strict Anti-Chat Notice in Membership Box */}
          <div className="mb-3 p-2 rounded-xl bg-amber-100/90 border border-amber-400 text-[10px] text-amber-950 font-vazir flex items-center gap-2">
            <span className="text-base">🛡️</span>
            <span>
              <b>قانون چایخانه:</b> هیچ چت متنی، شخصی یا گروهی وجود ندارد. ارتباط در جدول رقبا صرفاً از طریق ارسال <b>ایموجی‌های سنتی</b> (☕، 👏، 🫖) است.
            </span>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* 1. Name & Family */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                  نام: <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="مثلاً: بهمن"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm"
                  required
                  maxLength={40}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                  نام خانوادگی: <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="مثلاً: بامزد"
                  className="w-full px-3 py-2 text-xs rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm"
                  required
                  maxLength={40}
                />
              </div>
            </div>

            {/* 2. Nickname */}
            <div>
              <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                لقب در جدول رقبا (اختیاری):
              </label>
              <input
                type="text"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder={firstName && lastName ? `${firstName} ${lastName}` : 'مثلاً: داش بهمن بامزد'}
                className="w-full px-3 py-2 text-xs rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm"
                maxLength={50}
              />
            </div>

            {/* 3. Featured Avatar Picker (چندتایی پیشنهادی) */}
            <div>
              <div className="flex items-center justify-between mb-1.5 flex-wrap gap-1">
                <div className="text-[10px] text-amber-800 font-vazir flex items-center gap-1.5 flex-wrap">
                  <span>انتخاب شده: <b className="text-amber-950 font-lalezar text-xs">{activeAvatar.name}</b> ({activeAvatar.title})</span>
                  {(() => {
                    const activeBadge = getBadgeById(currentProfile.activeBadgeId);
                    if (activeBadge) {
                      return (
                        <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 font-lalezar text-[10px] font-bold shadow flex items-center gap-1">
                          <span>{activeBadge.icon}</span>
                          <span>{activeBadge.title}</span>
                        </span>
                      );
                    }
                    return null;
                  })()}
                </div>
                <label className="text-xs font-bold text-[#42220F] font-vazir flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5 text-amber-700" />
                  <span>تصویر شاخص پیشنهادی:</span>
                </label>
              </div>

              {/* Horizontal Scrollable Avatar Shelf */}
              <div className="grid grid-cols-5 gap-2 p-2 rounded-2xl bg-amber-900/10 border-2 border-amber-400/40 max-h-36 overflow-y-auto custom-scrollbar">
                {SUGGESTED_AVATARS.map((av) => {
                  const isSelected = selectedAvatarId === av.id;
                  return (
                    <button
                      key={av.id}
                      type="button"
                      onClick={() => {
                        soundEngine.playClick();
                        setSelectedAvatarId(av.id);
                      }}
                      className={`relative flex flex-col items-center p-1.5 rounded-xl border-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-amber-100 border-amber-600 shadow-md scale-105 ring-2 ring-yellow-400'
                          : 'bg-white/70 border-stone-300 hover:border-amber-400 opacity-80 hover:opacity-100'
                      }`}
                      title={`${av.name} - ${av.title}`}
                    >
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow flex items-center justify-center">
                        {av.image ? (
                          <img
                            src={av.image}
                            alt={av.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          <div className={`w-full h-full rounded-full bg-gradient-to-tr ${av.bgGradient} flex items-center justify-center text-lg`}>
                            {av.emoji}
                          </div>
                        )}
                      </div>
                      <span className="text-[9px] font-lalezar text-stone-900 mt-1 truncate w-full text-center">
                        {av.name}
                      </span>
                      {isSelected && (
                        <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] shadow">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Province & City Dropdowns */}
            <div className="grid grid-cols-2 gap-2">
              {/* Province */}
              <div>
                <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-teal-700" />
                  <span>استان:</span>
                </label>
                <select
                  value={selectedProvince}
                  onChange={(e) => handleProvinceChange(e.target.value)}
                  className="w-full px-2.5 py-2 text-xs rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm cursor-pointer"
                >
                  {IRAN_PROVINCES.map((prov) => (
                    <option key={prov.name} value={prov.name}>
                      {prov.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* City */}
              <div>
                <label className="block text-xs font-bold text-[#42220F] mb-1 font-vazir text-right">
                  شهر:
                </label>
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="w-full px-2.5 py-2 text-xs rounded-xl bg-white border-2 border-[#C9A26B] text-[#2C1A11] focus:outline-none focus:border-teal-600 transition-colors text-right font-vazir shadow-sm cursor-pointer"
                >
                  {currentProvinceInfo.majorCities.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Game Settings (صدا، شب، کوررنگی) */}
            <div className="p-2.5 rounded-2xl bg-amber-900/10 border border-amber-500/30 space-y-2">
              <span className="text-[11px] font-bold text-[#42220F] font-vazir block text-right">
                تنظیمات بازی و محیط چایخانه:
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {/* Sound Toggle */}
                {onToggleSound && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playClick();
                      onToggleSound();
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      soundEnabled
                        ? 'bg-amber-100 border-amber-500 text-amber-900'
                        : 'bg-stone-100 border-stone-300 text-stone-500 opacity-70'
                    }`}
                  >
                    {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-700" /> : <VolumeX className="w-4 h-4" />}
                    <span className="text-[10px] font-vazir font-semibold">
                      {soundEnabled ? 'صدا: روشن' : 'صدا: خاموش'}
                    </span>
                  </button>
                )}

                {/* Night Mode Toggle */}
                {onToggleNightMode && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playClick();
                      onToggleNightMode();
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      isNightMode
                        ? 'bg-amber-950 border-amber-500 text-amber-200'
                        : 'bg-white border-stone-300 text-amber-900'
                    }`}
                  >
                    {isNightMode ? <Moon className="w-4 h-4 text-amber-400" /> : <Sun className="w-4 h-4 text-amber-600" />}
                    <span className="text-[10px] font-vazir font-semibold">
                      {isNightMode ? 'شب: فعال' : 'روز / عادی'}
                    </span>
                  </button>
                )}

                {/* Colorblind Mode Toggle */}
                {onToggleColorblind && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playClick();
                      onToggleColorblind();
                    }}
                    className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                      colorblindMode
                        ? 'bg-teal-100 border-teal-600 text-teal-900'
                        : 'bg-white border-stone-300 text-stone-700'
                    }`}
                  >
                    <Eye className="w-4 h-4 text-teal-700" />
                    <span className="text-[10px] font-vazir font-semibold">
                      {colorblindMode ? 'علائم: روشن' : 'کوررنگی'}
                    </span>
                  </button>
                )}
              </div>
            </div>

            {/* Online Database Security & No-Chat Note */}
            <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-300 text-[10px] text-emerald-950 flex items-start gap-1.5 font-vazir leading-relaxed">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <span>
                دیتا در سرور آنلاین بازی ذخیره می‌شود. ارتباط بین بازیکنان بر اساس قوانین چایخانه تنها با <b>ایموجی‌های معرفتی</b> امکان‌پذیر است و امکان چت متنی وجود ندارد.
              </span>
            </div>

            {/* Feedback alert */}
            {feedback && (
              <div
                className={`p-2 rounded-xl text-xs font-vazir font-semibold flex items-center gap-1.5 ${
                  feedback.type === 'success'
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-400'
                    : 'bg-rose-100 text-rose-900 border border-rose-400'
                }`}
              >
                {feedback.type === 'success' ? (
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-700" />
                )}
                <span>{feedback.message}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-amber-950 font-lalezar text-base shadow-lg border border-amber-200 transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer font-bold"
            >
              {isLoading ? (
                <span>در حال ذخیره آنلاین در دیتابیس...</span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>ثبت و ذخیره مشخصات در دیتابیس</span>
                </>
              )}
            </button>

            {/* Direct Leaderboard Shortcut */}
            {onOpenNeighborhood && (
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  onOpenNeighborhood();
                }}
                className="w-full py-2 rounded-2xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/70 text-emerald-200 font-lalezar text-xs flex items-center justify-center gap-1.5 shadow transition-all active:scale-95 cursor-pointer"
              >
                <span>🏆</span>
                <span>مشاهده رتبه در جدول رقبا (کشوری، استانی، شهری)</span>
              </button>
            )}

            {/* Pahlavani Badges on Player Profile */}
            <div className="p-3 rounded-2xl bg-amber-900/10 border-2 border-amber-500/40 space-y-2 mt-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-lalezar text-amber-950">
                  <span className="text-sm">🛡️</span>
                  <span>مدال‌ها و نشان‌های افتخار پهلوانی</span>
                </div>
                {onOpenAchievements && (
                  <button
                    type="button"
                    onClick={() => {
                      soundEngine.playClick();
                      onOpenAchievements();
                    }}
                    className="text-[11px] font-lalezar text-amber-800 hover:text-amber-950 underline cursor-pointer"
                  >
                    تالار مدال‌ها و جوایز 🏆
                  </button>
                )}
              </div>

              <p className="text-[10px] text-amber-900/80 font-vazir leading-relaxed">
                برای انتخاب و نصب هر نشان روی پروفایل و کارت ویزیت، روی آن کلیک کنید:
              </p>

              {currentProfile.unlockedBadgeIds && currentProfile.unlockedBadgeIds.length > 0 ? (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {currentProfile.unlockedBadgeIds.map((badgeId) => {
                    const badge = getBadgeById(badgeId);
                    if (!badge) return null;
                    const isEquipped = currentProfile.activeBadgeId === badge.id;

                    return (
                      <button
                        key={badge.id}
                        type="button"
                        onClick={() => {
                          soundEngine.playClick();
                          const res = equipPlayerBadge(badge.id);
                          if (res.success) {
                            onProfileUpdated({
                              ...currentProfile,
                              activeBadgeId: badge.id,
                            });
                          }
                        }}
                        className={`p-2 rounded-xl text-right flex items-center gap-2 border-2 transition-all cursor-pointer ${
                          isEquipped
                            ? 'bg-amber-100 border-amber-600 shadow-md scale-102 ring-1 ring-amber-500'
                            : 'bg-white/80 border-amber-300 hover:border-amber-500'
                        }`}
                      >
                        <div
                          className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${badge.gradient} p-0.5 flex items-center justify-center shrink-0 shadow`}
                        >
                          <div className="w-full h-full rounded-[10px] bg-[#220E04] flex items-center justify-center text-sm">
                            {badge.icon}
                          </div>
                        </div>
                        <div className="min-w-0 flex-1">
                          <span className="font-lalezar text-xs text-amber-950 block truncate">
                            {badge.title}
                          </span>
                          <span className="text-[9px] font-vazir text-amber-800 block truncate">
                            {isEquipped ? '✓ نشان فعال' : 'ضربه برای انتخاب'}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-2.5 rounded-xl bg-white/70 border border-amber-300 text-center">
                  <span className="text-[10px] font-vazir text-amber-900/80 block mb-1">
                    هنوز مدالی کسب نکرده‌اید! با رد کردن مراحل و دم‌آوری چای نشان افتخار بگیرید.
                  </span>
                  {onOpenAchievements && (
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playClick();
                        onOpenAchievements();
                      }}
                      className="px-3 py-1 rounded-xl bg-amber-600 hover:bg-amber-500 text-amber-950 font-lalezar text-xs font-bold shadow transition-all active:scale-95 cursor-pointer"
                    >
                      ورود به تالار مدال‌های پهلوانی 🏆
                    </button>
                  )}
                </div>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
