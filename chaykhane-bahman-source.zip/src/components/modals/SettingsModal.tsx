import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  User,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Eye,
  Check,
  Sparkles,
  MapPin,
  ShieldCheck,
  AlertCircle,
  ImageIcon,
  Sliders,
  Award,
} from 'lucide-react';
import { PlayerProfile } from '../../types';
import { registerPlayerOnServer } from '../../services/backendApi';
import { soundEngine } from '../../audio/SoundEngine';
import { SUGGESTED_AVATARS, getAvatarById } from '../../constants/avatars';
import { IRAN_PROVINCES } from '../../constants/iranProvinces';
import {
  getBadgeById,
  equipPlayerBadge,
  PAHLAVANI_BADGES,
} from '../../services/PahlavaniAchievements';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: PlayerProfile;
  onProfileUpdated: (profile: PlayerProfile) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  volume: number;
  onVolumeChange: (vol: number) => void;
  isNightMode: boolean;
  onToggleNightMode: () => void;
  colorblindMode: boolean;
  onToggleColorblind: () => void;
  onOpenAchievements?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentProfile,
  onProfileUpdated,
  soundEnabled,
  onToggleSound,
  volume,
  onVolumeChange,
  isNightMode,
  onToggleNightMode,
  colorblindMode,
  onToggleColorblind,
  onOpenAchievements,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'game'>('profile');

  // Profile Form State
  const [firstName, setFirstName] = useState(currentProfile.firstName || '');
  const [lastName, setLastName] = useState(currentProfile.lastName || '');
  const [nickname, setNickname] = useState(currentProfile.nickname || '');
  const [selectedAvatarId, setSelectedAvatarId] = useState(currentProfile.avatarId || 'osta_bahman');
  const [selectedProvince, setSelectedProvince] = useState(currentProfile.province || 'تهران');
  const [selectedCity, setSelectedCity] = useState(currentProfile.city || 'تهران');

  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Sync state when opened or currentProfile changes
  useEffect(() => {
    if (isOpen) {
      setFirstName(currentProfile.firstName || '');
      setLastName(currentProfile.lastName || '');
      setNickname(currentProfile.nickname || '');
      setSelectedAvatarId(currentProfile.avatarId || 'osta_bahman');
      setSelectedProvince(currentProfile.province || 'تهران');
      setSelectedCity(currentProfile.city || 'تهران');
      setFeedback(null);
    }
  }, [isOpen, currentProfile]);

  if (!isOpen) return null;

  const currentProvinceInfo =
    IRAN_PROVINCES.find((p) => p.name === selectedProvince) || IRAN_PROVINCES[0];

  const handleProvinceChange = (prov: string) => {
    setSelectedProvince(prov);
    const pInfo = IRAN_PROVINCES.find((p) => p.name === prov);
    if (pInfo && pInfo.majorCities.length > 0) {
      setSelectedCity(pInfo.majorCities[0]);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim()) {
      setFeedback({
        type: 'error',
        message: 'لطفاً نام و نام خانوادگی را وارد کنید.',
      });
      return;
    }

    setIsLoading(true);
    setFeedback(null);
    soundEngine.playClick();

    try {
      const res = await registerPlayerOnServer(
        firstName.trim(),
        lastName.trim(),
        selectedAvatarId,
        selectedProvince,
        selectedCity,
        nickname.trim()
      );
      setIsLoading(false);

      const updated: PlayerProfile = {
        ...currentProfile,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        nickname: nickname.trim() || `${firstName.trim()} ${lastName.trim()}`,
        avatarId: selectedAvatarId,
        province: selectedProvince,
        city: selectedCity,
        isRegistered: true,
        registeredAt: Date.now(),
      };
      onProfileUpdated(updated);

      soundEngine.playSanturVictory();
      setFeedback({
        type: 'success',
        message: res.message || 'مشخصات شما با موفقیت در دیتابیس ثبت و به‌روزرسانی شد!',
      });

      setTimeout(() => {
        setFeedback(null);
      }, 3000);
    } catch {
      setIsLoading(false);
      setFeedback({
        type: 'error',
        message: 'خطایی رخ داد، اما اطلاعات به صورت محلی ذخیره گردید.',
      });
    }
  };

  const activeAvatar = getAvatarById(selectedAvatarId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-md max-h-[92vh] flex flex-col rounded-[32px] p-4 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300">
                <Settings className="w-4 h-4" />
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                تنظیمات و پروفایل اوستا
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                ویرایش نام، استان، شهر، تصویر شاخص و صدا
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center transition-colors cursor-pointer"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-[#1C0D05] border border-amber-700/50 my-3 text-center">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('profile');
            }}
            className={`py-1.5 rounded-xl font-lalezar text-xs cursor-pointer transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'profile'
                ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-bold shadow'
                : 'text-amber-300 hover:text-amber-100'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>مشخصات و تصویر شاخص</span>
          </button>
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab('game');
            }}
            className={`py-1.5 rounded-xl font-lalezar text-xs cursor-pointer transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'game'
                ? 'bg-gradient-to-r from-teal-600 to-emerald-500 text-white font-bold shadow'
                : 'text-teal-300 hover:text-teal-100'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>صدا و محیط بازی</span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto space-y-3.5 pr-0.5 custom-scrollbar">
          {activeTab === 'profile' ? (
            <form onSubmit={handleSaveProfile} className="space-y-3.5">
              {/* Selected Avatar Highlight Box */}
              <div className="p-3 rounded-2xl bg-[#231107] border-2 border-amber-500/50 flex items-center gap-3">
                <div className="w-14 h-14 rounded-full overflow-hidden bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow-lg flex items-center justify-center shrink-0">
                  {activeAvatar.image ? (
                    <img
                      src={activeAvatar.image}
                      alt={activeAvatar.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <div className={`w-full h-full rounded-full bg-gradient-to-tr ${activeAvatar.bgGradient} flex items-center justify-center text-2xl`}>
                      {activeAvatar.emoji}
                    </div>
                  )}
                </div>

                <div className="text-right flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-lalezar text-sm text-yellow-300 truncate">
                      {activeAvatar.name}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-950 text-yellow-300 border border-amber-600 font-vazir">
                      {activeAvatar.badge}
                    </span>
                  </div>
                  <span className="text-[10px] text-amber-200/80 font-vazir block truncate">
                    {activeAvatar.title}
                  </span>
                  <span className="text-[9px] text-amber-300/60 font-vazir block truncate mt-0.5">
                    {activeAvatar.description}
                  </span>
                  {/* Active Pahlavani Badge */}
                  {(() => {
                    const activePahlavaniBadge = getBadgeById(currentProfile.activeBadgeId);
                    if (activePahlavaniBadge) {
                      return (
                        <div className="mt-1.5 flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-gradient-to-r from-amber-950 via-amber-900 to-amber-950 border border-amber-500/70 text-yellow-300 w-fit shadow-sm">
                          <span className="text-xs">{activePahlavaniBadge.icon}</span>
                          <span className="text-[10px] font-lalezar font-bold">{activePahlavaniBadge.title}</span>
                        </div>
                      );
                    }
                    return null;
                  })()}
                </div>
              </div>

              {/* Avatar Picker Shelf (۱۰ تصویر پیشنهادی باصفا) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] text-amber-300/70 font-vazir">
                    روی هر کدام کلیک کنید تا انتخاب شود:
                  </span>
                  <label className="text-xs font-bold text-amber-300 font-vazir flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-yellow-400" />
                    <span>انتخاب تصویر شاخص:</span>
                  </label>
                </div>

                <div className="grid grid-cols-5 gap-2 p-2 rounded-2xl bg-[#1C0D05] border border-amber-700/60 max-h-36 overflow-y-auto custom-scrollbar">
                  {SUGGESTED_AVATARS.map((av) => {
                    const isSelected = selectedAvatarId === av.id;
                    return (
                      <button
                        key={av.id}
                        type="button"
                        onClick={() => {
                          soundEngine.playClick();
                          setSelectedAvatarId(av.id);
                        }}
                        className={`relative flex flex-col items-center p-1 rounded-xl border-2 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-950/90 border-yellow-400 shadow-md scale-105 ring-2 ring-yellow-400'
                            : 'bg-[#291308] border-stone-800 hover:border-amber-500 opacity-80 hover:opacity-100'
                        }`}
                        title={`${av.name} - ${av.title}`}
                      >
                        <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-tr from-amber-500 to-yellow-300 p-0.5 shadow flex items-center justify-center">
                          {av.image ? (
                            <img
                              src={av.image}
                              alt={av.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full rounded-full object-cover"
                            />
                          ) : (
                            <div className={`w-full h-full rounded-full bg-gradient-to-tr ${av.bgGradient} flex items-center justify-center text-lg`}>
                              {av.emoji}
                            </div>
                          )}
                        </div>
                        <span className="text-[9px] font-lalezar text-amber-200 mt-1 truncate w-full text-center">
                          {av.name}
                        </span>
                        {isSelected && (
                          <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] shadow">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* First Name & Last Name */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-amber-300 mb-1 font-vazir text-right">
                    نام: <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="مثلاً: بهمن"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[#200F05] border border-amber-600/70 text-amber-100 focus:outline-none focus:border-yellow-400 transition-colors text-right font-vazir shadow-sm"
                    required
                    maxLength={40}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-300 mb-1 font-vazir text-right">
                    نام خانوادگی: <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="مثلاً: بامزد"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-[#200F05] border border-amber-600/70 text-amber-100 focus:outline-none focus:border-yellow-400 transition-colors text-right font-vazir shadow-sm"
                    required
                    maxLength={40}
                  />
                </div>
              </div>

              {/* Nickname in Leaderboard */}
              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1 font-vazir text-right">
                  لقب نمایشی در جدول رقبا (اختیاری):
                </label>
                <input
                  type="text"
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  placeholder={
                    firstName && lastName ? `${firstName} ${lastName}` : 'مثلاً: داش بهمن بامزد'
                  }
                  className="w-full px-3 py-2 text-xs rounded-xl bg-[#200F05] border border-amber-600/70 text-amber-100 focus:outline-none focus:border-yellow-400 transition-colors text-right font-vazir shadow-sm"
                  maxLength={50}
                />
              </div>

              {/* Province & City Selection */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-amber-300 mb-1 font-vazir text-right flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-teal-400" />
                    <span>استان:</span>
                  </label>
                  <select
                    value={selectedProvince}
                    onChange={(e) => handleProvinceChange(e.target.value)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl bg-[#200F05] border border-amber-600/70 text-amber-100 focus:outline-none focus:border-yellow-400 transition-colors text-right font-vazir shadow-sm cursor-pointer"
                  >
                    {IRAN_PROVINCES.map((prov) => (
                      <option key={prov.name} value={prov.name} className="bg-[#2A1408] text-white">
                        {prov.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-amber-300 mb-1 font-vazir text-right">
                    شهر:
                  </label>
                  <select
                    value={selectedCity}
                    onChange={(e) => setSelectedCity(e.target.value)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl bg-[#200F05] border border-amber-600/70 text-amber-100 focus:outline-none focus:border-yellow-400 transition-colors text-right font-vazir shadow-sm cursor-pointer"
                  >
                    {currentProvinceInfo.majorCities.map((c) => (
                      <option key={c} value={c} className="bg-[#2A1408] text-white">
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Online Cloud Storage Note */}
              <div className="p-2.5 rounded-xl bg-amber-950/60 border border-amber-600/40 text-[10px] text-amber-200/80 font-vazir flex items-start gap-1.5 leading-relaxed">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  اطلاعات شما پس از ذخیره، به صورت آنلاین در سرور دیتابیس ثبت و در جدول رقبای استانی و کشوری نمایش داده می‌شود.
                </span>
              </div>

              {/* Feedback Alert */}
              {feedback && (
                <div
                  className={`p-2.5 rounded-xl text-xs font-vazir font-semibold flex items-center gap-1.5 ${
                    feedback.type === 'success'
                      ? 'bg-emerald-950 border border-emerald-400 text-emerald-200'
                      : 'bg-rose-950 border border-rose-500 text-rose-200'
                  }`}
                >
                  {feedback.type === 'success' ? (
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                  )}
                  <span>{feedback.message}</span>
                </div>
              )}

              {/* Save Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-amber-950 font-lalezar text-base shadow-lg border border-amber-200 transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer font-bold"
              >
                {isLoading ? (
                  <span>در حال ذخیره‌سازی...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>ذخیره مشخصات و تصویر شاخص</span>
                  </>
                )}
              </button>

              {/* Pahlavani Badges & Honors Showcase Shelf */}
              <div className="p-3 rounded-2xl bg-[#231107] border border-amber-600/50 space-y-2 mt-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-lalezar text-yellow-300">
                    <Award className="w-4 h-4 text-yellow-400" />
                    <span>نشان‌ها و مدال‌های پهلوانی پروفایل</span>
                  </div>
                  {onOpenAchievements && (
                    <button
                      type="button"
                      onClick={() => {
                        soundEngine.playClick();
                        onOpenAchievements();
                      }}
                      className="text-[10px] font-lalezar text-amber-300 hover:text-yellow-200 underline cursor-pointer"
                    >
                      تالار مدال‌ها و جوایز 🏆
                    </button>
                  )}
                </div>

                <p className="text-[10px] text-amber-200/70 font-vazir leading-relaxed">
                  نشان‌های کسب‌شده در زیر نمایش داده می‌شوند. برای نصب هر نشان روی پروفایل و کارت ویزیت، روی آن کلیک کنید:
                </p>

                {currentProfile.unlockedBadgeIds && currentProfile.unlockedBadgeIds.length > 0 ? (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    {currentProfile.unlockedBadgeIds.map((badgeId) => {
                      const badge = getBadgeById(badgeId);
                      if (!badge) return null;
                      const isEquipped = currentProfile.activeBadgeId === badge.id;

                      return (
                        <button
                          key={badge.id}
                          type="button"
                          onClick={() => {
                            soundEngine.playClick();
                            const res = equipPlayerBadge(badge.id);
                            if (res.success) {
                              onProfileUpdated({
                                ...currentProfile,
                                activeBadgeId: badge.id,
                              });
                            }
                          }}
                          className={`p-2 rounded-xl text-right flex items-center gap-2 border transition-all cursor-pointer ${
                            isEquipped
                              ? 'bg-amber-900/70 border-yellow-400 shadow-md scale-102'
                              : 'bg-[#180A03] border-amber-800/60 hover:border-amber-600'
                          }`}
                        >
                          <div
                            className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${badge.gradient} p-0.5 flex items-center justify-center shrink-0 shadow`}
                          >
                            <div className="w-full h-full rounded-[10px] bg-[#1C0B03] flex items-center justify-center text-sm">
                              {badge.icon}
                            </div>
                          </div>
                          <div className="min-w-0 flex-1">
                            <span className="font-lalezar text-xs text-yellow-200 block truncate">
                              {badge.title}
                            </span>
                            <span className="text-[9px] font-vazir text-amber-300/80 block truncate">
                              {isEquipped ? '✓ نشان فعال' : 'ضربه برای انتخاب'}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-[#180A03] border border-amber-900/60 text-center">
                    <span className="text-[11px] font-vazir text-amber-300/80 block mb-1.5">
                      هنوز نشانی کسب نکرده‌اید! با انجام مأموریت‌های چایخانه نشان افتخار بگیرید.
                    </span>
                    {onOpenAchievements && (
                      <button
                        type="button"
                        onClick={() => {
                          soundEngine.playClick();
                          onOpenAchievements();
                        }}
                        className="px-3 py-1 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 text-amber-950 font-lalezar text-xs font-bold shadow hover:brightness-110 active:scale-95 transition-all cursor-pointer"
                      >
                        ورود به تالار مدال‌ها و دستاوردها 🏆
                      </button>
                    )}
                  </div>
                )}
              </div>
            </form>
          ) : (
            /* Tab 2: Game Settings (Audio, Night Lantern, Accessibility) */
            <div className="space-y-3 animate-fade-in">
              {/* Sound & Music Controls */}
              <div className="p-3 rounded-2xl bg-[#231107] border border-amber-600/50 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        soundEnabled ? 'bg-amber-500 text-amber-950' : 'bg-[#3A1B0C] text-amber-400'
                      }`}
                    >
                      {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                    </div>
                    <div className="text-right">
                      <span className="font-lalezar text-xs text-yellow-200 block">
                        صدا و موسیقی سنتی
                      </span>
                      <span className="text-[9px] text-amber-200/70 font-vazir">
                        صدای قل‌قل سماور، ریختن چای و نوای تار
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      soundEngine.playClick();
                      onToggleSound();
                    }}
                    className={`px-3 py-1 rounded-full font-lalezar text-xs transition-all cursor-pointer ${
                      soundEnabled ? 'bg-emerald-600 text-white shadow' : 'bg-stone-800 text-stone-400'
                    }`}
                  >
                    {soundEnabled ? 'روشن ✓' : 'خاموش ✕'}
                  </button>
                </div>

                {/* Volume Slider */}
                {soundEnabled && (
                  <div className="pt-2 border-t border-amber-900/50 flex items-center gap-2">
                    <span className="text-[10px] text-amber-300 font-vazir whitespace-nowrap">
                      میزان صدا:
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={volume}
                      onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                      className="w-full accent-amber-500 cursor-pointer"
                    />
                  </div>
                )}
              </div>

              {/* Cozy Night Mode Lantern Toggle */}
              <div className="p-3 rounded-2xl bg-[#231107] border border-amber-600/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isNightMode ? 'bg-indigo-600 text-yellow-300' : 'bg-amber-500 text-amber-950'
                    }`}
                  >
                    {isNightMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-yellow-200 block">
                      حالت شبانه چراغ گردسوز
                    </span>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      نور ملایم شمع و فضای دنج شب‌های چایخانه
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    soundEngine.playClick();
                    onToggleNightMode();
                  }}
                  className={`px-3 py-1 rounded-full font-lalezar text-xs transition-all cursor-pointer ${
                    isNightMode ? 'bg-indigo-600 text-white shadow' : 'bg-amber-600 text-amber-950'
                  }`}
                >
                  {isNightMode ? 'شبانه 🌙' : 'روزانه ☀️'}
                </button>
              </div>

              {/* Accessibility: Colorblind Assistance */}
              <div className="p-3 rounded-2xl bg-[#231107] border border-amber-600/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      colorblindMode ? 'bg-teal-600 text-white' : 'bg-[#3A1B0C] text-teal-300'
                    }`}
                  >
                    <Eye className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <span className="font-lalezar text-xs text-yellow-200 block">
                      حالت کمکی دسترس‌پذیری رنگ‌ها
                    </span>
                    <span className="text-[9px] text-amber-200/70 font-vazir">
                      نمایش حروف اختصاری روی لایه‌های استکان
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    soundEngine.playClick();
                    onToggleColorblind();
                  }}
                  className={`px-3 py-1 rounded-full font-lalezar text-xs transition-all cursor-pointer ${
                    colorblindMode ? 'bg-teal-600 text-white shadow' : 'bg-stone-800 text-stone-400'
                  }`}
                >
                  {colorblindMode ? 'فعال ✓' : 'غیرفعال'}
                </button>
              </div>

              {/* App Version & Credits */}
              <div className="p-3 rounded-2xl bg-[#1C0D05] border border-amber-800/50 text-[10px] text-amber-300/80 font-vazir space-y-1">
                <div className="flex items-center justify-between">
                  <span>بازی سنتی چایخانه عمو بهمن</span>
                  <span className="font-lalezar text-yellow-300 text-xs">نسخه ۱.۱.۰</span>
                </div>
                <div className="flex items-center justify-between text-[9px] text-amber-200/60 pt-1 border-t border-amber-950">
                  <span>طراحی و توسعه: مهندس بهمن بامزد</span>
                  <span>پایگاه داده آنلاین فعال</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-3 pt-2 border-t border-[#3E1F0F] text-center text-[10px] text-amber-300/70 font-vazir flex items-center justify-between">
          <span className="font-lalezar text-yellow-300">چایخانه عمو بهمن</span>
          <span>تنظیمات یکپارچه ابری</span>
          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="text-amber-200 hover:text-white font-vazir underline cursor-pointer"
          >
            بستن پنجره
          </button>
        </div>
      </div>
    </div>
  );
};
