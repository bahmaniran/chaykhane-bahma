import React, { useState, useEffect, useRef } from 'react';
import { X, Trophy, AlertCircle, Sparkles } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import { toPersianDigits, formatPersianCoins } from '../../utils/persianNumbers';

interface SiniGardaniModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFinish: (coinsAwarded: number) => void;
}

export const SiniGardaniModal: React.FC<SiniGardaniModalProps> = ({
  isOpen,
  onClose,
  onFinish,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(20);
  const [angle, setAngle] = useState(0); // -30 to +30 degrees
  const [glassesLeft, setGlassesLeft] = useState(5);
  const [isGameOver, setIsGameOver] = useState(false);
  const [coinsWon, setCoinsWon] = useState(0);

  const angleRef = useRef(0);
  const glassesRef = useRef(5);

  angleRef.current = angle;
  glassesRef.current = glassesLeft;

  // Game Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    // Timer countdown
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Physics & crowd bumps
    const physicsInterval = setInterval(() => {
      // Random push from teahouse crowd
      const push = (Math.random() - 0.5) * 4.5;
      setAngle((prev) => {
        const next = prev + push;
        // If angle slips past 25deg, drop a glass
        if (Math.abs(next) > 25 && glassesRef.current > 0) {
          soundEngine.playTrayClatter();
          setGlassesLeft((g) => Math.max(0, g - 1));
          return next > 0 ? 12 : -12; // recover slight balance
        }
        return Math.max(-30, Math.min(30, next));
      });
    }, 100);

    return () => {
      clearInterval(timer);
      clearInterval(physicsInterval);
    };
  }, [isPlaying, isGameOver]);

  const startGame = () => {
    soundEngine.playClick();
    setTimeLeft(20);
    setAngle(0);
    setGlassesLeft(5);
    setIsGameOver(false);
    setCoinsWon(0);
    setIsPlaying(true);
  };

  const endGame = () => {
    setIsPlaying(false);
    setIsGameOver(true);
    const reward = Math.max(20, glassesRef.current * 30);
    setCoinsWon(reward);
    soundEngine.playCoins();
    onFinish(reward);
  };

  const tiltLeft = () => {
    if (!isPlaying) return;
    soundEngine.playGlassClink();
    setAngle((prev) => Math.max(-30, prev - 7));
  };

  const tiltRight = () => {
    if (!isPlaying) return;
    soundEngine.playGlassClink();
    setAngle((prev) => Math.min(30, prev + 7));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[32px] p-5 bg-gradient-to-b from-[#3A1E0E] via-[#2C160A] to-[#1E0E06] border-4 border-[#F59E0B] shadow-[0_15px_50px_rgba(245,158,11,0.3)] text-[#FFFBF0]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#522E18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full rounded-full bg-[#200F05] flex items-center justify-center text-amber-300 text-sm">
                🍽️
              </div>
            </div>
            <div>
              <h2 className="font-lalezar text-base text-yellow-300 leading-tight">
                مینی‌گیم سینی‌گردانی قهوه‌خانه
              </h2>
              <p className="text-[10px] text-amber-200/70 font-vazir">
                هنر حفظ تعادل سینی چای در شلوغی بازار
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="w-7 h-7 rounded-full bg-[#4A2613] hover:bg-[#66351B] text-amber-200 flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Gameplay Area */}
        <div className="my-4">
          {!isPlaying && !isGameOver ? (
            // Intro
            <div className="text-center py-4 space-y-3">
              <div className="text-4xl animate-bounce">☕</div>
              <h3 className="font-lalezar text-lg text-yellow-200">
                چالش ۲۰ ثانیه‌ای شاگرد قهوه‌چی!
              </h3>
              <p className="text-[11px] text-amber-200/80 font-vazir leading-relaxed px-2">
                مشتری‌ها تنه می‌زنند و سینی تکان می‌خورد! با دکمه‌های چپ و راست تعادل سینی را حفظ کن تا استکان‌ها نریزند و تا ۱۵۰ سکه انعام بگیری!
              </p>
              <button
                onClick={startGame}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 font-lalezar text-sm font-bold shadow-lg hover:brightness-110 active:scale-95 transition-transform cursor-pointer"
              >
                شروع سینی‌گردانی (۲۰ ثانیه)
              </button>
            </div>
          ) : isGameOver ? (
            // Results
            <div className="text-center py-4 space-y-2 animate-fade-in">
              <Trophy className="w-12 h-12 text-yellow-400 mx-auto animate-bounce" />
              <h3 className="font-lalezar text-lg text-yellow-300">
                دست مریزاد اوستا!
              </h3>
              <p className="text-xs text-amber-200 font-vazir">
                {toPersianDigits(glassesLeft)} استکان را سالم به میز مشتری‌ها رساندی!
              </p>
              <div className="text-xl font-lalezar text-yellow-300 my-2">
                +{formatPersianCoins(coinsWon)} سکه انعام ★
              </div>
              <button
                onClick={startGame}
                className="w-full py-2 rounded-xl bg-amber-600 text-amber-950 font-lalezar text-xs font-bold shadow hover:brightness-110 cursor-pointer"
              >
                دوباره امتحان کن
              </button>
            </div>
          ) : (
            // Active Balancing Tray
            <div>
              <div className="flex items-center justify-between px-2 mb-2">
                <span className="font-lalezar text-xs text-yellow-300">
                  زمان مانده: {toPersianDigits(timeLeft)} ثانیه
                </span>
                <span className="font-lalezar text-xs text-amber-300">
                  استکان‌های سالم: {toPersianDigits(glassesLeft)} / ۵
                </span>
              </div>

              {/* Physical Tray Simulation */}
              <div className="h-44 rounded-2xl bg-[#140803] border-2 border-[#8B5226] flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
                {/* Visual copper tray tilting */}
                <div
                  className="transition-transform duration-100 ease-out flex flex-col items-center"
                  style={{ transform: `rotate(${angle}deg)` }}
                >
                  {/* Glasses on tray */}
                  <div className="flex items-end gap-2 mb-0.5">
                    {Array.from({ length: glassesLeft }).map((_, i) => (
                      <span key={i} className="text-xl filter drop-shadow">
                        🍵
                      </span>
                    ))}
                  </div>

                  {/* Copper Engraved Tray Bar */}
                  <div className="w-48 h-4 rounded-full bg-gradient-to-r from-[#92400E] via-[#F59E0B] to-[#92400E] border-2 border-yellow-200 shadow-xl" />
                </div>

                {/* Tilt danger warning indicator */}
                {Math.abs(angle) > 18 && (
                  <div className="absolute top-2 bg-red-900/90 text-red-200 px-2 py-0.5 rounded-full text-[10px] font-lalezar animate-ping">
                    خطر ریختن چای!
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <button
                  onClick={tiltLeft}
                  className="py-3 rounded-2xl bg-[#3D1E0C] hover:bg-[#522810] border border-amber-500/70 text-yellow-200 font-lalezar text-sm shadow-md active:scale-95 transition-all cursor-pointer"
                >
                  ◀ کج به چپ
                </button>
                <button
                  onClick={tiltRight}
                  className="py-3 rounded-2xl bg-[#3D1E0C] hover:bg-[#522810] border border-amber-500/70 text-yellow-200 font-lalezar text-sm shadow-md active:scale-95 transition-all cursor-pointer"
                >
                  کج به راست ▶
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-[#522E18] text-center">
          <p className="text-[10px] text-amber-300/60 font-vazir">
            تعادل سینی چای • چابکی و مهارت پهلوانان قهوه‌خانه
          </p>
        </div>
      </div>
    </div>
  );
};
