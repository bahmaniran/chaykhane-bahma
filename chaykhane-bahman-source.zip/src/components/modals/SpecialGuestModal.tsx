import React from 'react';
import { X } from 'lucide-react';
import { soundEngine } from '../../audio/SoundEngine';
import ghafourAvatar from '../../assets/images/ghafour_exact_avatar_1791919275034.webp';

interface SpecialGuestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAcceptChallenge: () => void;
  isAccepted: boolean;
}

export const SpecialGuestModal: React.FC<SpecialGuestModalProps> = ({
  isOpen,
  onClose,
  onAcceptChallenge,
  isAccepted,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-[#180A03]/85 backdrop-blur-sm animate-fade-in select-none">
      {/* Persian Turquoise Tile Arch Frame (کاشی‌کاری فیروزه‌ای اسلیمی دقیقا مثل عکس شماره ۱) */}
      <div className="relative w-full max-w-sm max-h-[92vh] overflow-y-auto rounded-[36px] p-2 bg-gradient-to-b from-[#0D9488] via-[#065F56] to-[#043E38] border-4 border-[#5EEAD4] shadow-[0_15px_50px_rgba(0,0,0,0.9)] text-[#FFFBF0]">
        {/* Red Circular 'X' Close Button (Top-Right as in image 1) */}
        <button
          onClick={() => {
            soundEngine.playClick();
            onClose();
          }}
          className="absolute -top-3 -right-3 z-30 w-9 h-9 rounded-full bg-gradient-to-b from-rose-500 to-red-700 hover:brightness-110 text-white flex items-center justify-center border-2 border-white shadow-xl transition-transform active:scale-90"
          title="بستن پنجره"
        >
          <X className="w-5 h-5 stroke-[2.5]" />
        </button>

        {/* Inner Ornate Container with Persian Tiles Outline */}
        <div className="rounded-[30px] p-4 bg-gradient-to-b from-[#FFFBF0] via-[#FDF8E7] to-[#F7EDCE] border-2 border-[#D97706]/40 flex flex-col items-center text-center relative overflow-hidden">
          {/* Top Turquoise Banner: مشتری ویژه امروز: پهلوان غفور! */}
          <div className="w-full py-2 px-3 rounded-2xl bg-gradient-to-r from-[#0F766E] via-[#0D9488] to-[#0F766E] border-2 border-[#99F6E4] shadow-md mb-3 flex items-center justify-center">
            <h2 className="font-lalezar text-sm sm:text-base text-white tracking-wide drop-shadow">
              مشتری ویژه امروز: پهلوان غفور!
            </h2>
          </div>

          {/* Dialogue Speech Bubble (pointing to Pahlevan Ghafour) */}
          <div className="relative w-full bg-[#FFFFFF] text-[#2C1A11] p-3 rounded-2xl border-2 border-[#D4A373] shadow-sm mb-3 text-right">
            <p className="font-vazir text-xs sm:text-sm font-bold leading-relaxed text-[#3B1E08]">
              عمو بهمن، واسه ما یه شربت مشتی و دوفاز خاکشیر-زعفرون بریز صفا کنیم!
            </p>
            {/* Speech bubble tail pointing towards Pahlevan below */}
            <div className="absolute -bottom-2 right-12 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[8px] border-t-white" />
          </div>

          {/* Pahlevan Ghafour Character Illustration & Mini Copper Tray */}
          <div className="relative w-full flex flex-col items-center mb-3">
            {/* Pahlevan Portrait Image with Fez Cap & Embroidered Vest */}
            <div className="w-36 h-36 rounded-2xl overflow-hidden border-2 border-[#B8860B] shadow-md bg-[#2A160D]">
              <img
                src={ghafourAvatar}
                alt="پهلوان غفور"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-top"
                onError={(e) => {
                  const target = e.currentTarget;
                  target.style.display = 'none';
                }}
              />
            </div>

            {/* Mini Copper Tray in front with 4 estekans */}
            <div className="w-48 -mt-6 z-10 rounded-full px-3 py-1.5 bg-gradient-to-r from-[#CD6D3C] via-[#B85D38] to-[#CD6D3C] border-2 border-[#F7A97E] shadow-lg flex items-center justify-center gap-2">
              <span className="text-xs">🫖</span>
              <span className="font-lalezar text-[11px] text-[#FFEAD9]">
                سفارش: شربت زعفران و خاکشیر (۲ برابر سکه)
              </span>
            </div>
          </div>

          {/* Bottom Green Button: قبول چالش و پذیرایی */}
          <button
            onClick={() => {
              soundEngine.playCoin();
              onAcceptChallenge();
            }}
            disabled={isAccepted}
            className={`w-full py-3 px-4 rounded-2xl font-lalezar text-base transition-all shadow-lg border-2 ${
              isAccepted
                ? 'bg-teal-800 text-teal-100 border-teal-400 cursor-default'
                : 'bg-gradient-to-b from-[#10B981] via-[#059669] to-[#047857] hover:brightness-110 active:scale-95 text-white border-[#A7F3D0] shadow-emerald-900/40 cursor-pointer'
            }`}
          >
            {isAccepted ? 'چالش پذیرفته شد ✓ (۲ برابر سکه)' : 'قبول چالش و پذیرایی'}
          </button>
        </div>
      </div>
    </div>
  );
};
