import bahmanAvatarImg from '../assets/images/bahman_exact_avatar_1791919274915.webp';
import ghafourAvatarImg from '../assets/images/ghafour_exact_avatar_1791919275034.webp';

export interface TeahouseAvatar {
  id: string;
  name: string;
  title: string;
  badge: string;
  image?: string;
  emoji: string;
  bgGradient: string;
  borderColor: string;
  description: string;
}

export const SUGGESTED_AVATARS: TeahouseAvatar[] = [
  {
    id: 'osta_bahman',
    name: 'اوستا بهمن',
    title: 'صاحب چایخانه و قهوه‌چی کهنه‌کار',
    badge: '👑 اوستای کل',
    image: bahmanAvatarImg,
    emoji: '🫖',
    bgGradient: 'from-amber-600 via-yellow-500 to-amber-700',
    borderColor: '#F59E0B',
    description: 'سماورش همیشه به راهه و دلش به صفای رفقا روشنه.',
  },
  {
    id: 'pahlevan_ghafour',
    name: 'پهلوان غفور',
    title: 'قهرمان زورخانه و لوتی سنگلج',
    badge: '🦁 پهلوان نامی',
    image: ghafourAvatarImg,
    emoji: '💪',
    bgGradient: 'from-red-700 via-amber-600 to-orange-700',
    borderColor: '#DC2626',
    description: 'دست‌به‌خیر، مظهر فتوت و عاشق چای قندپهلو بعد از میل باستانی.',
  },
  {
    id: 'mirza_habib',
    name: 'میرزا حبیب خوش‌نویس',
    title: 'کاتب محله و روزنامه‌خوان',
    badge: '📜 میرزا قلم‌دان',
    emoji: '🖋️',
    bgGradient: 'from-teal-700 via-emerald-600 to-teal-800',
    borderColor: '#0D9488',
    description: 'عینک دسته‌شاخه‌ای به چشم دارد و با طمانینه چای دارچین می‌نوشد.',
  },
  {
    id: 'mashti_jafar',
    name: 'مشتی جعفر ساعت‌ساز',
    title: 'تعمیرکار ساعت‌های بغلی قاجاری',
    badge: '⏱️ ساعت‌ساز',
    emoji: '🕰️',
    bgGradient: 'from-indigo-700 via-purple-600 to-indigo-900',
    borderColor: '#8B5CF6',
    description: 'تنباکوی شیرازی می‌کشد و رمز گاوصندوق عتیقه را بلد است.',
  },
  {
    id: 'bibi_jan',
    name: 'بی‌بی‌جان چای‌ریز',
    title: 'کدبانوی دلسوز و مادر چایخانه',
    badge: '👵 بی‌بی باصفا',
    emoji: '☕',
    bgGradient: 'from-rose-600 via-pink-500 to-amber-700',
    borderColor: '#F43F5E',
    description: 'بهترین شربت خاکشیر و زعفران را با عطر هل مادرانه آماده می‌کند.',
  },
  {
    id: 'shater_abbas',
    name: 'شاطر عباس سنگکی',
    title: 'نانوای قدیمی گذر بازار',
    badge: '🥖 شاطر محل',
    emoji: '🌾',
    bgGradient: 'from-amber-700 via-yellow-600 to-amber-800',
    borderColor: '#D97706',
    description: 'نان سنگک کنجدی داغ می‌پزد و چای بعد از تنور به جانش می‌نشیند.',
  },
  {
    id: 'golnar_khatoon',
    name: 'گلنار خاتون',
    title: 'بانوی هنرمند ترمه‌دوز',
    badge: '🌸 ترمه‌دوز',
    emoji: '🪡',
    bgGradient: 'from-purple-700 via-fuchsia-600 to-pink-700',
    borderColor: '#C026D3',
    description: 'رومیزی‌های نفیس فیروزه‌ای چایخانه را با عشق و سرمه‌دوزی آراسته است.',
  },
  {
    id: 'tayyeb_khan',
    name: 'طیّب خان پیش‌کسوت',
    title: 'ریش‌سفید و میانجی محله',
    badge: '⭐ بزرگ محله',
    emoji: '🪙',
    bgGradient: 'from-stone-700 via-amber-800 to-stone-900',
    borderColor: '#EAB308',
    description: 'حرفش سند است و دفتر نسیه عمو بهمن به ضمانت او باز می‌ماند.',
  },
  {
    id: 'shahin_sini_gardoon',
    name: 'شاهین سینی‌گردان',
    title: 'شاگرد چابک و رکورددار سینی‌گردانی',
    badge: '🍽️ قهرمان سینی',
    emoji: '⚡',
    bgGradient: 'from-cyan-700 via-teal-600 to-blue-800',
    borderColor: '#06B6D4',
    description: 'با یک دست سینی مسی با هفت استکان لب‌ریز را روی دست می‌چرخاند.',
  },
  {
    id: 'sohrab_ranandeh',
    name: 'فریدون شوفِر',
    title: 'راننده ترانزیت جاده قدیم تهران-مشهد',
    badge: '🚚 راننده باصفا',
    emoji: '🛣️',
    bgGradient: 'from-blue-700 via-slate-600 to-blue-900',
    borderColor: '#3B82F6',
    description: 'از دل جاده‌ها آمده تا خستگی راه را با چای دیشلمه عمو بهمن به در کند.',
  },
];

export function getAvatarById(id?: string): TeahouseAvatar {
  if (!id) return SUGGESTED_AVATARS[0];
  const found = SUGGESTED_AVATARS.find((a) => a.id === id);
  return found || SUGGESTED_AVATARS[0];
}
