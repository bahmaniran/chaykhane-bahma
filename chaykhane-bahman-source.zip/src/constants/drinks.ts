import { DrinkInfo, DrinkType } from '../types';

export const DRINKS_DATA: Record<DrinkType, DrinkInfo> = {
  // ۱. زرد: زعفران درخشان خورشیدی (Vivid Luminous Sunburst Yellow)
  saffron: {
    id: 'saffron',
    persianName: 'شربت زعفران خورشیدی',
    shortName: 'زرد زعفرانی',
    subtitle: 'زعفران سرگل با زرد درخشان خورشیدی و شفاف',
    gradient: ['#FFE600', '#F59E0B'], // Bright vivid sunburst yellow to saturated golden amber
    char: 'ز',
    textureType: 'sparkle',
    accentColor: '#EAB308',
  },

  // ۲. مشکی: چای سیاه و آبنوس سلطنتی (Deep Midnight Obsidian Black)
  khakshir: {
    id: 'khakshir',
    persianName: 'شربت آبنوس و چای مشکی',
    shortName: 'مشکی آبنوس',
    subtitle: 'عصاره چای سیاه کلکته و آبنوس درباری با تلألو کریستالی',
    gradient: ['#3F3F46', '#09090B'], // Charcoal silver-rimmed obsidian black
    char: 'م',
    textureType: 'seeds',
    accentColor: '#18181B',
  },

  // ۳. آبی: شربت لاجورد و بیدمشک آبی درباری (Electric Royal Sapphire Blue)
  bidmeshk: {
    id: 'bidmeshk',
    persianName: 'شربت لاجورد و بیدمشک آبی',
    shortName: 'آبی لاجورد',
    subtitle: 'آبی لاجوردی و فیروزه‌ای درخشان با عطر نسترن شاهانه',
    gradient: ['#00D2FF', '#1D4ED8'], // Glowing vivid cyan-blue to deep royal blue
    char: 'آ',
    textureType: 'mint',
    accentColor: '#2563EB',
  },

  // ۴. سبز: شربت زمرد و سکنجبین نعناع (Vibrant Royal Emerald Green)
  'bahar-narenj': {
    id: 'bahar-narenj',
    persianName: 'شربت زمرد و سکنجبین خیار',
    shortName: 'سبز زمردی',
    subtitle: 'عصاره نعناع تازه و شربت زمردین ملوکانه',
    gradient: ['#34D399', '#047857'], // Radiant mint to royal emerald green
    char: 'س',
    textureType: 'warm',
    accentColor: '#059669',
  },

  // ۵. سفید: دوغ سفید برفی خالص (Crisp Snow-White Porcelain)
  doogh: {
    id: 'doogh',
    persianName: 'دوغ سفید برفی درباری',
    shortName: 'سفید برفی',
    subtitle: 'سفید خالص و مخملی با عطر گل‌محمدی و نعناع',
    gradient: ['#FFFFFF', '#E2E8F0'], // Crisp pure opaque porcelain white
    char: 'ف',
    textureType: 'foam',
    accentColor: '#64748B',
  },

  // ۶. قرمز: چای یاقوتی قرمز آتشین (Fiery Crimson Ruby Red)
  tea: {
    id: 'tea',
    persianName: 'چای یاقوتی قرمز آتشین',
    shortName: 'قرمز یاقوتی',
    subtitle: 'دم‌کشیده در سماور با رنگ قرمز لعل و یاقوت ناب',
    gradient: ['#FF1E56', '#991B1B'], // Glowing neon ruby red to rich carmine red
    char: 'ق',
    textureType: 'clear',
    accentColor: '#DC2626',
  },
};
