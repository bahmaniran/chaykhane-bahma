const STORAGE_KEY = 'bahman_teahouse_daily_reward_v1';

export interface DailyRewardStatus {
  isClaimedToday: boolean;
  currentStreak: number;
  rewardAmount: number;
  lastClaimDate: string;
}

const STREAK_AMOUNTS = [50, 70, 90, 120, 150, 180, 250];

export function getTodayDateString(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getDailyRewardStatus(): DailyRewardStatus {
  const today = getTodayDateString();

  if (typeof window === 'undefined') {
    return {
      isClaimedToday: false,
      currentStreak: 1,
      rewardAmount: STREAK_AMOUNTS[0],
      lastClaimDate: '',
    };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      const lastDate = data.lastDate || '';
      let streak = Number(data.streak || 1);

      if (lastDate === today) {
        // Already claimed today
        const idx = Math.min(STREAK_AMOUNTS.length - 1, Math.max(0, streak - 1));
        return {
          isClaimedToday: true,
          currentStreak: streak,
          rewardAmount: STREAK_AMOUNTS[idx],
          lastClaimDate: lastDate,
        };
      }

      // Check if yesterday was claimed (consecutive streak)
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = getTodayDateString(yesterday);

      if (lastDate === yesterdayStr) {
        // Progress streak
        streak = streak >= 7 ? 1 : streak + 1;
      } else {
        // Missed a day: reset streak to 1
        streak = 1;
      }

      const idx = Math.min(STREAK_AMOUNTS.length - 1, Math.max(0, streak - 1));
      return {
        isClaimedToday: false,
        currentStreak: streak,
        rewardAmount: STREAK_AMOUNTS[idx],
        lastClaimDate: lastDate,
      };
    }
  } catch {
    // ignore
  }

  return {
    isClaimedToday: false,
    currentStreak: 1,
    rewardAmount: STREAK_AMOUNTS[0],
    lastClaimDate: '',
  };
}

export function claimTodayReward(): {
  success: boolean;
  rewardAmount: number;
  newStreak: number;
} {
  const status = getDailyRewardStatus();
  if (status.isClaimedToday) {
    return {
      success: false,
      rewardAmount: 0,
      newStreak: status.currentStreak,
    };
  }

  const today = getTodayDateString();
  const streak = status.currentStreak;
  const rewardAmount = status.rewardAmount;

  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        lastDate: today,
        streak,
        claimedAt: Date.now(),
      })
    );
  } catch {
    // ignore
  }

  return {
    success: true,
    rewardAmount,
    newStreak: streak,
  };
}
