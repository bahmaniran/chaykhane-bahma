import { Cup, DrinkType } from '../types';
import { solveWaterSort } from './Solver';

const ALL_DRINKS: DrinkType[] = [
  'saffron',
  'tea',
  'khakshir',
  'doogh',
  'bahar-narenj',
  'bidmeshk',
];

export interface LevelConfig {
  levelNumber: number;
  cups: Cup[];
  isRushMode: boolean;
  rushTargets?: DrinkType[];
  rushTimeLimit?: number;
  drinkPool: DrinkType[];
}

export function generateLevel(level: number): LevelConfig {
  const isRushMode = level % 5 === 0;

  // Determine drink count & empty cup count based on level
  let colorCount: number;
  let emptyCount: number;

  if (level === 1) {
    colorCount = 2;
    emptyCount = 1; // Total 3 cups (Super friendly tutorial)
  } else if (level === 2) {
    colorCount = 3;
    emptyCount = 2; // Total 5 cups (2 empty cups gives casual breathing room)
  } else if (level === 3) {
    colorCount = 3;
    emptyCount = 2; // Total 5 cups
  } else if (level <= 6) {
    colorCount = 4;
    emptyCount = 2; // Total 6 cups
  } else if (level <= 10) {
    colorCount = 4;
    emptyCount = 2; // Total 6 cups
  } else if (level <= 14) {
    colorCount = 5;
    emptyCount = 2; // Total 7 cups
  } else {
    colorCount = Math.min(6, 4 + Math.floor((level - 10) / 4));
    emptyCount = 2; // Total 7 or 8 cups
  }

  // Pick drinks for this level
  const shuffledDrinks = [...ALL_DRINKS].sort(() => 0.5 - Math.random());
  const selectedDrinks = shuffledDrinks.slice(0, colorCount);

  // Handcrafted beginner stages for guaranteed smooth on-boarding
  if (level === 1) {
    const c1: DrinkType = selectedDrinks[0] || 'saffron';
    const c2: DrinkType = selectedDrinks[1] || 'tea';
    return {
      levelNumber: 1,
      cups: [
        { id: 0, layers: [c1, c1, c2, c2] },
        { id: 1, layers: [c2, c2, c1, c1] },
        { id: 2, layers: [] },
      ],
      isRushMode: false,
      drinkPool: [c1, c2],
    };
  }

  // Solvable reverse shuffle algorithm with graduated move counts
  let attempts = 0;
  let finalCups: Cup[] = [];

  // Smooth difficulty curve: beginner levels use fewer reverse steps so solutions are clean & fun
  const numReverseMoves =
    level === 2
      ? 6
      : level === 3
      ? 9
      : level <= 5
      ? 13
      : level <= 8
      ? 18
      : level <= 12
      ? 24
      : Math.min(40, 20 + Math.floor(level * 1.5));

  while (attempts < 12) {
    attempts++;
    // Start with solved state
    const cups: Cup[] = [];
    for (let i = 0; i < colorCount; i++) {
      cups.push({
        id: i,
        layers: [selectedDrinks[i], selectedDrinks[i], selectedDrinks[i], selectedDrinks[i]],
      });
    }
    for (let i = 0; i < emptyCount; i++) {
      cups.push({
        id: colorCount + i,
        layers: [],
      });
    }

    // Perform random valid reverse moves
    for (let step = 0; step < numReverseMoves; step++) {
      const nonEmptyCupIndices = cups
        .map((c, idx) => (c.layers.length > 0 ? idx : -1))
        .filter((idx) => idx !== -1);

      if (nonEmptyCupIndices.length === 0) break;

      const fromIdx = nonEmptyCupIndices[Math.floor(Math.random() * nonEmptyCupIndices.length)];
      const nonFullCupIndices = cups
        .map((c, idx) => (idx !== fromIdx && c.layers.length < 4 ? idx : -1))
        .filter((idx) => idx !== -1);

      if (nonFullCupIndices.length === 0) continue;

      const toIdx = nonFullCupIndices[Math.floor(Math.random() * nonFullCupIndices.length)];

      const item = cups[fromIdx].layers.pop();
      if (item) {
        cups[toIdx].layers.push(item);
      }
    }

    // Verify it's not already solved and has at least one valid path
    const isAlreadySolved = cups.every(
      (c) => c.layers.length === 0 || (c.layers.length === 4 && c.layers.every((l) => l === c.layers[0]))
    );

    if (!isAlreadySolved) {
      const solution = solveWaterSort(cups, 2000);
      if (solution && solution.length > 0) {
        finalCups = cups;
        break;
      }
    }
  }

  // Fallback handcrafted initial distribution if random search exhausted
  if (finalCups.length === 0) {
    const c1 = selectedDrinks[0] || 'saffron';
    const c2 = selectedDrinks[1] || 'tea';
    const c3 = selectedDrinks[2] || 'khakshir';
    finalCups = [
      { id: 0, layers: [c1, c2, c1, c2] },
      { id: 1, layers: [c2, c1, c2, c1] },
      { id: 2, layers: [c3, c3, c1, c2] },
      { id: 3, layers: [] },
      { id: 4, layers: [] },
    ];
  }

  // Progressive Obstacles: Harmonious & Casual-friendly (Never overwhelm the player!)
  // 1. Sugar Cube Blocker (rare gentle challenge only after level 16)
  if (level >= 16 && level % 8 === 0) {
    const candidate = finalCups.find((c) => c.layers.length >= 3);
    if (candidate) candidate.hasSugarCubeBlocker = true;
  }

  // 2. Steamy Mystery Glass (Introduced gently at Level 7, never in Rush Mode!)
  if (level >= 7 && !isRushMode) {
    const candidate = finalCups.find((c) => c.layers.length >= 3 && !c.hasSugarCubeBlocker);
    if (candidate) candidate.isSteamy = true;
  }

  // 3. Cooling Tea Timer (Introduced gently at Level 9, with generous 12-move buffer)
  if (level >= 9 && !isRushMode) {
    const candidate = finalCups.find(
      (c) => c.layers.length >= 2 && !c.hasSugarCubeBlocker && !c.isSteamy
    );
    if (candidate) candidate.coolingMovesLeft = Math.max(10, 14 - Math.floor(level / 8));
  }

  let rushTargets: DrinkType[] | undefined;
  if (isRushMode) {
    // Pick 2 target drinks from selected drinks
    rushTargets = selectedDrinks.slice(0, 2);
  }

  return {
    levelNumber: level,
    cups: finalCups,
    isRushMode,
    rushTargets,
    rushTimeLimit: isRushMode ? 60 : undefined,
    drinkPool: selectedDrinks,
  };
}
