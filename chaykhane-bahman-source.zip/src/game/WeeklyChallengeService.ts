import { Cup, DrinkType, WeeklyChallengeStage, WeeklyChallengeState, WeeklyLeaderboardCompetitor } from '../types';
import { solveWaterSort } from './Solver';

const STORAGE_KEY = 'bahman_teahouse_weekly_v2';

/**
 * Calculates the Monday of the current week (starting at 00:00:00.000)
 */
export function getMondayOfCurrentWeek(date: Date = new Date()): Date {
  const d = new Date(date);
  const day = d.getDay(); // 0: Sunday, 1: Monday, 2: Tuesday, ...
  // Calculate days back to Monday
  const diff = d.getDate() - (day === 0 ? 6 : day - 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

/**
 * Calculates the next Monday (reset moment)
 */
export function getNextMonday(date: Date = new Date()): Date {
  const monday = getMondayOfCurrentWeek(date);
  const next = new Date(monday.getTime() + 7 * 24 * 60 * 60 * 1000);
  next.setHours(0, 0, 0, 0);
  return next;
}

/**
 * Generates a unique key for the current Monday (e.g. "monday-2026-10-12")
 */
export function getWeekKey(date: Date = new Date()): string {
  const m = getMondayOfCurrentWeek(date);
  const year = m.getFullYear();
  const month = String(m.getMonth() + 1).padStart(2, '0');
  const day = String(m.getDate()).padStart(2, '0');
  return `monday-${year}-${month}-${day}`;
}

/**
 * Returns week index of the year (1-52)
 */
export function getWeekNumber(date: Date = new Date()): number {
  const m = getMondayOfCurrentWeek(date);
  const startOfYear = new Date(m.getFullYear(), 0, 1);
  const pastDaysOfYear = (m.getTime() - startOfYear.getTime()) / 86400000;
  return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);
}

/**
 * Computes remaining time until the upcoming Monday reset
 */
export function getTimeRemainingUntilMonday(now: Date = new Date()): {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalMs: number;
  isMondayToday: boolean;
} {
  const nextMonday = getNextMonday(now);
  const totalMs = Math.max(0, nextMonday.getTime() - now.getTime());

  const seconds = Math.floor((totalMs / 1000) % 60);
  const minutes = Math.floor((totalMs / 1000 / 60) % 60);
  const hours = Math.floor((totalMs / (1000 * 60 * 60)) % 24);
  const days = Math.floor(totalMs / (1000 * 60 * 60 * 24));
  const isMondayToday = now.getDay() === 1;

  return { days, hours, minutes, seconds, totalMs, isMondayToday };
}

// 6 Rotating cultural teahouse weekly themes
const WEEKLY_THEMES = [
  {
    themeTitle: 'جشنواره شربت زعفران و گلاب قاجاری',
    themeStory: 'اول هفته است و بساط زعفران سرگل قائنات در چایخانه به پاست. کاسبان بازار کهنه منتظر عطر زعفران ناب و شربت خنک تو هستند!',
  },
  {
    themeTitle: 'سرای شربت‌خانه‌های عودلاجان',
    themeStory: 'در کوچه پس‌کوچه‌های عودلاجان، نوای تار به راه است و اهل هنر برای چای دارچینی و بهارنارنج دیشلمه صف بسته‌اند.',
  },
  {
    themeTitle: 'جام خاکشیر و بیدمشک سنگلج',
    themeStory: 'پهلوانان زورخانه سنگلج بعد از میل گرفتن راهی چایخانه شده‌اند؛ شربت خاکشیر دوفاز و بیدمشک اعلا هدیه به بازوان ستبرشان است.',
  },
  {
    themeTitle: 'معجون هفت‌رنگ بازار بزرگ ری',
    themeStory: 'کاروان تاجران ری از راه رسیده و استکان‌های میناکاری را پیشکش آورده‌اند تا طعم چای لیمو و شربت‌های ویژه دوشنبه را بچشند.',
  },
  {
    themeTitle: 'سماور زرین پهلوانان پایتخت',
    themeStory: 'سماور زغالی بزرگ عمو بهمن قل‌قل می‌کند؛ این هفته هر که چالش را یکسره کند، نشان زرین پهلوان هفته را بر سینه خواهد زد.',
  },
  {
    themeTitle: 'نسیم بهارنارنج و نعناع شیراز',
    themeStory: 'بوی خوش بهارنارنج در هوای چایخانه پیچیده. این دوشنبه دست‌های زرنگ و حواس جمع می‌خواهد تا رنگ‌ها در بلور استکان بنشینند.',
  },
];

/**
 * Builds guaranteed solvable cups for a weekly challenge stage using deterministic reverse shuffle
 */
function createSolvableWeeklyStageCups(
  colorCount: number,
  emptyCount: number,
  selectedDrinks: DrinkType[],
  seedNumber: number
): Cup[] {
  // Start with solved state
  const cups: Cup[] = [];
  for (let i = 0; i < colorCount; i++) {
    cups.push({
      id: i,
      layers: [selectedDrinks[i], selectedDrinks[i], selectedDrinks[i], selectedDrinks[i]],
    });
  }
  for (let i = 0; i < emptyCount; i++) {
    cups.push({
      id: colorCount + i,
      layers: [],
    });
  }

  // Deterministic pseudo-random number generator
  let state = Math.abs(seedNumber * 9301 + 49297) % 233280;
  const rnd = () => {
    state = (state * 9301 + 49297) % 233280;
    return state / 233280;
  };

  // Perform reverse moves
  const moves = 16 + colorCount * 4;
  for (let s = 0; s < moves; s++) {
    const nonEmpty = cups.map((c, i) => (c.layers.length > 0 ? i : -1)).filter((i) => i !== -1);
    if (nonEmpty.length === 0) break;
    const fromIdx = nonEmpty[Math.floor(rnd() * nonEmpty.length)];

    const nonFull = cups.map((c, i) => (i !== fromIdx && c.layers.length < 4 ? i : -1)).filter((i) => i !== -1);
    if (nonFull.length === 0) continue;
    const toIdx = nonFull[Math.floor(rnd() * nonFull.length)];

    const item = cups[fromIdx].layers.pop();
    if (item) {
      cups[toIdx].layers.push(item);
    }
  }

  // Test with solver
  const solution = solveWaterSort(cups, 2000);
  if (solution && solution.length > 0) {
    return cups;
  }

  // Handcrafted verified fallback setups
  if (colorCount === 3) {
    return [
      { id: 0, layers: [selectedDrinks[0], selectedDrinks[1], selectedDrinks[0], selectedDrinks[2]] },
      { id: 1, layers: [selectedDrinks[1], selectedDrinks[2], selectedDrinks[1], selectedDrinks[0]] },
      { id: 2, layers: [selectedDrinks[2], selectedDrinks[0], selectedDrinks[2], selectedDrinks[1]] },
      { id: 3, layers: [] },
      { id: 4, layers: [] },
    ];
  } else if (colorCount === 4) {
    return [
      { id: 0, layers: [selectedDrinks[0], selectedDrinks[1], selectedDrinks[2], selectedDrinks[3]] },
      { id: 1, layers: [selectedDrinks[1], selectedDrinks[2], selectedDrinks[3], selectedDrinks[0]] },
      { id: 2, layers: [selectedDrinks[2], selectedDrinks[3], selectedDrinks[0], selectedDrinks[1]] },
      { id: 3, layers: [selectedDrinks[3], selectedDrinks[0], selectedDrinks[1], selectedDrinks[2]] },
      { id: 4, layers: [] },
      { id: 5, layers: [] },
    ];
  } else if (colorCount === 5) {
    return [
      { id: 0, layers: [selectedDrinks[0], selectedDrinks[1], selectedDrinks[2], selectedDrinks[3]] },
      { id: 1, layers: [selectedDrinks[1], selectedDrinks[2], selectedDrinks[3], selectedDrinks[4]] },
      { id: 2, layers: [selectedDrinks[2], selectedDrinks[3], selectedDrinks[4], selectedDrinks[0]] },
      { id: 3, layers: [selectedDrinks[3], selectedDrinks[4], selectedDrinks[0], selectedDrinks[1]] },
      { id: 4, layers: [selectedDrinks[4], selectedDrinks[0], selectedDrinks[1], selectedDrinks[2]] },
      { id: 5, layers: [] },
      { id: 6, layers: [] },
    ];
  } else {
    // 6 colors
    return [
      { id: 0, layers: [selectedDrinks[0], selectedDrinks[1], selectedDrinks[2], selectedDrinks[3]] },
      { id: 1, layers: [selectedDrinks[1], selectedDrinks[2], selectedDrinks[3], selectedDrinks[4]] },
      { id: 2, layers: [selectedDrinks[2], selectedDrinks[3], selectedDrinks[4], selectedDrinks[5]] },
      { id: 3, layers: [selectedDrinks[3], selectedDrinks[4], selectedDrinks[5], selectedDrinks[0]] },
      { id: 4, layers: [selectedDrinks[4], selectedDrinks[5], selectedDrinks[0], selectedDrinks[1]] },
      { id: 5, layers: [selectedDrinks[5], selectedDrinks[0], selectedDrinks[1], selectedDrinks[2]] },
      { id: 6, layers: [] },
      { id: 7, layers: [] },
    ];
  }
}

/**
 * Returns the 5 unique stages for the current week based on Monday key
 */
export function getWeeklyStagesForCurrentWeek(date: Date = new Date()): WeeklyChallengeStage[] {
  const weekNum = getWeekNumber(date);
  const themeIdx = weekNum % WEEKLY_THEMES.length;
  const seed = weekNum * 137;

  return [
    {
      id: 1,
      title: 'دست‌گرمی دوشنبه: شربت زعفرانی',
      subtitle: 'مرحله اول چالش هفتگی',
      description: 'شروع پرانرژی اول هفته با چای و شربت زعفران اعلای قائنات. استکان‌ها را سریع مرتب کن!',
      drinkPool: ['saffron', 'doogh', 'tea'],
      initialCups: createSolvableWeeklyStageCups(3, 2, ['saffron', 'doogh', 'tea'], seed + 1),
      rewardCoins: 250,
      rewardWeeklyScore: 60,
      specialItemReward: 'نشان برنزی دوشنبه',
      badgeTitle: 'نشان برنزی دوشنبه',
      badgeIcon: '🥉',
      modifierLabel: 'آغاز هفته با برکت',
    },
    {
      id: 2,
      title: 'عطر بهارنارنج عودلاجان',
      subtitle: 'مرحله دوم چالش هفتگی',
      description: 'چهار رنگ شربت خوش‌طعم در استکان‌های لب‌سوز. تمرکز کن تا هر قطره در جای خود بنشیند.',
      drinkPool: ['saffron', 'bahar-narenj', 'tea', 'khakshir'],
      initialCups: createSolvableWeeklyStageCups(4, 2, ['saffron', 'bahar-narenj', 'tea', 'khakshir'], seed + 2),
      rewardCoins: 400,
      rewardWeeklyScore: 100,
      specialItemReward: 'سکه زرین دوشنبه',
      badgeTitle: 'بلور عودلاجان',
      badgeIcon: '🥈',
      modifierLabel: 'شربت‌های معطر',
    },
    {
      id: 3,
      title: 'معجون دوغ و خاکشیر سنگلج',
      subtitle: 'مرحله سوم چالش هفتگی',
      description: 'سفارش اختصاصی مشتریان وفادار! دانه‌های خاکشیر و خنکای دوغ نعنایی در هم تنیده‌اند.',
      drinkPool: ['doogh', 'khakshir', 'tea', 'bidmeshk'],
      initialCups: createSolvableWeeklyStageCups(4, 2, ['doogh', 'khakshir', 'tea', 'bidmeshk'], seed + 3),
      rewardCoins: 600,
      rewardWeeklyScore: 160,
      specialItemReward: 'قند بلورین هفتگی',
      badgeTitle: 'قند بلورین هفتگی',
      badgeIcon: '🧊',
      modifierLabel: 'خاکشیر طوق‌دار',
    },
    {
      id: 4,
      title: 'چای دیشلمه اعلای اوستا',
      subtitle: 'مرحله چهارم چالش هفتگی',
      description: 'پنج شربت اصیل ایرانی؛ آزمایش هوش و تسلط بر چایخانه! بدون شتاب، دقیق پیش برو.',
      drinkPool: ['tea', 'saffron', 'bahar-narenj', 'khakshir', 'bidmeshk'],
      initialCups: createSolvableWeeklyStageCups(5, 2, ['tea', 'saffron', 'bahar-narenj', 'khakshir', 'bidmeshk'], seed + 4),
      rewardCoins: 900,
      rewardWeeklyScore: 240,
      specialItemReward: 'استکان میناکاری دوشنبه',
      badgeTitle: 'استکان میناکاری دوشنبه',
      badgeIcon: '🏺',
      modifierLabel: 'چالش حرفه‌ای سماور',
    },
    {
      id: 5,
      title: 'آزمون بزرگ پهلوان هفته',
      subtitle: 'مرحله نهایی قهرمانی دوشنبه',
      description: 'شش نوشیدنی نفیس و هشت استکان بلورین شاه‌عباسی! فقط اوستای واقعی چایخانه از پس این مرحله برمی‌آید.',
      drinkPool: ['saffron', 'tea', 'khakshir', 'doogh', 'bahar-narenj', 'bidmeshk'],
      initialCups: createSolvableWeeklyStageCups(6, 2, ['saffron', 'tea', 'khakshir', 'doogh', 'bahar-narenj', 'bidmeshk'], seed + 5),
      rewardCoins: 1600,
      rewardWeeklyScore: 400,
      specialItemReward: '👑 تاج طلایی پهلوان هفته',
      badgeTitle: 'تاج طلایی پهلوان هفته',
      badgeIcon: '👑',
      modifierLabel: 'جام قهرمانی دوشنبه',
    },
  ];
}

/**
 * Retrieves the current weekly state, refreshing automatically if a new Monday has started
 */
export function getWeeklyChallengeState(date: Date = new Date()): WeeklyChallengeState {
  const currentWeekKey = getWeekKey(date);
  const weekNum = getWeekNumber(date);
  const theme = WEEKLY_THEMES[weekNum % WEEKLY_THEMES.length];
  const mondayDate = getMondayOfCurrentWeek(date);
  const nextMonday = getNextMonday(date);

  const defaultState: WeeklyChallengeState = {
    weekKey: currentWeekKey,
    weekNumber: weekNum,
    themeTitle: theme.themeTitle,
    themeStory: theme.themeStory,
    startDate: mondayDate.toISOString().split('T')[0],
    nextMondayDate: nextMonday.toISOString().split('T')[0],
    completedStageIds: [],
    weeklyScore: 0,
    hasClaimedGrandPrize: false,
    unlockedAt: Date.now(),
  };

  if (typeof window === 'undefined') return defaultState;

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed: WeeklyChallengeState = JSON.parse(raw);
      // Check if it belongs to the current Monday week!
      if (parsed.weekKey === currentWeekKey) {
        return parsed;
      }
      // If Monday rolled over, archive previous score if needed and start fresh
      localStorage.setItem(`${STORAGE_KEY}_previous_${parsed.weekKey}`, JSON.stringify(parsed));
    }
  } catch {
    // ignore parse errors
  }

  // Save new Monday state
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultState));
  } catch {
    // ignore
  }

  return defaultState;
}

/**
 * Saves weekly challenge state
 */
export function saveWeeklyChallengeState(state: WeeklyChallengeState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

/**
 * Marks a stage as completed, updates score, returns rewards
 */
export function completeWeeklyStage(stageId: number): {
  success: boolean;
  rewardCoins: number;
  rewardWeeklyScore: number;
  isAllCompleted: boolean;
  alreadyCompleted: boolean;
  stage: WeeklyChallengeStage | undefined;
} {
  const state = getWeeklyChallengeState();
  const stages = getWeeklyStagesForCurrentWeek();
  const stage = stages.find((s) => s.id === stageId);

  if (!stage) {
    return {
      success: false,
      rewardCoins: 0,
      rewardWeeklyScore: 0,
      isAllCompleted: false,
      alreadyCompleted: false,
      stage: undefined,
    };
  }

  const alreadyCompleted = state.completedStageIds.includes(stageId);
  const coins = alreadyCompleted ? Math.floor(stage.rewardCoins * 0.25) : stage.rewardCoins;
  const weeklyScoreBonus = alreadyCompleted ? Math.floor(stage.rewardWeeklyScore * 0.25) : stage.rewardWeeklyScore;

  if (!alreadyCompleted) {
    state.completedStageIds = [...state.completedStageIds, stageId].sort((a, b) => a - b);
  }
  state.weeklyScore += weeklyScoreBonus;

  const isAllCompleted = state.completedStageIds.length === 5;
  saveWeeklyChallengeState(state);

  return {
    success: true,
    rewardCoins: coins,
    rewardWeeklyScore: weeklyScoreBonus,
    isAllCompleted,
    alreadyCompleted,
    stage,
  };
}

/**
 * Claims the Grand Monday Chest (when all 5 stages are beaten)
 */
export function claimWeeklyGrandChest(): {
  success: boolean;
  bonusCoins: number;
  bonusWeeklyScore: number;
  message: string;
} {
  const state = getWeeklyChallengeState();
  if (state.completedStageIds.length < 5) {
    return {
      success: false,
      bonusCoins: 0,
      bonusWeeklyScore: 0,
      message: 'هنوز همه ۵ مرحله چالش هفتگی حل نشده است!',
    };
  }

  if (state.hasClaimedGrandPrize) {
    return {
      success: false,
      bonusCoins: 0,
      bonusWeeklyScore: 0,
      message: 'جایزه بزرگ صندوقچه قبلاً دریافت شده است.',
    };
  }

  state.hasClaimedGrandPrize = true;
  state.weeklyScore += 500;
  saveWeeklyChallengeState(state);

  return {
    success: true,
    bonusCoins: 1200,
    bonusWeeklyScore: 500,
    message: 'صندوقچه زرین دوشنبه باز شد! ۱۲۰۰ سکه و ۵۰۰ امتیاز هفتگی به پاداش شما افزوده شد.',
  };
}

// Preset active competitors for Weekly Leaderboard
const BASE_WEEKLY_COMPETITORS: Omit<WeeklyLeaderboardCompetitor, 'rank'>[] = [
  {
    id: 'w_1',
    name: 'حاج اسدالله صراف',
    neighborhood: 'محله بازار کهنه',
    score: 1420,
    stagesCompleted: 5,
    badge: '👑 اوستای هفته',
    avatarSeed: 1,
  },
  {
    id: 'w_2',
    name: 'پهلوان حبیب زنگ‌بزن',
    neighborhood: 'محله سنگلج',
    score: 1350,
    stagesCompleted: 5,
    badge: '🥈 سماور نقره',
    avatarSeed: 2,
  },
  {
    id: 'w_3',
    name: 'میرزا محمود کاتب',
    neighborhood: 'محله عودلاجان',
    score: 1180,
    stagesCompleted: 5,
    badge: '🥉 بلور مفرغی',
    avatarSeed: 3,
  },
  {
    id: 'w_4',
    name: 'بانو فخرالتاج دربندی',
    neighborhood: 'محله تجریش و دربند',
    score: 960,
    stagesCompleted: 4,
    badge: 'نشان استکان طلا',
    avatarSeed: 7,
  },
  {
    id: 'w_5',
    name: 'اوستا عزت مسگر',
    neighborhood: 'محله بازار کهنه',
    score: 820,
    stagesCompleted: 4,
    badge: 'استاد چایخانه',
    avatarSeed: 5,
  },
  {
    id: 'w_6',
    name: 'مشتی رضا درشکه‌چی',
    neighborhood: 'محله سنگلج',
    score: 680,
    stagesCompleted: 3,
    badge: 'پیشکسوت محله',
    avatarSeed: 6,
  },
  {
    id: 'w_7',
    name: 'کربلایی یوسف بلورفروش',
    neighborhood: 'محله عودلاجان',
    score: 540,
    stagesCompleted: 3,
    badge: 'چایچی باصفا',
    avatarSeed: 8,
  },
  {
    id: 'w_8',
    name: 'آقا ناصر عطار',
    neighborhood: 'محله بازار کهنه',
    score: 420,
    stagesCompleted: 2,
    badge: 'عضو پرتلاش',
    avatarSeed: 9,
  },
  {
    id: 'w_9',
    name: 'داش منصور پهلوون',
    neighborhood: 'محله سنگلج',
    score: 310,
    stagesCompleted: 2,
    badge: 'همسایه باصفا',
    avatarSeed: 10,
  },
  {
    id: 'w_10',
    name: 'شاطر تقی نانوا',
    neighborhood: 'محله تجریش و دربند',
    score: 220,
    stagesCompleted: 1,
    badge: 'عضو نوپا',
    avatarSeed: 11,
  },
];

/**
 * Generates the live weekly leaderboard including the player's personal standing
 */
export function getWeeklyLeaderboard(
  playerName: string = 'اوستای چایخانه (شما)',
  playerWeeklyScore?: number,
  playerStagesCompleted?: number
): {
  leaderboard: WeeklyLeaderboardCompetitor[];
  playerRank: number;
  playerEntry: WeeklyLeaderboardCompetitor;
} {
  const state = getWeeklyChallengeState();
  const effectiveScore = playerWeeklyScore !== undefined ? playerWeeklyScore : state.weeklyScore;
  const stagesDone = playerStagesCompleted !== undefined ? playerStagesCompleted : state.completedStageIds.length;

  const playerEntry: WeeklyLeaderboardCompetitor = {
    id: 'user_weekly_player',
    name: `${playerName.replace(' (شما)', '')} (شما)`,
    neighborhood: 'محله بازار کهنه',
    score: effectiveScore,
    stagesCompleted: stagesDone,
    rank: 1,
    badge:
      stagesDone === 5
        ? '👑 قهرمان چالش دوشنبه'
        : stagesDone >= 3
        ? '✨ اوستای ممتاز هفتگی'
        : stagesDone >= 1
        ? 'چایچی تازه‌نفس'
        : 'در حال رقابت',
    avatarSeed: 4,
    isCurrentPlayer: true,
  };

  const all = [...BASE_WEEKLY_COMPETITORS, playerEntry].sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return b.stagesCompleted - a.stagesCompleted;
  });

  const ranked: WeeklyLeaderboardCompetitor[] = all.map((c, idx) => ({
    ...c,
    rank: idx + 1,
  }));

  const playerFinal = ranked.find((c) => c.isCurrentPlayer) || playerEntry;

  return {
    leaderboard: ranked,
    playerRank: playerFinal.rank,
    playerEntry: playerFinal,
  };
}
