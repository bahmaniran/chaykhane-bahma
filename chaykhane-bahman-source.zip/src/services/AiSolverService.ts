/**
 * AiSolverService.ts
 * Manages Uncle Bahman AI Brain, multi-provider prioritized fallback,
 * and strict rate limiting (Maximum 3 AI-assisted level completions per 1 hour per user).
 */

import { Cup } from '../types';
import { solveWaterSort, findImmediateBestMove } from '../game/Solver';
import { toPersianDigits } from '../utils/persianNumbers';

const STORAGE_KEY_AI_QUOTA = 'bahman_ai_hourly_quota_v1';
export const MAX_AI_STAGES_PER_HOUR = 3;
export const QUOTA_WINDOW_MS = 60 * 60 * 1000; // 1 Hour in milliseconds

export interface AiQuotaStatus {
  stagesUsed: number;
  stagesRemaining: number;
  isRestricted: boolean;
  minutesRemaining: number;
  secondsRemaining: number;
  resetTimestamp: number;
}

interface StoredQuota {
  windowStart: number;
  stagesCompleted: number;
  completedLevelIds: number[];
}

/**
 * Prioritized Multi-Provider AI Keys Configuration
 * Priority 1: Google Gemini (Multiple active keys with instant failover)
 * Priority 2: OpenRouter
 * Priority 3: Routeway
 * Priority 4: Inception Labs
 * Priority 5: OrcaRouter
 * Priority 6: SambaNova
 * Priority 7: xAI Grok
 * Priority 8: Together AI
 */
export const AI_PROVIDERS = {
  gemini: {
    name: 'Google Gemini Flash',
    keys: [
      'AQ.Ab8RN6KcKZfk0Y0YoA17YDpsJQiDnnXBh3NG9GWp9uBH_LNWUQ',
      'AQ.Ab8RN6KOV3ieVyOO8Zfz-NerO5W93ge8vCTA48KEe_T0zM6mRQ',
      'AQ.Ab8RN6JMcno4i_9KXsduUDpeerSzaq_EXHRYyvb-3hUzAYRY3A',
      'AQ.Ab8RN6KON9CJ3xLKAOOO6tXS3NbGjMvHtt6mHtAVvoos6G-U3g',
      'AQ.Ab8RN6KRADJ1weIJCWBSyK9gTJYsYFZ3dpVisIAhZVwCbqTdvA',
      'AQ.Ab8RN6Lv8BRN5NY03VqtjpeAREP3R_D4tONVmjP_DK65pnGoWg',
    ],
  },
  openrouter: {
    name: 'OpenRouter AI',
    endpoint: 'https://openrouter.ai/api/v1/chat/completions',
    key: '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',
    model: 'google/gemini-2.5-flash',
  },
  routeway: {
    name: 'Routeway AI',
    endpoint: 'https://api.routeway.ai/v1/chat/completions',
    key: 'sk-dhESsxZCcuEAsE1WB4C-T0aEkDLt-b295zn-Dxy56t106TdqFvFKtBI',
    model: 'minimax-m2.7:free',
  },
  inception: {
    name: 'Inception Labs',
    endpoint: 'https://api.inceptionlabs.ai/v1/chat/completions',
    keys: [
      'sk_c9207aaa6b382373ff2184647034c260',
      'sk_be955a19fc40f5a8ca43b593edb9d6af',
    ],
    model: 'mercury-2.5',
  },
  orcarouter: {
    name: 'OrcaRouter AI',
    endpoint: 'https://api.orcarouter.ai/v1/chat/completions',
    key: 'sk-orca-SUdhKEzKbtfFPYLxJKto31N89XrWLlBtIwfrm9u229S',
    model: 'orcarouter/auto',
  },
  sambanova: {
    name: 'SambaNova AI',
    endpoint: 'https://api.sambanova.ai/v1/chat/completions',
    key: '429e7e30-283a-4613-8983-5e7181a9b38d',
    model: 'DeepSeek-V3.1',
  },
  grok: {
    name: 'xAI Grok',
    endpoint: 'https://api.x.ai/v1/chat/completions',
    key: 'xai-fNq0qg87XHH6zJpnzdbbVVD1A353Y5QdqHhHZCHZb29rEC5QaYHr8QZD8rdtRyHwW5N10wfgztnjehWZ',
    model: 'grok-4.7',
  },
  together: {
    name: 'Together AI',
    endpoint: 'https://api.together.ai/v1/chat/completions',
    key: 'key_Cfpy2th7QkxJdzen8KyDG',
    model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo',
  },
};

/**
 * Retrieve current user's AI quota status for the current 1-hour sliding window.
 */
export function getAiQuotaStatus(): AiQuotaStatus {
  const now = Date.now();
  let quota: StoredQuota = {
    windowStart: now,
    stagesCompleted: 0,
    completedLevelIds: [],
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEY_AI_QUOTA);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.windowStart === 'number') {
        quota = parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to parse AI quota from storage:', err);
  }

  // Check if 1 hour has elapsed since window start
  const elapsed = now - quota.windowStart;
  if (elapsed >= QUOTA_WINDOW_MS) {
    // Window expired, reset window and count
    quota.windowStart = now;
    quota.stagesCompleted = 0;
    quota.completedLevelIds = [];
    saveQuota(quota);
  }

  const stagesUsed = Math.min(MAX_AI_STAGES_PER_HOUR, quota.stagesCompleted);
  const stagesRemaining = Math.max(0, MAX_AI_STAGES_PER_HOUR - stagesUsed);
  const isRestricted = stagesRemaining <= 0;

  const msRemainingInWindow = Math.max(0, QUOTA_WINDOW_MS - (now - quota.windowStart));
  const totalSeconds = Math.ceil(msRemainingInWindow / 1000);
  const minutesRemaining = Math.floor(totalSeconds / 60);
  const secondsRemaining = totalSeconds % 60;
  const resetTimestamp = quota.windowStart + QUOTA_WINDOW_MS;

  return {
    stagesUsed,
    stagesRemaining,
    isRestricted,
    minutesRemaining,
    secondsRemaining,
    resetTimestamp,
  };
}

/**
 * Record an AI-assisted level advance
 */
export function recordAiStageCompleted(levelNumber: number): AiQuotaStatus {
  const status = getAiQuotaStatus();
  if (status.isRestricted) {
    return status;
  }

  const now = Date.now();
  let quota: StoredQuota = {
    windowStart: now,
    stagesCompleted: 0,
    completedLevelIds: [],
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEY_AI_QUOTA);
    if (raw) {
      quota = JSON.parse(raw);
    }
  } catch {}

  // If window has passed, reset start time
  if (now - quota.windowStart >= QUOTA_WINDOW_MS) {
    quota.windowStart = now;
    quota.stagesCompleted = 0;
    quota.completedLevelIds = [];
  }

  quota.stagesCompleted += 1;
  if (!quota.completedLevelIds.includes(levelNumber)) {
    quota.completedLevelIds.push(levelNumber);
  }

  saveQuota(quota);
  return getAiQuotaStatus();
}

function saveQuota(quota: StoredQuota) {
  try {
    localStorage.setItem(STORAGE_KEY_AI_QUOTA, JSON.stringify(quota));
  } catch (err) {
    console.warn('Failed to save AI quota to storage:', err);
  }
}

/**
 * Format remaining time nicely in Persian
 */
export function formatAiTimeRemaining(minutes: number, seconds: number): string {
  if (minutes > 0) {
    return `${toPersianDigits(minutes)} دقیقه و ${toPersianDigits(seconds)} ثانیه`;
  }
  return `${toPersianDigits(seconds)} ثانیه`;
}

/**
 * Generate a smart Persian prompt for Uncle Bahman AI Brain
 */
function buildAiPrompt(cups: Cup[], levelNumber: number): string {
  const simplified = cups.map((c, i) => ({
    cupNumber: i + 1,
    layersCount: c.layers.length,
    layers: c.layers,
    isFrozen: c.isFrozenSolid,
  }));

  return `شما «عمو بهمن»، اوستای باصفا و مهربان چایخانه سنتی ایرانی هستید.
بازیکن در مرحله ${levelNumber} بازی مرتب‌سازی چای و نوشیدنی‌های سنتی است.
وضعیت استکان‌های سینی:
${JSON.stringify(simplified, null, 2)}
یک تحلیل بسیار کوتاه، صمیمانه و کوچه‌بازاری تهرانی قدیم (حداکثر ۲ خط) در قالب توصیه پهلوانی ارائه دهید و بگویید کدام رنگ یا استکان را اول خالی کند. لحنت باصفا، معرفتی و شیرین باشد.`;
}

/**
 * Call prioritized AI backends in strict fallback order
 */
export async function askUncleBahmanAi(cups: Cup[], levelNumber: number): Promise<string> {
  const prompt = buildAiPrompt(cups, levelNumber);

  // 1. Priority 1: Google Gemini Flash
  for (const geminiKey of AI_PROVIDERS.gemini.keys) {
    try {
      const resp = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { maxOutputTokens: 120, temperature: 0.7 },
          }),
        }
      );
      if (resp.ok) {
        const data = await resp.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text && text.trim().length > 0) {
          return text.trim();
        }
      }
    } catch {
      // Try next key
    }
  }

  // 2. Priority 2: OpenRouter
  try {
    const resp = await fetch(AI_PROVIDERS.openrouter.endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${AI_PROVIDERS.openrouter.key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: AI_PROVIDERS.openrouter.model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 120,
      }),
    });
    if (resp.ok) {
      const data = await resp.json();
      const content = data.choices?.[0]?.message?.content;
      if (content && content.trim().length > 0) {
        return content.trim();
      }
    }
  } catch {}

  // 3. Priority 3: Routeway
  try {
    const resp = await fetch(AI_PROVIDERS.routeway.endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${AI_PROVIDERS.routeway.key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: AI_PROVIDERS.routeway.model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 120,
      }),
    });
    if (resp.ok) {
      const data = await resp.json();
      const content = data.choices?.[0]?.message?.content;
      if (content && content.trim().length > 0) {
        return content.trim();
      }
    }
  } catch {}

  // 4. Priority 4: Inception Labs
  for (const incKey of AI_PROVIDERS.inception.keys) {
    try {
      const resp = await fetch(AI_PROVIDERS.inception.endpoint, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${incKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: AI_PROVIDERS.inception.model,
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 120,
        }),
      });
      if (resp.ok) {
        const data = await resp.json();
        const content = data.choices?.[0]?.message?.content;
        if (content && content.trim().length > 0) {
          return content.trim();
        }
      }
    } catch {}
  }

  // 5. Priority 5: SambaNova
  try {
    const resp = await fetch(AI_PROVIDERS.sambanova.endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${AI_PROVIDERS.sambanova.key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: AI_PROVIDERS.sambanova.model,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 120,
      }),
    });
    if (resp.ok) {
      const data = await resp.json();
      const content = data.choices?.[0]?.message?.content;
      if (content && content.trim().length > 0) {
        return content.trim();
      }
    }
  } catch {}

  // Local Diegetic Fallback
  return '«اول استکان‌های یکرنگ رو کامل کن تا سینی خلوت شه و دستت برای حرکت‌های بعدی باز بمونه پهلوون!»';
}
