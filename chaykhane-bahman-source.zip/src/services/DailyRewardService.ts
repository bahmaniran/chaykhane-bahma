export interface DailyRewardStatus {
  canClaim: boolean;
  isClaimedToday: boolean;
  streak: number; // 1 to 7
  todayRewardAmount: number;
  lastClaimDate: string | null;
}

const STORAGE_KEY = 'bahman_teahouse_daily_reward_v2';

export const DAILY_STREAK_AMOUNTS = [50, 70, 90, 120, 150, 180, 250];

function getLocalDateString(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function parseDateString(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d);
}

function getDaysDifference(currentDateStr: string, pastDateStr: string): number {
  const current = parseDateString(currentDateStr);
  const past = parseDateString(pastDateStr);
  const diffTime = current.getTime() - past.getTime();
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

interface StoredDailyData {
  lastClaimDate: string | null;
  streak: number;
}

function getStoredData(): StoredDailyData {
  if (typeof window === 'undefined') {
    return { lastClaimDate: null, streak: 1 };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed.streak === 'number') {
        return {
          lastClaimDate: parsed.lastClaimDate || null,
          streak: Math.max(1, Math.min(7, parsed.streak)),
        };
      }
    }
  } catch {}
  return { lastClaimDate: null, streak: 1 };
}

export function getDailyRewardStatus(): DailyRewardStatus {
  const today = getLocalDateString();
  const data = getStoredData();

  if (!data.lastClaimDate) {
    // First time player
    return {
      canClaim: true,
      isClaimedToday: false,
      streak: 1,
      todayRewardAmount: DAILY_STREAK_AMOUNTS[0],
      lastClaimDate: null,
    };
  }

  const diffDays = getDaysDifference(today, data.lastClaimDate);

  if (diffDays <= 0) {
    // Already claimed today
    const safeStreak = Math.max(1, Math.min(7, data.streak));
    return {
      canClaim: false,
      isClaimedToday: true,
      streak: safeStreak,
      todayRewardAmount: DAILY_STREAK_AMOUNTS[safeStreak - 1] || 50,
      lastClaimDate: data.lastClaimDate,
    };
  }

  if (diffDays === 1) {
    // Consecutive day login!
    const nextStreak = (data.streak % 7) + 1;
    return {
      canClaim: true,
      isClaimedToday: false,
      streak: nextStreak,
      todayRewardAmount: DAILY_STREAK_AMOUNTS[nextStreak - 1],
      lastClaimDate: data.lastClaimDate,
    };
  }

  // Missed one or more days, reset streak to day 1
  return {
    canClaim: true,
    isClaimedToday: false,
    streak: 1,
    todayRewardAmount: DAILY_STREAK_AMOUNTS[0],
    lastClaimDate: data.lastClaimDate,
  };
}

export function claimDailyReward(): { success: boolean; rewardAmount: number; newStreak: number } {
  const status = getDailyRewardStatus();
  if (!status.canClaim) {
    return { success: false, rewardAmount: 0, newStreak: status.streak };
  }

  const today = getLocalDateString();
  const newStreak = status.streak;
  const rewardAmount = status.todayRewardAmount;

  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        lastClaimDate: today,
        streak: newStreak,
      })
    );
  } catch {}

  return {
    success: true,
    rewardAmount,
    newStreak,
  };
}
