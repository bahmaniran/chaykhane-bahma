/**
 * HavalehService.ts
 * Peer-to-Peer Coin Sharing & Gifting system for Uncle Bahman's Teahouse.
 * Secure offline/online HMAC-based voucher generation and redemption.
 */

const APP_SECRET = 'Bahman_TeaHouse_Secret_2026_#987!';
const STORAGE_KEYS = {
  REDEEMED_CODES: 'bahman_redeemed_havaleh_codes_v1',
  GENERATED_CODES: 'bahman_generated_havaleh_codes_v1',
  DAILY_GENEROSITY_DATE: 'bahman_daily_generosity_claim_v1',
};

export interface HavalehVoucher {
  code: string;
  amount: number;
  senderId: string;
  createdAt: number;
}

// Deterministic cryptographic checksum generator using FNV-1a with secret salt
function generateChecksum(payload: string): string {
  let hash = 0x811c9dc5;
  const combined = payload + APP_SECRET;
  for (let i = 0; i < combined.length; i++) {
    hash ^= combined.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  const hex = (hash >>> 0).toString(16).toUpperCase().padStart(8, '0');
  return hex.slice(0, 4);
}

export function getRedeemedHavalehCodes(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.REDEEMED_CODES);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

export function getGeneratedHavalehCodes(): HavalehVoucher[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.GENERATED_CODES);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

/**
 * Checks if the player can generate a gift havaleh:
 * Must be at least Level 5 and have coins >= amount + 200
 */
export function canSendHavaleh(
  currentLevel: number,
  currentCoins: number,
  amount: number,
  unlockAll: boolean = false
): { allowed: boolean; reason?: string } {
  if (!unlockAll && currentLevel < 5) {
    return {
      allowed: false,
      reason: 'برای صدور حواله و مهمون کردن رفقا باید حداقل به مرحله ۵ چایخانه برسی پهلوون!',
    };
  }
  if (currentCoins < amount + 200) {
    return {
      allowed: false,
      reason: `برای صدور حواله ${amount} سکه‌ای، باید بعد از کسر حداقل ۲۰۰ سکه ته جیبت بمونه!`,
    };
  }
  return { allowed: true };
}

/**
 * Generates a signed, human-readable voucher code e.g. BAHMAN-100-X7F9-K2M4-9A2B
 */
export function createHavalehVoucher(amount: number, senderId: string): HavalehVoucher {
  const nonce = Math.random().toString(36).substring(2, 6).toUpperCase();
  const shortSender = (senderId || 'GUEST').slice(0, 4).toUpperCase();
  const payloadToSign = `${amount}-${shortSender}-${nonce}`;
  const checksum = generateChecksum(payloadToSign);

  const code = `BAHMAN-${amount}-${shortSender}-${nonce}-${checksum}`;

  const voucher: HavalehVoucher = {
    code,
    amount,
    senderId,
    createdAt: Date.now(),
  };

  const existing = getGeneratedHavalehCodes();
  existing.unshift(voucher);
  try {
    localStorage.setItem(STORAGE_KEYS.GENERATED_CODES, JSON.stringify(existing.slice(0, 20)));
  } catch {}

  return voucher;
}

/**
 * Verifies and redeems a havaleh code with zero-trust cryptographic signature validation
 */
export function redeemHavalehCode(
  rawCode: string,
  mySenderId: string
): { success: boolean; amount?: number; message: string } {
  const code = rawCode.trim().toUpperCase();

  const parts = code.split('-');
  if (parts.length < 4 || parts[0] !== 'BAHMAN') {
    return {
      success: false,
      message: 'کد حواله نامعتبر است! لطفاً قالب صحیح کد را بررسی کن پهلوون.',
    };
  }

  let amount: number;
  let senderTag: string;
  let nonce: string;
  let checksum: string;

  if (parts.length === 5) {
    // Format: BAHMAN-100-SNDR-NONC-CHKS
    amount = parseInt(parts[1], 10);
    senderTag = parts[2];
    nonce = parts[3];
    checksum = parts[4];
  } else if (parts.length === 4) {
    // Format: BAHMAN-100-NONC-CHKS
    amount = parseInt(parts[1], 10);
    senderTag = 'GUEST';
    nonce = parts[2];
    checksum = parts[3];
  } else {
    return {
      success: false,
      message: 'قالب کد حواله نامعتبر است!',
    };
  }

  if (![50, 100, 250].includes(amount)) {
    return {
      success: false,
      message: 'مبلغ حواله در دفاتر عمو بهمن ثبت نشده است!',
    };
  }

  // Prevent self-redemption: verify sender device identity
  const myShortTag = (mySenderId || 'GUEST').slice(0, 4).toUpperCase();
  if (parts.length === 5 && senderTag === myShortTag) {
    return {
      success: false,
      message: 'نمی‌تونی حواله‌ای که خودت صادر کردی رو وصول کنی مشتی! این مرام چایخانه نیست.',
    };
  }

  const generated = getGeneratedHavalehCodes();
  if (generated.some((v) => v.code === code)) {
    return {
      success: false,
      message: 'نمی‌تونی حواله‌ای که خودت صادر کردی رو وصول کنی مشتی! این مرام چایخانه نیست.',
    };
  }

  // Check if already redeemed
  const redeemed = getRedeemedHavalehCodes();
  if (redeemed.includes(code)) {
    return {
      success: false,
      message: 'این برگه حواله قبلاً وصول شده و سکه‌های آن پرداخت گردیده است!',
    };
  }

  // Strict cryptographic checksum verification
  const expectedChecksum = generateChecksum(`${amount}-${senderTag}-${nonce}`);
  if (checksum !== expectedChecksum) {
    // Check fallback with GUEST tag if sender was empty
    const fallbackExpected = generateChecksum(`${amount}-GUEST-${nonce}`);
    if (checksum !== fallbackExpected) {
      return {
        success: false,
        message: 'امضای معتبر عمو بهمن پای این حواله نیست! کد دستکاری شده است.',
      };
    }
  }

  // Mark as redeemed
  redeemed.push(code);
  try {
    localStorage.setItem(STORAGE_KEYS.REDEEMED_CODES, JSON.stringify(redeemed));
  } catch {}

  return {
    success: true,
    amount,
    message: `دمت گرم! حواله ${amount} سکه‌ای با موفقیت وصول شد و به کیسه طلا واریز گردید!`,
  };
}

/**
 * Checks if the user is eligible for the daily generosity reward (Chay-e-Mehmooni):
 * Generosity badge + 1 Free sugar cube booster once per day.
 */
export function checkDailyGenerosityReward(): { canClaim: boolean; claimedToday: boolean } {
  try {
    const lastClaim = localStorage.getItem(STORAGE_KEYS.DAILY_GENEROSITY_DATE);
    const today = new Date().toDateString();
    if (lastClaim === today) {
      return { canClaim: false, claimedToday: true };
    }
    return { canClaim: true, claimedToday: false };
  } catch {
    return { canClaim: true, claimedToday: false };
  }
}

export function claimDailyGenerosityReward(): void {
  try {
    const today = new Date().toDateString();
    localStorage.setItem(STORAGE_KEYS.DAILY_GENEROSITY_DATE, today);
  } catch {}
}
