/**
 * Live Patch & Remote Code Service (OTA)
 * Allows real-time live script/styles/config delivery from the backend host
 * without needing user to download new APK or rebuild the project.
 */
import { getApiBaseUrl } from './backendApi';

export interface RemoteBroadcastMessage {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'reward' | 'urgent' | 'event';
  rewardCoins?: number;
  ctaText?: string;
  ctaUrl?: string;
  date?: string;
}

export interface LiveRemotePatch {
  patch_id: string;
  version_code: number;
  custom_js?: string;
  custom_css?: string;
  announcement?: string;
  broadcast?: RemoteBroadcastMessage | null;
  direct_apk_url?: string;
  latest_version?: string;
  timestamp?: number;
}

const SEEN_BROADCASTS_KEY = 'bahman_seen_broadcasts_v1';
const APPLIED_PATCH_KEY = 'bahman_last_applied_patch_id_v1';

/**
 * Checks and injects live remote code (JS/CSS) and returns any live broadcast notification
 */
export async function fetchAndApplyLivePatch(): Promise<{
  applied: boolean;
  broadcast: RemoteBroadcastMessage | null;
  announcement: string | null;
}> {
  try {
    const baseUrl = getApiBaseUrl();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const res = await fetch(`${baseUrl}/app_patch.php?t=${Date.now()}`, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      return { applied: false, broadcast: null, announcement: null };
    }

    const data: LiveRemotePatch = await res.json();
    if (!data) return { applied: false, broadcast: null, announcement: null };

    // 1. Inject Live Dynamic CSS if present
    if (data.custom_css && data.custom_css.trim()) {
      let styleTag = document.getElementById('live-remote-custom-css') as HTMLStyleElement | null;
      if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'live-remote-custom-css';
        document.head.appendChild(styleTag);
      }
      styleTag.textContent = data.custom_css;
    }

    // 2. Safely Execute Live Dynamic JS if present and new
    if (data.custom_js && data.custom_js.trim()) {
      try {
        const lastPatch = localStorage.getItem(APPLIED_PATCH_KEY);
        if (lastPatch !== data.patch_id) {
          // Execute isolated sandbox function
          const runRemoteCode = new Function('window', 'document', data.custom_js);
          runRemoteCode(window, document);
          if (data.patch_id) {
            localStorage.setItem(APPLIED_PATCH_KEY, data.patch_id);
          }
        }
      } catch (jsErr) {
        console.warn('Live remote JS execution note:', jsErr);
      }
    }

    // 3. Check for live broadcast push notification
    let validBroadcast: RemoteBroadcastMessage | null = null;
    if (data.broadcast && data.broadcast.id) {
      try {
        const seenList: string[] = JSON.parse(localStorage.getItem(SEEN_BROADCASTS_KEY) || '[]');
        if (!seenList.includes(data.broadcast.id)) {
          validBroadcast = data.broadcast;
        }
      } catch {
        validBroadcast = data.broadcast;
      }
    }

    return {
      applied: true,
      broadcast: validBroadcast,
      announcement: data.announcement?.trim() || null,
    };
  } catch {
    return { applied: false, broadcast: null, announcement: null };
  }
}

/**
 * Mark a broadcast notification as seen
 */
export function markBroadcastAsSeen(broadcastId: string): void {
  try {
    const seenList: string[] = JSON.parse(localStorage.getItem(SEEN_BROADCASTS_KEY) || '[]');
    if (!seenList.includes(broadcastId)) {
      seenList.push(broadcastId);
      localStorage.setItem(SEEN_BROADCASTS_KEY, JSON.stringify(seenList));
    }
  } catch {}
}
