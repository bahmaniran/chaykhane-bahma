/**
 * PahlavaniAchievements.ts
 * Manages milestones, awards, and Pahlavani Badges for Uncle Bahman's Teahouse.
 */

import {
  getStoredPlayerProfile,
  saveStoredPlayerProfile,
} from './backendApi';
import { DEFAULT_DECORATIONS } from './TeahouseStore';

export interface PahlavaniBadge {
  id: string;
  title: string;
  honorTitle: string;
  description: string;
  icon: string;
  tier: 'bronze' | 'silver' | 'gold' | 'diamond';
  ringBorder: string;
  gradient: string;
  textColor: string;
  glowShadow: string;
  motto: string;
}

export interface PahlavaniAchievement {
  id: string;
  title: string;
  category: 'levels' | 'tea' | 'decor' | 'sugar' | 'wealth' | 'weekly' | 'social';
  categoryLabel: string;
  description: string;
  targetCount: number;
  unit: string;
  rewardCoins: number;
  badge: PahlavaniBadge;
  getProgress: (stats: PahlavaniStats) => number;
}

export interface PahlavaniStats {
  currentLevel: number;
  totalTeasPoured: number;
  ownedDecorationsCount: number;
  totalDecorationsCount: number;
  coins: number;
  sugarCubesDissolved: number;
  weeklyStagesCompleted: number;
  emojisSentCount: number;
}

const STORAGE_KEYS = {
  CLAIMED_ACHIEVEMENTS: 'bahman_claimed_achievements_v1',
  TOTAL_TEAS_POURED: 'bahman_total_teas_poured_v1',
  SUGAR_CUBES_DISSOLVED: 'bahman_sugar_cubes_dissolved_v1',
  EMOJIS_SENT: 'bahman_emojis_sent_v1',
  ACTIVE_BADGE: 'bahman_active_badge_id_v1',
};

// ============================================================================
// BADGES DEFINITIONS
// ============================================================================
export const PAHLAVANI_BADGES: Record<string, PahlavaniBadge> = {
  badge_centurion: {
    id: 'badge_centurion',
    title: 'مدال طلایی ۱۰۰ مرحله‌ای',
    honorTitle: 'سلطان صد مرحله',
    description: 'نشان زرین اوستای کهنه‌کار با عبور سربلند از ۱۰۰ مرحله چایخانه عمو بهمن.',
    icon: '👑',
    tier: 'diamond',
    ringBorder: 'border-yellow-400',
    gradient: 'from-amber-400 via-yellow-200 to-amber-600',
    textColor: 'text-amber-950',
    glowShadow: 'shadow-[0_0_20px_rgba(251,191,36,0.6)]',
    motto: '«صد بادیه را پشت سر نهادیم و هنوز چای ما تازه دم است»',
  },
  badge_veteran_25: {
    id: 'badge_veteran_25',
    title: 'مدال نقره‌ای کهنه‌کار',
    honorTitle: 'چابک‌دست گود',
    description: 'عبور از ۲۵ مرحله اول و تسلط کامل بر چیدمان انواع شربت و دیشلمه.',
    icon: '🎖️',
    tier: 'silver',
    ringBorder: 'border-slate-300',
    gradient: 'from-slate-200 via-white to-slate-400',
    textColor: 'text-slate-900',
    glowShadow: 'shadow-[0_0_15px_rgba(203,213,225,0.5)]',
    motto: '«قدم اول استواری است، قدم دوم استادی»',
  },
  badge_tea_master: {
    id: 'badge_tea_master',
    title: 'نشان سیمین چای‌ریزی اعلا',
    honorTitle: 'اوستای چای‌ریزی (دست‌طلایی)',
    description: 'تکمیل و ریختن حداقل ۵۰ استکان چای بدون نقص و خوش‌عطر با نعلبکی شاه‌عباسی.',
    icon: '🫖',
    tier: 'gold',
    ringBorder: 'border-emerald-400',
    gradient: 'from-emerald-400 via-teal-200 to-emerald-600',
    textColor: 'text-emerald-950',
    glowShadow: 'shadow-[0_0_18px_rgba(52,211,153,0.5)]',
    motto: '«نه یک قطره بر زمین ریخت، نه رنگ چای از دهن افتاد»',
  },
  badge_full_decor: {
    id: 'badge_full_decor',
    title: 'نشان زرین عتیقه‌بان طهران',
    honorTitle: 'طهران قدیم تمام‌عیار',
    description: 'خریداری و بازسازی کل دکوراسیون چایخانه شامل سماورهای طلاکوب، قالی‌های کاشان و رادیو لامپی.',
    icon: '🏛️',
    tier: 'diamond',
    ringBorder: 'border-amber-300',
    gradient: 'from-amber-300 via-rose-300 to-amber-500',
    textColor: 'text-amber-950',
    glowShadow: 'shadow-[0_0_22px_rgba(245,158,11,0.6)]',
    motto: '«صفای عمارت به صاحب‌دلان است و بوی خوش دارچین»',
  },
  badge_sugar_breaker: {
    id: 'badge_sugar_breaker',
    title: 'نشان بلورین قند پهلو',
    honorTitle: 'قندشکن قهار طهران',
    description: 'حل کردن و از میان برداشتن حداقل ۸ حبه قند سفت از روی دهانه استکان‌ها.',
    icon: '🍬',
    tier: 'bronze',
    ringBorder: 'border-cyan-400',
    gradient: 'from-cyan-300 via-sky-100 to-cyan-500',
    textColor: 'text-cyan-950',
    glowShadow: 'shadow-[0_0_15px_rgba(56,189,248,0.5)]',
    motto: '«شیرینی کار به صبر است و ذوب قند در آب جوش»',
  },
  badge_treasurer: {
    id: 'badge_treasurer',
    title: 'نشان کیسه زر پهلوانی',
    honorTitle: 'خزانه‌دار باصفا',
    description: 'اندوختن بیش از ۲۰۰۰ سکه طلا در دخل و صندوق چایخانه بدون یک شاهی کم و کسر.',
    icon: '💰',
    tier: 'gold',
    ringBorder: 'border-yellow-400',
    gradient: 'from-yellow-400 via-amber-200 to-yellow-600',
    textColor: 'text-yellow-950',
    glowShadow: 'shadow-[0_0_18px_rgba(250,204,21,0.5)]',
    motto: '«برکت دخل از حلال‌خوری است و لبخند مشتری»',
  },
  badge_weekly_hero: {
    id: 'badge_weekly_hero',
    title: 'نشان بازوبند زرین پهلوانی',
    honorTitle: 'پهلوان دوشنبه‌ها',
    description: 'پایان رساندن هر ۵ خوان چالش هفتگی دوشنبه‌ها در مصاف با بزرگان محله.',
    icon: '⚔️',
    tier: 'diamond',
    ringBorder: 'border-red-400',
    gradient: 'from-red-400 via-orange-300 to-amber-500',
    textColor: 'text-red-950',
    glowShadow: 'shadow-[0_0_20px_rgba(239,68,68,0.6)]',
    motto: '«یا علی مدد! میدان برای اهل همت همیشه باز است»',
  },
  badge_generous: {
    id: 'badge_generous',
    title: 'نشان فتوت و مروت',
    honorTitle: 'لوطی مردم‌دار',
    description: 'ارسال گل و احترام به حریفان و رفقای جدول رقبا در پاتوق‌های استانی.',
    icon: '🌸',
    tier: 'silver',
    ringBorder: 'border-pink-300',
    gradient: 'from-pink-300 via-rose-100 to-pink-400',
    textColor: 'text-pink-950',
    glowShadow: 'shadow-[0_0_15px_rgba(244,114,182,0.5)]',
    motto: '«افتادگی آموز اگر طالب فیضی، هرگز نخورد آب زمینی که بلند است»',
  },
};

// ============================================================================
// MILESTONES & ACHIEVEMENTS LIST
// ============================================================================
export const PAHLAVANI_ACHIEVEMENTS: PahlavaniAchievement[] = [
  {
    id: 'achieve_level_100',
    title: 'سلطان صد مرحله',
    category: 'levels',
    categoryLabel: 'مراحل چایخانه',
    description: 'رسیدن به مرحله ۱۰۰ چایخانه عمو بهمن و جاودانه‌شدن در تاریخ طهران.',
    targetCount: 100,
    unit: 'مرحله',
    rewardCoins: 2000,
    badge: PAHLAVANI_BADGES.badge_centurion,
    getProgress: (s) => s.currentLevel,
  },
  {
    id: 'achieve_tea_master',
    title: 'اوستای چای‌ریزی (دست‌طلایی)',
    category: 'tea',
    categoryLabel: 'مهارت چای‌ریزی',
    description: 'دم‌آوری و پرکردن موفق حداقل ۵۰ استکان چای با رنگ و طعم یکدست.',
    targetCount: 50,
    unit: 'استکان',
    rewardCoins: 800,
    badge: PAHLAVANI_BADGES.badge_tea_master,
    getProgress: (s) => s.totalTeasPoured,
  },
  {
    id: 'achieve_full_decor',
    title: 'طهران قدیم تمام‌عیار',
    category: 'decor',
    categoryLabel: 'دکوراسیون و عتیقه',
    description: 'خرید و تجهیز کامل تمام ۸ قلم وسایل سنتی و عتیقه چایخانه.',
    targetCount: DEFAULT_DECORATIONS.length, // 8 items
    unit: 'وسیله',
    rewardCoins: 1500,
    badge: PAHLAVANI_BADGES.badge_full_decor,
    getProgress: (s) => s.ownedDecorationsCount,
  },
  {
    id: 'achieve_level_25',
    title: 'چابک‌دست گود',
    category: 'levels',
    categoryLabel: 'مراحل چایخانه',
    description: 'رسیدن به مرحله ۲۵ چایخانه و اثبات زرنگی در مقابل مشتریان عجول.',
    targetCount: 25,
    unit: 'مرحله',
    rewardCoins: 400,
    badge: PAHLAVANI_BADGES.badge_veteran_25,
    getProgress: (s) => s.currentLevel,
  },
  {
    id: 'achieve_sugar_breaker',
    title: 'قندشکن قهار طهران',
    category: 'sugar',
    categoryLabel: 'موانع و قند',
    description: 'حل کردن حداقل ۸ حبه قند سفت از روی دهانه استکان‌ها با ضربه دقیق.',
    targetCount: 8,
    unit: 'حبه قند',
    rewardCoins: 500,
    badge: PAHLAVANI_BADGES.badge_sugar_breaker,
    getProgress: (s) => s.sugarCubesDissolved,
  },
  {
    id: 'achieve_treasurer',
    title: 'خزانه‌دار باصفا',
    category: 'wealth',
    categoryLabel: 'سرمایه و دخل',
    description: 'اندوختن حداقل ۲۰۰۰ سکه طلا در دخل چایخانه عمو بهمن.',
    targetCount: 2000,
    unit: 'سکه',
    rewardCoins: 600,
    badge: PAHLAVANI_BADGES.badge_treasurer,
    getProgress: (s) => s.coins,
  },
  {
    id: 'achieve_weekly_hero',
    title: 'پهلوان دوشنبه‌ها',
    category: 'weekly',
    categoryLabel: 'لیگ هفتگی',
    description: 'تکمیل تمامی ۵ مرحله پرچالش لیگ هفتگی دوشنبه‌ها.',
    targetCount: 5,
    unit: 'مرحله لیگ',
    rewardCoins: 1000,
    badge: PAHLAVANI_BADGES.badge_weekly_hero,
    getProgress: (s) => s.weeklyStagesCompleted,
  },
  {
    id: 'achieve_generous',
    title: 'لوطی مردم‌دار',
    category: 'social',
    categoryLabel: 'مرام و رفاقت',
    description: 'ارسال حداقل ۵ واکنش ایموجی (گل، چای، دست) برای رقبای جدول استانی.',
    targetCount: 5,
    unit: 'واکنش',
    rewardCoins: 350,
    badge: PAHLAVANI_BADGES.badge_generous,
    getProgress: (s) => s.emojisSentCount,
  },
];

// ============================================================================
// STATS & PROGRESS HELPERS
// ============================================================================

export function getClaimedAchievementIds(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CLAIMED_ACHIEVEMENTS);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return arr;
    }
  } catch {}
  return [];
}

export function saveClaimedAchievementIds(ids: string[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CLAIMED_ACHIEVEMENTS, JSON.stringify(ids));
  } catch {}
}

export function getTotalTeasPouredCount(currentLevelFallback: number = 1): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TOTAL_TEAS_POURED);
    if (raw) {
      const val = parseInt(raw, 10);
      if (!isNaN(val) && val >= 0) return val;
    }
  } catch {}
  // Sensible default based on currentLevel so players with progress don't start at 0
  const estimated = Math.max(0, (currentLevelFallback - 1) * 4);
  saveTotalTeasPouredCount(estimated);
  return estimated;
}

export function saveTotalTeasPouredCount(count: number): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TOTAL_TEAS_POURED, String(count));
  } catch {}
}

export function incrementTeasPouredCount(amount: number = 1): number {
  const current = getTotalTeasPouredCount();
  const next = current + amount;
  saveTotalTeasPouredCount(next);
  return next;
}

export function getSugarCubesDissolvedCount(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SUGAR_CUBES_DISSOLVED);
    if (raw) {
      const val = parseInt(raw, 10);
      if (!isNaN(val) && val >= 0) return val;
    }
  } catch {}
  return 0;
}

export function incrementSugarCubesDissolvedCount(amount: number = 1): number {
  const current = getSugarCubesDissolvedCount();
  const next = current + amount;
  try {
    localStorage.setItem(STORAGE_KEYS.SUGAR_CUBES_DISSOLVED, String(next));
  } catch {}
  return next;
}

export function getEmojisSentCount(): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EMOJIS_SENT);
    if (raw) {
      const val = parseInt(raw, 10);
      if (!isNaN(val) && val >= 0) return val;
    }
  } catch {}
  return 0;
}

export function incrementEmojisSentCount(amount: number = 1): number {
  const current = getEmojisSentCount();
  const next = current + amount;
  try {
    localStorage.setItem(STORAGE_KEYS.EMOJIS_SENT, String(next));
  } catch {}
  return next;
}

/**
 * Computes full stats snapshot for evaluation
 */
export function buildPahlavaniStats(params: {
  currentLevel: number;
  coins: number;
  ownedDecorations: string[];
  weeklyCompletedStages: number;
}): PahlavaniStats {
  return {
    currentLevel: params.currentLevel,
    totalTeasPoured: getTotalTeasPouredCount(params.currentLevel),
    ownedDecorationsCount: params.ownedDecorations.length,
    totalDecorationsCount: DEFAULT_DECORATIONS.length,
    coins: params.coins,
    sugarCubesDissolved: getSugarCubesDissolvedCount(),
    weeklyStagesCompleted: params.weeklyCompletedStages,
    emojisSentCount: getEmojisSentCount(),
  };
}

/**
 * Checks if achievement is unlocked based on stats
 */
export function isAchievementUnlocked(
  achievement: PahlavaniAchievement,
  stats: PahlavaniStats
): boolean {
  return achievement.getProgress(stats) >= achievement.targetCount;
}

/**
 * Counts how many achievements are completed but not yet claimed
 */
export function getClaimableAchievementsCount(stats: PahlavaniStats): number {
  const claimed = getClaimedAchievementIds();
  return PAHLAVANI_ACHIEVEMENTS.filter(
    (a) => isAchievementUnlocked(a, stats) && !claimed.includes(a.id)
  ).length;
}

/**
 * Claims an achievement, awards coins, unlocks badge, and updates player profile
 */
export function claimAchievement(achievementId: string): {
  success: boolean;
  rewardCoins: number;
  badge: PahlavaniBadge | null;
  message: string;
} {
  const achievement = PAHLAVANI_ACHIEVEMENTS.find((a) => a.id === achievementId);
  if (!achievement) {
    return { success: false, rewardCoins: 0, badge: null, message: 'دستاورد یافت نشد.' };
  }

  const claimed = getClaimedAchievementIds();
  if (claimed.includes(achievementId)) {
    return { success: false, rewardCoins: 0, badge: achievement.badge, message: 'این دستاورد قبلاً دریافت شده است.' };
  }

  // Record claimed
  const nextClaimed = [...claimed, achievementId];
  saveClaimedAchievementIds(nextClaimed);

  // Update profile with unlocked badge
  const profile = getStoredPlayerProfile();
  const currentUnlockedBadges = Array.isArray(profile.unlockedBadgeIds)
    ? [...profile.unlockedBadgeIds]
    : [];

  if (!currentUnlockedBadges.includes(achievement.badge.id)) {
    currentUnlockedBadges.push(achievement.badge.id);
  }

  // If user has no active badge or wants default, set to this one
  const nextActiveBadgeId = profile.activeBadgeId || achievement.badge.id;

  const updatedProfile = {
    ...profile,
    unlockedBadgeIds: currentUnlockedBadges,
    activeBadgeId: nextActiveBadgeId,
  };
  saveStoredPlayerProfile(updatedProfile);

  return {
    success: true,
    rewardCoins: achievement.rewardCoins,
    badge: achievement.badge,
    message: `دستخوش پهلوون! «${achievement.badge.title}» به مدال‌های پروفایل شما اضافه شد و +${achievement.rewardCoins} سکه دریافت کردی!`,
  };
}

/**
 * Equips a badge as the player's active badge displayed on profile and card
 */
export function equipPlayerBadge(badgeId: string): { success: boolean; badge?: PahlavaniBadge } {
  const badge = PAHLAVANI_BADGES[badgeId];
  if (!badge) return { success: false };

  const profile = getStoredPlayerProfile();
  const updated = {
    ...profile,
    activeBadgeId: badgeId,
  };
  saveStoredPlayerProfile(updated);

  return { success: true, badge };
}

/**
 * Returns badge by id
 */
export function getBadgeById(badgeId?: string): PahlavaniBadge | undefined {
  if (!badgeId) return undefined;
  return PAHLAVANI_BADGES[badgeId];
}
