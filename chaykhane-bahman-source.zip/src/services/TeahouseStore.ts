/**
 * TeahouseStore.ts - Central persistent state manager for Uncle Bahman's Teahouse
 * Manages: Daftar-e-Hesab, Shab-haye Naghali, Renovations & Daily Tip, VIP Bosses, Dice Roll, and Referral Card
 */

import {
  DaftarHesabState,
  NaghaliState,
  TeahouseDecoration,
  VIPBossCustomer,
  DiceRollResult,
  RadioTrackId,
} from '../types';

const STORAGE_KEYS = {
  DAFTAR_HESAB: 'bahman_daftar_hesab_v1',
  NAGHALI: 'bahman_naghali_v1',
  DECORATIONS: 'bahman_decorations_v1',
  DAILY_TIP: 'bahman_daily_tip_claim_v1',
  DICE_ROLL: 'bahman_dice_roll_date_v1',
  REFERRAL: 'bahman_referral_code_v1',
  REDEEMED_REFERRALS: 'bahman_redeemed_referrals_v1',
  RADIO_STATION: 'bahman_radio_station_v1',
};

// -------------------------------------------------------------
// 1. DAFTAR-E-HESAB (Debt System)
// -------------------------------------------------------------
export function getDaftarHesab(): DaftarHesabState {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DAFTAR_HESAB);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    isDebtActive: false,
    debtAmount: 0,
    debtStreak: 0,
    repossessedItem: null,
    borrowDate: null,
  };
}

export function saveDaftarHesab(state: DaftarHesabState) {
  try {
    localStorage.setItem(STORAGE_KEYS.DAFTAR_HESAB, JSON.stringify(state));
  } catch {}
}

export function borrowDebt(): { success: boolean; coinsGranted: number; state: DaftarHesabState } {
  const current = getDaftarHesab();
  if (current.isDebtActive) return { success: false, coinsGranted: 0, state: current };

  const updated: DaftarHesabState = {
    isDebtActive: true,
    debtAmount: 300,
    debtStreak: 0,
    repossessedItem: null,
    borrowDate: new Date().toISOString(),
  };
  saveDaftarHesab(updated);
  return { success: true, coinsGranted: 300, state: updated };
}

export function advanceDebtStreak(): { cleared: boolean; streak: number; state: DaftarHesabState } {
  const current = getDaftarHesab();
  if (!current.isDebtActive) return { cleared: false, streak: 0, state: current };

  const newStreak = current.debtStreak + 1;
  if (newStreak >= 3) {
    const cleared: DaftarHesabState = {
      isDebtActive: false,
      debtAmount: 0,
      debtStreak: 0,
      repossessedItem: null,
      borrowDate: null,
    };
    saveDaftarHesab(cleared);
    return { cleared: true, streak: 3, state: cleared };
  }

  const updated: DaftarHesabState = { ...current, debtStreak: newStreak };
  saveDaftarHesab(updated);
  return { cleared: false, streak: newStreak, state: updated };
}

export function failDebtStreak(ownedDecorations: string[]): { repossessedItem: string | null; state: DaftarHesabState } {
  const current = getDaftarHesab();
  if (!current.isDebtActive) return { repossessedItem: null, state: current };

  // Repossess one paid item if available, otherwise just lock debt
  const candidate = ownedDecorations.find((id) => !id.includes('halabi') && !id.includes('gelim')) || 'samovar_halabi';
  const updated: DaftarHesabState = {
    ...current,
    debtAmount: 350, // penalty with interest
    debtStreak: 0,
    repossessedItem: candidate,
  };
  saveDaftarHesab(updated);
  return { repossessedItem: candidate, state: updated };
}

export function repayDebtRepossession(): { success: boolean; state: DaftarHesabState } {
  const cleared: DaftarHesabState = {
    isDebtActive: false,
    debtAmount: 0,
    debtStreak: 0,
    repossessedItem: null,
    borrowDate: null,
  };
  saveDaftarHesab(cleared);
  return { success: true, state: cleared };
}

// -------------------------------------------------------------
// 2. SHAB-HAYE NAGHALI (Weekend Live-Ops)
// -------------------------------------------------------------
export function getNaghaliState(): NaghaliState {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NAGHALI);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    isActive: false,
    collectedPieces: [],
    isPaintingCompleted: false,
    hasClaimedReward: false,
    goldenGlassUnlocked: false,
  };
}

export function saveNaghaliState(state: NaghaliState) {
  try {
    localStorage.setItem(STORAGE_KEYS.NAGHALI, JSON.stringify(state));
  } catch {}
}

export function awardNaghaliPiece(): { newPiece: number | null; total: number; completed: boolean } {
  const state = getNaghaliState();
  if (state.collectedPieces.length >= 9) {
    return { newPiece: null, total: 9, completed: true };
  }

  const available: number[] = [];
  for (let i = 0; i < 9; i++) {
    if (!state.collectedPieces.includes(i)) available.push(i);
  }

  if (available.length === 0) return { newPiece: null, total: 9, completed: true };

  const piece = available[Math.floor(Math.random() * available.length)];
  const updatedPieces = [...state.collectedPieces, piece];
  const isCompleted = updatedPieces.length === 9;

  const updated: NaghaliState = {
    ...state,
    collectedPieces: updatedPieces,
    isPaintingCompleted: isCompleted,
    goldenGlassUnlocked: isCompleted ? true : state.goldenGlassUnlocked,
  };
  saveNaghaliState(updated);
  return { newPiece: piece, total: updatedPieces.length, completed: isCompleted };
}

// -------------------------------------------------------------
// 3. TEAHOUSE RENOVATION & DAILY TIP JAR
// -------------------------------------------------------------
export const DEFAULT_DECORATIONS: TeahouseDecoration[] = [
  // Samovars
  {
    id: 'samovar_halabi',
    name: 'سماور حلبی سنتی',
    category: 'samovar',
    tier: 1,
    price: 0,
    unlocked: true,
    description: 'سماور نوستالژیک قهوه‌خانه‌ای، همیشه قل‌قل می‌کنه',
    passiveCoinsPerDay: 50,
    icon: '☕',
  },
  {
    id: 'samovar_ghalamzani',
    name: 'سماور برنجی قلم‌زنی',
    category: 'samovar',
    tier: 2,
    price: 500,
    unlocked: false,
    description: 'نقش برجسته رستم و سهراب با جلای اصیل اصفهان',
    passiveCoinsPerDay: 100,
    icon: '✨',
  },
  {
    id: 'samovar_tala',
    name: 'سماور طلاکوب سلطنتی',
    category: 'samovar',
    tier: 3,
    price: 1500,
    unlocked: false,
    description: 'شاهکار دربار قاجار، برقش چشم هر پهلوانی رو می‌گیره',
    passiveCoinsPerDay: 200,
    icon: '👑',
  },
  // Carpets & Beds
  {
    id: 'carpet_gelim',
    name: 'گلیم دستباف ساده',
    category: 'carpet',
    tier: 1,
    price: 0,
    unlocked: true,
    description: 'گلیم خوش‌رنگ و سنتی عشایری',
    passiveCoinsPerDay: 50,
    icon: '🧶',
  },
  {
    id: 'carpet_kashan',
    name: 'قالیچه لچک‌ترنج کاشان',
    category: 'carpet',
    tier: 2,
    price: 600,
    unlocked: false,
    description: 'پشم دست‌ریس با رنگ روناس طبیعی، نرم و شاهانه',
    passiveCoinsPerDay: 120,
    icon: '🏛️',
  },
  {
    id: 'poshti_torkamoon',
    name: 'پشتی و تخت ترکمنی',
    category: 'carpet',
    tier: 3,
    price: 1200,
    unlocked: false,
    description: 'تخت چوبی منبت با پشتی‌های مخمل برای لم دادن مشتی‌ها',
    passiveCoinsPerDay: 180,
    icon: '🛋️',
  },
  // Antiques
  {
    id: 'radio_lampi',
    name: 'رادیو لامپی قدیمی',
    category: 'antique',
    tier: 2,
    price: 400,
    unlocked: false,
    description: 'خش‌خش دلنشین تصنیف‌های بنان و قمرالملوک وزیری',
    passiveCoinsPerDay: 80,
    icon: '📻',
  },
  {
    id: 'ghafas_ghanari',
    name: 'قفس قناری آوازخوان',
    category: 'antique',
    tier: 3,
    price: 800,
    unlocked: false,
    description: 'قناری خوش‌صدا که مشتری‌ها رو مست و سرخوش می‌کنه',
    passiveCoinsPerDay: 150,
    icon: '🐦',
  },
];

export function getOwnedDecorations(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DECORATIONS);
    if (raw) return JSON.parse(raw);
  } catch {}
  return ['samovar_halabi', 'carpet_gelim'];
}

export function saveOwnedDecorations(ids: string[]) {
  try {
    localStorage.setItem(STORAGE_KEYS.DECORATIONS, JSON.stringify(ids));
  } catch {}
}

export function calculateDailyTipTotal(ownedIds: string[]): number {
  return ownedIds.reduce((sum, id) => {
    const item = DEFAULT_DECORATIONS.find((d) => d.id === id);
    return sum + (item ? item.passiveCoinsPerDay : 0);
  }, 0);
}

export function getDailyTipStatus(ownedIds: string[] = getOwnedDecorations()): { canClaim: boolean; amount: number; hoursLeft: number } {
  const amount = calculateDailyTipTotal(ownedIds);
  let lastClaim: string | null = null;
  try {
    lastClaim = localStorage.getItem(STORAGE_KEYS.DAILY_TIP);
  } catch {}
  if (!lastClaim) return { canClaim: true, amount, hoursLeft: 0 };

  const diffMs = Date.now() - new Date(lastClaim).getTime();
  const hoursLeft = Math.max(0, 24 - diffMs / (1000 * 60 * 60));
  return {
    canClaim: hoursLeft === 0,
    amount,
    hoursLeft: Math.ceil(hoursLeft),
  };
}

export function claimDailyTip(ownedIds: string[] = getOwnedDecorations()): { success: boolean; coins: number } {
  const status = getDailyTipStatus(ownedIds);
  if (!status.canClaim) return { success: false, coins: 0 };

  try {
    localStorage.setItem(STORAGE_KEYS.DAILY_TIP, new Date().toISOString());
  } catch {}
  return { success: true, coins: status.amount };
}

// -------------------------------------------------------------
// 4. RETRO RADIO STATIONS
// -------------------------------------------------------------
// -------------------------------------------------------------
export type RadioCategory = 'classical' | 'folk' | 'provinces';
export type RadioStationId = number | string;

export interface RadioStationInfo {
  id: RadioStationId;
  category: RadioCategory;
  trackId: RadioTrackId;
  name: string;
  genre: string;
  emoji: string;
  dastgahTag: string;
  province?: string;
  instruments?: string;
  bgTheme:
    | 'gilan'
    | 'khorasan'
    | 'kurdistan'
    | 'azarbaijan'
    | 'bushehr'
    | 'lorestan'
    | 'fars'
    | 'isfahan'
    | 'yazd'
    | 'mazandaran'
    | 'baluchestan'
    | 'khuzestan'
    | 'classic';
  tickerMessages: string[];
}

export const RADIO_STATIONS: RadioStationInfo[] = [
  {
    id: 1,
    category: 'classical',
    trackId: 'homayoun',
    name: 'موج ۱: دستگاه همایون',
    genre: 'شوشتری، بیداد و نوای کمانچه',
    emoji: '🎻',
    dastgahTag: 'دستگاه همایون (شاهانه)',
    bgTheme: 'classic',
    tickerMessages: [
      '🎶 در حال پخش: گوشه بیداد در دستگاه همایون، نغمه‌ای عمیق و شاهانه',
      '☕ طعم زعفران قائنات و آرامش پرشکوه عصر چایخانه عمو بهمن',
      '🎻 مضراب‌های سنگین و پروقار تار و سوز پرابهت کمانچه اصیل',
      '✨ یاد ایام بارگاه و محفل اهل ادب و معرفت قدیم',
    ],
  },
  {
    id: 2,
    category: 'classical',
    trackId: 'dashti',
    name: 'موج ۲: آواز دشتی و نینوا',
    genre: 'سوز نی هفت‌بند و سه‌تار دشتستان',
    emoji: '🪈',
    dastgahTag: 'آواز دشتی (دلنشین و نوستالژیک)',
    bgTheme: 'classic',
    tickerMessages: [
      '🌾 در حال پخش: سوز نای هفت‌بند و گیلکی، نغمه‌های دیلمان و دشتستان',
      '✨ چای قندپهلو با هل اعلا و نوای دل‌انگیز نی‌نوا',
      '🌿 نسیم خنک کوهپایه و زمزمه دلتنگی‌های عاشقی',
      '🍵 دم نوش خاطره‌انگیز شب‌های دنج عمو بهمن',
    ],
  },
  {
    id: 3,
    category: 'classical',
    trackId: 'tar_sonati',
    name: 'موج ۳: سنتور و بیات اصفهان',
    genre: 'چهارمضراب‌های بلورین پایور',
    emoji: '🎼',
    dastgahTag: 'آواز اصفهان (پرشور و لطیف)',
    bgTheme: 'classic',
    tickerMessages: [
      '🎶 در حال پخش: چهارمضراب اصفهان، ریزهای بلورین مضراب بر سیم سنتور',
      '☕ سماور قل‌قل می‌کنه، چای قندپهلو دست اوستاست...',
      '🌸 نغمه‌های زلال زاینده‌رود و صفای دل مشتی‌های بازار',
      '🌿 نوای خوش سه‌تار و عطر دارچین تازه چایخانه',
    ],
  },
  {
    id: 4,
    category: 'classical',
    trackId: 'lofi_sonati',
    name: 'موج ۴: کوچه‌بازاری و طهران قدیم',
    genre: 'ریتم ۶/۸ ضربی شاد و ضرب زورخانه',
    emoji: '🪘',
    dastgahTag: 'کوچه‌بازاری (شاد و مردمی)',
    bgTheme: 'classic',
    tickerMessages: [
      '🎵 ضرب تنبک مشتی و ترانه‌های شاد لاله‌زار و طهران قدیم!',
      '👏 دست بزنید رفقا! چای تازه‌دم نثار پهلوانان مجلس!',
      '✨ ریتم شاد و مرامی کوچه پس‌کوچه‌های خاطره‌انگیز بهارستان',
      '🪘 زنگ مرشد و گرمای نفس لوتی‌های باصفای محله',
    ],
  },
  {
    id: 5,
    category: 'classical',
    trackId: 'samovar_rain',
    name: 'موج ۵: آوای آرامش و سماور',
    genre: 'قل‌قل سماور ذغالی و نم‌نم باران',
    emoji: '☕',
    dastgahTag: 'امبینت چایخانه (آرامش‌بخش)',
    bgTheme: 'classic',
    tickerMessages: [
      '🌧️ صدای باران بر شیشه‌های قدی ارسی و گرمای دلپذیر سماور ذغالی',
      '☕ خلوت دنج عمو بهمن، دمی آسودگی از هیاهوی روزگار',
      '🔥 رقص شعله‌های آتش و عطر چای لاهیجان در شب بارانی',
      '🌿 طنین آرام بخش قطرات باران و نوای ملایم چای‌ریزی',
    ],
  },
];

export const FOLK_RADIO_STATIONS: RadioStationInfo[] = [
  {
    id: 11,
    category: 'folk',
    trackId: 'folk_gilan',
    name: 'موج محلی ۱: رعنا و دیلمان',
    province: 'گیلان و مازندران (شمال)',
    genre: 'لالایی شالیزار و چای لاهیجان',
    emoji: '🌿',
    dastgahTag: 'نواحی شمال (شاد و باصفا)',
    instruments: 'نی للوا، دایره و کرنی',
    bgTheme: 'gilan',
    tickerMessages: [
      '🌿 نغمه‌های سبز شالیزار گیلان و عطر مزارع چای بهاره لاهیجان',
      '🌾 رعنا گل رعنا، نسیم مه‌آلود جنگل‌های دیلمان و دامنه سبلان',
      '🍵 چای داغ گیلانی در خنکای نم‌نم باران شمال',
      '🍃 نوای دل‌انگیز نی للوا و ریتم شاد و مردمی ترانه‌های خزر',
    ],
  },
  {
    id: 12,
    category: 'folk',
    trackId: 'folk_khorasan',
    name: 'موج محلی ۲: دوتار نوایی و الله‌مزار',
    province: 'خراسان رضوی و شمالی (شرق)',
    genre: 'مقام‌های اصیل دوتار شمال خراسان',
    emoji: '🪕',
    dastgahTag: 'نواحی شرق (حماسی و معنوی)',
    instruments: 'دوتار خراسانی، قوشمه و دایره',
    bgTheme: 'khorasan',
    tickerMessages: [
      '🪕 نوایی نوایی نوایی نوایی... همه باوفایند تو گل بی‌وفایی',
      '✨ طنین سحرانگیز سیم‌های ابریشمی دوتار در دل کویر پرستاره',
      '🕌 یاد بخشی‌های نامدار خراسان، مقام الله‌مزار و شاه‌ختایی',
      '🍵 چای قندپهلو با عطر زعفران قائنات و خلوت دلنشین چایخانه',
    ],
  },
  {
    id: 13,
    category: 'folk',
    trackId: 'folk_kurdistan',
    name: 'موج محلی ۳: تنبور و سیاه‌چمانه',
    province: 'کردستان و کرمانشاه (غرب)',
    genre: 'آوای اورامان و دف خانقاهی',
    emoji: '🪘',
    dastgahTag: 'نواحی غرب (شور و عرفان زاگرس)',
    instruments: 'تنبور کهن، دف خانقاهی و شمشال',
    bgTheme: 'kurdistan',
    tickerMessages: [
      '🪘 طنین پرطپش دف و ذکر روحانی در کوهساران اورامانات',
      '✨ نغمه‌های باستانی سیاه‌چمانه و پنجه‌های زرین تنبور گوران',
      '🏔️ استواری زاگرس و صفای مردمان غیور و پاک‌نهاد کردستان',
      '🍵 کاسه‌ای چای دارچین تازه برای رفع خستگی رهگذران کوهستان',
    ],
  },
  {
    id: 14,
    category: 'folk',
    trackId: 'folk_azarbaijan',
    name: 'موج محلی ۴: عاشیقلار و ساری‌گلین',
    province: 'آذربایجان شرقی و غربی (شمال‌غرب)',
    genre: 'نغمه بالابان و ساز قوپوز عاشیق',
    emoji: '🪈',
    dastgahTag: 'نواحی شمال‌غرب (پرشور و عاشقانه)',
    instruments: 'بالابان، قوپوز و قاوال',
    bgTheme: 'azarbaijan',
    tickerMessages: [
      '🪈 سوز سحرانگیز بالابان و نغمه جاودانه ساری گلین در دامنه‌های سبلان',
      '🌸 ترانه‌های دلکش عاشیق‌های سهند و دشت شقایق‌های دشت مغان',
      '✨ آراز آراز خان آراز، نوای زلال چشمه‌ساران سرعین و تبریز',
      '🍵 استکان کمرباریک چای لب‌سوز در بازار تاریخی تبریز',
    ],
  },
  {
    id: 15,
    category: 'folk',
    trackId: 'folk_bushehr',
    name: 'موج محلی ۵: نی‌انبان و شروه‌خوانی',
    province: 'بوشهر و هرمزگان (جنوب)',
    genre: 'ریتم پرشور بندری و دمام خلیج فارس',
    emoji: '🌊',
    dastgahTag: 'نواحی جنوب (پرانرژی و ساحلی)',
    instruments: 'نی‌انبان بندری، دمام و کسر',
    bgTheme: 'bushehr',
    tickerMessages: [
      '🌊 ریتم پرانرژی و شاد بندری، نسیم گرم و نیلگون خلیج همیشگی فارس',
      '🎺 زنگ ممتد نی‌انبان و طنین کوبنده دمام صیادان جنوب',
      '🌴 بوی رطب تازه و نخلستان‌های سر به فلک کشیده بوشهر',
      '🍵 چای هل‌دار زعفرانی بعد از صید مروارید و پهلوگیری لنج‌ها',
    ],
  },
  {
    id: 16,
    category: 'folk',
    trackId: 'folk_lorestan',
    name: 'موج محلی ۶: کمانچه لری و دایه دایه',
    province: 'لرستان و کهگیلویه (زاگرس)',
    genre: 'نغمه‌های حماسی تال و سرنای زاگرس',
    emoji: '🎻',
    dastgahTag: 'نواحی زاگرس (حماسی و کوهستانی)',
    instruments: 'تال (کمانچه لری)، سرنا و دهل',
    bgTheme: 'lorestan',
    tickerMessages: [
      '🎻 کمانچه لری (تال) و نغمه پرشور دایه دایه وقته جنگه!',
      '🌊 خروش زلال آبشار بیشه و استواری درختان دیرین بلوط زاگرس',
      '🏔️ غیرت و دلاوری پهلوانان فلک‌الافلاک و سواران لرستان',
      '🍵 پیاله چای آتشی در سیاه چادرهای دشت الشتر',
    ],
  },
];

export const PROVINCE_RADIO_STATIONS: RadioStationInfo[] = [
  {
    id: 21,
    category: 'provinces',
    trackId: 'prov_fars',
    name: 'موج استان ۱: واسونک و بهارنارنج',
    province: 'استان فارس (شیراز)',
    genre: 'نغمه‌های شاد بهارنارنج و باغ ارم',
    emoji: '🌸',
    dastgahTag: 'استان فارس (دلنشین و عاشقانه)',
    instruments: 'تار، نی، تنبک و دایره',
    bgTheme: 'fars',
    tickerMessages: [
      '🌸 عطر دل‌انگیز شکوفه‌های بهارنارنج در هوای بهشتی شیراز و حافظیه',
      '🎶 یار مبارک بادا، نغمه دل‌انگیز واسونک‌های شاد و عروسی‌های اصیل شیراز',
      '🏛️ آرامش جاودان سروهای سر به فلک کشیده باغ ارم و نارنجستان قوام',
      '🍵 استکان کمرباریک چای هل و گلاب ناب در چایخانه دلگشا',
    ],
  },
  {
    id: 22,
    category: 'provinces',
    trackId: 'prov_isfahan',
    name: 'موج استان ۲: زاینده‌رود و نقش‌جهان',
    province: 'استان اصفهان (نصف‌جهان)',
    genre: 'چهارمضراب‌های بلورین مکتب اصفهان',
    emoji: '🕌',
    dastgahTag: 'استان اصفهان (فاخر و پرشکوه)',
    instruments: 'سنتور، تار و تنبک اساتید',
    bgTheme: 'isfahan',
    tickerMessages: [
      '🕌 طنین زرین مضراب‌های سنتور زیر گنبد فیروزه‌ای مسجد شیخ لطف‌الله',
      '🌊 انعکاس دهانه‌های آجری پل خواجو و زمزمه زلال زاینده‌رود',
      '🎨 هنر قلم‌زنی و فیروزه‌کوبی استادان میدان نقش‌جهان',
      '🍵 گز فردوس و چای قندپهلو با عطر هل و گل‌گاوزبان اصفهان',
    ],
  },
  {
    id: 23,
    category: 'provinces',
    trackId: 'prov_yazd',
    name: 'موج استان ۳: بادگیرها و سکوت کویر',
    province: 'استان یزد (شهر بادگیرها)',
    genre: 'نغمه‌های عمیق سه‌تار و سازهای کویر',
    emoji: '🏜️',
    dastgahTag: 'استان یزد (عرفانی و آرامش‌بخش)',
    instruments: 'سه‌تار، نی و دایره کویری',
    bgTheme: 'yazd',
    tickerMessages: [
      '🏜️ نسیم خنک جاری در بادگیرهای افراشته و کوچه‌های کاهگلی آشتی‌کنان',
      '✨ آسمان پر از الماس و کهکشان شب‌های پرستاره کویر یزد',
      '🕯️ قنوت، قنات و قناعت؛ صفای باطنی مردمان سخت‌کوش و نجیب یزد',
      '🍵 قطاب داغ حاج خلیفه و پیاله چای گل محمدی در خانه لاری‌ها',
    ],
  },
  {
    id: 24,
    category: 'provinces',
    trackId: 'prov_mazandaran',
    name: 'موج استان ۴: نغمه‌های امیری و تبری',
    province: 'استان مازندران (طبرستان)',
    genre: 'آوای جنگل‌های هیرکانی و لله‌وا',
    emoji: '🌲',
    dastgahTag: 'استان مازندران (سرسبز و باطراوت)',
    instruments: 'لله‌وا، دوتار مازندرانی و دسرکوتن',
    bgTheme: 'mazandaran',
    tickerMessages: [
      '🌲 سوز دلنشین لله‌وا و اشعار جاودانه امیر پازواری در ییلاقات مازندران',
      '🏔️ نسیم مه‌آلود از دامنه‌های سرافراز دماوند تا سواحل نیلگون کاسپین',
      '🏡 عطر چوب خیس جنگل‌های هیرکانی و صفای کلبه‌های سنتی تلار',
      '🍵 کته کباب با چای بهاره لاهیجان و عسل کوهستان‌های کلاردشت',
    ],
  },
  {
    id: 25,
    category: 'provinces',
    trackId: 'prov_baluchestan',
    name: 'موج استان ۵: قیچک کهن و آوای لیکو',
    province: 'استان سیستان و بلوچستان (دیار آفتاب)',
    genre: 'ریتم پرشور دوچاپی و نغمه‌های پهلوانی',
    emoji: '☀️',
    dastgahTag: 'استان سیستان و بلوچستان (حماسی و کهن)',
    instruments: 'قیچک، رباب و دهلک بلوچی',
    bgTheme: 'baluchestan',
    tickerMessages: [
      '☀️ طنین جادویی قیچک و نغمه‌های حماسی شاهنامه در دیار رستم دستان',
      '🌴 خروش امواج اقیانوسی چابهار و نخلستان‌های سرفراز بمپور و سراوان',
      '🌋 استواری قله آتشفشانی تفتان و اصالت هنر سوزن‌دوزی زنان بلوچ',
      '🍵 چای کرک زعفرانی هل‌دار در سیاه چادرهای مهمان‌نواز بلوچستان',
    ],
  },
  {
    id: 26,
    category: 'provinces',
    trackId: 'prov_khuzestan',
    name: 'موج استان ۶: خروش کارون و شوشتر',
    province: 'استان خوزستان (دیار کارون و نخل)',
    genre: 'مقام‌های اصیل شوشتری و ریتم علوانیه',
    emoji: '⛵',
    dastgahTag: 'استان خوزستان (پرشور و خاطره‌انگیز)',
    instruments: 'سنتور شوشتری، ربابه، نی‌جفتی و دمام',
    bgTheme: 'khuzestan',
    tickerMessages: [
      '⛵ خروش رود پهناور کارون و پرواز مرغان دریایی گرد پل سفید اهواز',
      '🌴 نوای سوزناک علوانیه و ریتم پرطراوت دمام صیادان اروند و شط‌العرب',
      '🏛️ آبشارهای باستانی شوشتر و نخلستان‌های خرمای طلایی برحی خوزستان',
      '🍵 فنجان قهوه دله عربی و چای لب‌سوز دارچینی در شب‌های گرم کارون',
    ],
  },
];

export const ALL_RADIO_STATIONS: RadioStationInfo[] = [
  ...RADIO_STATIONS,
  ...FOLK_RADIO_STATIONS,
  ...PROVINCE_RADIO_STATIONS,
];

export function getActiveRadioStation(): RadioStationId {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.RADIO_STATION);
    if (raw) {
      const parsed = Number(raw);
      if (!isNaN(parsed)) return parsed;
      return raw;
    }
  } catch {}
  return 1;
}

export function setActiveRadioStation(station: RadioStationId) {
  try {
    localStorage.setItem(STORAGE_KEYS.RADIO_STATION, station.toString());
  } catch {}
}

// -------------------------------------------------------------
// 5. VIP BOSS CUSTOMERS
// -------------------------------------------------------------
export const VIP_BOSSES: Record<string, VIPBossCustomer> = {
  javad_sibil: {
    id: 'javad_sibil',
    name: 'جواد سبیل (عجول)',
    title: 'راننده خطی ترمینال جنوب',
    description: '۷۵ ثانیه وقت داری! انگشتاش مدام رو میز ضرب گرفته و دیر بجنبی چای‌تو رد می‌کنه!',
    avatarEmoji: '🧔',
    timeLimit: 75,
    tipReward: 200,
    dialogue: [
      'زوود باش اخوی! سرویسم راه افتاد، مسافرا منتظرن!',
      'دست بجنبون جوون! چای سرد بشه از گلو پایین نمیره!',
      'باریکلا! انعام مشتی پیش من محفوظه!',
    ],
  },
  haj_agha: {
    id: 'haj_agha',
    name: 'حاج‌آقا بازاری (سخت‌گیر)',
    title: 'بزرگ صنف قماش بازار بزرگ',
    description: '۲۴ حرکت مجاز داری! هر حرکتی رو با چرتکه و حساب کتاب دقیق زیر نظر داره!',
    avatarEmoji: '👳',
    movesLimit: 24,
    tipReward: 200,
    dialogue: [
      'حرکت اضافه توی حجره ما تاوان داره پسرم! با حساب برو جلو.',
      'چرتکه انداختم، بیشتر از ۲۴ حرکت بشه از سود می‌افته!',
      'طیب‌الله! دست به نقدی و حلال‌خوری هنرته.',
    ],
  },
  poet_shekasteh: {
    id: 'poet_shekasteh',
    name: 'شاعر دلشکسته (غمگین)',
    title: 'مرثیه‌خوان خاطرات دور',
    description: 'همه استکان‌ها زیر بخار غلیظ پوشیده شده‌اند! با هر برگشت (Undo) یک بیت غمگین می‌سراید.',
    avatarEmoji: '🥀',
    tipReward: 200,
    dialogue: [
      'چنان در غم فرو رفتم که رنگ از چای هم بگریخت...',
      'هر بار برمی‌گردی، داغ گذشته در دلم تازه می‌شود...',
      'آفرین بر تو که روشنی را به دل تاریک استکان بازگرداندی.',
    ],
  },
};

// -------------------------------------------------------------
// 6. TAKHTEH-NARD (Backgammon Dice)
// -------------------------------------------------------------
export function canRollDiceToday(): boolean {
  try {
    const lastRoll = localStorage.getItem(STORAGE_KEYS.DICE_ROLL);
    if (!lastRoll) return true;
    const lastDate = new Date(lastRoll).toDateString();
    const today = new Date().toDateString();
    return lastDate !== today;
  } catch {
    return true;
  }
}

export function rollBackgammonDice(): DiceRollResult {
  const d1 = Math.floor(Math.random() * 6) + 1;
  const d2 = Math.floor(Math.random() * 6) + 1;
  const isDouble = d1 === d2;
  const isSheshBesh = d1 === 6 && d2 === 6;

  let coins = (d1 + d2) * 10;
  if (isSheshBesh) coins = 500;
  else if (isDouble) coins = 150;

  try {
    localStorage.setItem(STORAGE_KEYS.DICE_ROLL, new Date().toISOString());
  } catch {}

  return {
    dice1: d1,
    dice2: d2,
    isDouble,
    isSheshBesh,
    coinsAwarded: coins,
    freeBooster: isSheshBesh,
  };
}

// -------------------------------------------------------------
// 7. PAHLAVANI BUSINESS CARD & REFERRALS
// -------------------------------------------------------------
export function getOrCreateReferralCode(): string {
  try {
    let code = localStorage.getItem(STORAGE_KEYS.REFERRAL);
    if (!code) {
      code = 'CHAY-' + Math.floor(1000 + Math.random() * 9000);
      localStorage.setItem(STORAGE_KEYS.REFERRAL, code);
    }
    return code;
  } catch {
    return 'CHAY-2026';
  }
}

export function redeemFriendReferral(code: string): { success: boolean; message: string } {
  try {
    const myCode = getOrCreateReferralCode();
    if (code.trim().toUpperCase() === myCode.toUpperCase()) {
      return { success: false, message: 'نمی‌تونی کد خودت رو وارد کنی پهلوون!' };
    }

    let redeemed: string[] = [];
    try {
      const redeemedRaw = localStorage.getItem(STORAGE_KEYS.REDEEMED_REFERRALS) || '[]';
      redeemed = JSON.parse(redeemedRaw);
    } catch {
      redeemed = [];
    }

    if (redeemed.includes(code.trim().toUpperCase())) {
      return { success: false, message: 'این کد دعوت رو قبلاً دریافت کردی رفیق!' };
    }

    redeemed.push(code.trim().toUpperCase());
    try {
      localStorage.setItem(STORAGE_KEYS.REDEEMED_REFERRALS, JSON.stringify(redeemed));
    } catch {}
    return { success: true, message: 'دمت گرم! ۵۰۰ سکه هدیه رفاقت به جیبت اضافه شد!' };
  } catch {
    return { success: false, message: 'خطا در ثبت کد دعوت! دوباره امتحان کن.' };
  }
}
