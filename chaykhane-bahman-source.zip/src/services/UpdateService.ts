import { AppUpdateInfo } from '../types';
import { getApiBaseUrl } from './backendApi';

// Current installed application version & code
export const APP_CURRENT_VERSION = '1.2.0';
export const APP_CURRENT_VERSION_CODE = 12;

const LAST_CHECK_KEY = 'bahman_last_update_check_v1';
const DISMISSED_VERSION_KEY = 'bahman_dismissed_update_version_v1';

/**
 * Checks for in-app updates from the backend (ghurfe.ir/api/check_update.php)
 * or falls back to public version configuration.
 */
export async function checkForAppUpdate(): Promise<AppUpdateInfo> {
  const fallbackInfo: AppUpdateInfo = {
    hasUpdate: false,
    latestVersion: APP_CURRENT_VERSION,
    latestVersionCode: APP_CURRENT_VERSION_CODE,
    currentVersion: APP_CURRENT_VERSION,
    currentVersionCode: APP_CURRENT_VERSION_CODE,
    releaseTitle: 'چایخانه سنتی عمو بهمن (آخرین نسخه)',
    releaseNotes: ['شما از جدیدترین و پایدارترین نسخه بازی استفاده می‌کنید.'],
    apkDownloadUrl: 'https://ghurfe.ir/download/bahman-teahouse.apk',
    fileSizeMb: 14.8,
    isMandatory: false,
  };

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const baseUrl = getApiBaseUrl();
    const url = `${baseUrl}/check_update.php?v=${APP_CURRENT_VERSION}&vc=${APP_CURRENT_VERSION_CODE}&t=${Date.now()}`;

    const res = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && typeof data.latestVersionCode === 'number') {
        const hasUpdate = data.latestVersionCode > APP_CURRENT_VERSION_CODE;
        return {
          hasUpdate,
          latestVersion: data.latestVersion || APP_CURRENT_VERSION,
          latestVersionCode: data.latestVersionCode,
          currentVersion: APP_CURRENT_VERSION,
          currentVersionCode: APP_CURRENT_VERSION_CODE,
          releaseTitle: data.releaseTitle || 'نسخه جدید چایخانه عمو بهمن آماده دریافت است!',
          releaseNotes: Array.isArray(data.releaseNotes) && data.releaseNotes.length > 0
            ? data.releaseNotes
            : [
                'اضافه شدن مراحل و چالش‌های هفتگی جدید',
                'بهبود شدید سرعت، کاهش لگ و بهینه‌سازی مصرف باتری',
                'رفع ایرادات گزارش‌شده و ارتقای گرافیک سنتی',
              ],
          apkDownloadUrl: data.apkDownloadUrl || 'https://ghurfe.ir/download/bahman-teahouse.apk',
          fileSizeMb: data.fileSizeMb || 15.2,
          isMandatory: Boolean(data.isMandatory),
        };
      }
    }
  } catch {
    // If offline or network error, return no-update state
  }

  return fallbackInfo;
}

/**
 * Checks whether user should be prompted (not checked too frequently and not dismissed if optional)
 */
export function shouldPromptUpdate(info: AppUpdateInfo): boolean {
  if (!info.hasUpdate) return false;
  if (info.isMandatory) return true;

  try {
    const dismissed = localStorage.getItem(DISMISSED_VERSION_KEY);
    if (dismissed === info.latestVersion) {
      return false; // User chose to skip this optional version for now
    }
  } catch {}

  return true;
}

export function dismissUpdatePrompt(version: string): void {
  try {
    localStorage.setItem(DISMISSED_VERSION_KEY, version);
  } catch {}
}

export function recordUpdateCheckedNow(): void {
  try {
    localStorage.setItem(LAST_CHECK_KEY, Date.now().toString());
  } catch {}
}
