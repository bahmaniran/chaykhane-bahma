export type DrinkType =
  | 'saffron'      // زعفران
  | 'khakshir'     // خاکشیر
  | 'tea'          // چای دارچین
  | 'doogh'        // دوغ
  | 'bahar-narenj' // بهارنارنج
  | 'bidmeshk';    // بیدمشک

export interface DrinkInfo {
  id: DrinkType;
  persianName: string;
  shortName?: string;
  subtitle: string;
  gradient: [string, string];
  char: string; // Colorblind Persian initial letter
  textureType: 'sparkle' | 'seeds' | 'clear' | 'foam' | 'warm' | 'mint';
  accentColor: string;
}

export interface Cup {
  id: number;
  layers: DrinkType[]; // bottom to top (max 4)
  isExtra?: boolean;
  hasSugarCubeBlocker?: boolean; // Sugar cube layer blocking underneath
  isSteamy?: boolean; // Mystery layer covered in steam (?)
  steamyRevealedCount?: number; // How many top layers are revealed
  coolingMovesLeft?: number; // Moves left before freezing solid
  isFrozenSolid?: boolean; // Locked frozen glass when timer hits 0
}

export interface MoveStep {
  fromIndex: number;
  toIndex: number;
  drink: DrinkType;
  count: number;
}

export type RadioTrackId =
  | 'homayoun'
  | 'dashti'
  | 'tar_sonati'
  | 'tehran_ghadim'
  | 'lofi_sonati'
  | 'samovar_rain'
  | 'silence'
  | 'folk_gilan'
  | 'folk_khorasan'
  | 'folk_kurdistan'
  | 'folk_azarbaijan'
  | 'folk_bushehr'
  | 'folk_lorestan'
  | 'prov_fars'
  | 'prov_isfahan'
  | 'prov_yazd'
  | 'prov_mazandaran'
  | 'prov_baluchestan'
  | 'prov_khuzestan';

export interface RadioTrack {
  id: RadioTrackId;
  title: string;
  subtitle: string;
  icon: string;
}

export interface ShopItem {
  id: string;
  category: 'carpet' | 'samovar' | 'window';
  name: string;
  description: string;
  price: number;
  isUnlocked: boolean;
  isEquipped: boolean;
  isSpecialOffer?: boolean;
  tier: 1 | 2 | 3;
}

export interface SugarCubeItem {
  id: number;
  name: string;
  era: string;
  unlocked: boolean;
  description: string;
}

export interface MahallehMember {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  province?: string;
  city?: string;
  avatarId?: string;
  score: number;
  cupsServed: number;
  level?: number;
  rank: number;
  badge: string;
  avatarSeed: number;
  emojisReceived?: Record<string, number>;
}

export interface PoetryRiddle {
  id: number;
  verse1: string;
  verse2Blanks: string;
  options: string[];
  correctAnswer: number;
  poet: string;
}

export interface PlayerProfile {
  deviceId: string;
  firstName: string;
  lastName: string;
  nickname: string;
  avatarId?: string;
  province?: string;
  city?: string;
  isRegistered: boolean;
  registeredAt?: number;
  emojisReceived?: Record<string, number>;
  activeBadgeId?: string;
  unlockedBadgeIds?: string[];
}

export interface WeeklyChallengeStage {
  id: number; // 1 to 5
  title: string;
  subtitle: string;
  description: string;
  drinkPool: DrinkType[];
  initialCups: Cup[];
  rewardCoins: number;
  rewardWeeklyScore: number;
  specialItemReward?: string;
  badgeTitle?: string;
  badgeIcon?: string;
  modifierLabel?: string;
}

export interface WeeklyChallengeState {
  weekKey: string; // e.g. "monday-2026-10-12"
  weekNumber: number;
  themeTitle: string;
  themeStory: string;
  startDate: string;
  nextMondayDate: string;
  completedStageIds: number[];
  weeklyScore: number;
  hasClaimedGrandPrize: boolean;
  unlockedAt: number;
}

export interface WeeklyLeaderboardCompetitor {
  id: string;
  name: string;
  neighborhood: string;
  score: number;
  stagesCompleted: number;
  rank: number;
  badge: string;
  avatarSeed: number;
  isCurrentPlayer?: boolean;
}

export interface GameState {
  currentLevel: number;
  coins: number;
  stars: number;
  extraCupsUsedInLevel: number;
  colorblindMode: boolean;
  soundEnabled: boolean;
  musicEnabled: boolean;
  volume: number;
  activeTrack: RadioTrackId;
  sugarCubesCollected: number[];
  unlockedShopItems: string[];
  equippedCarpet: string;
  equippedSamovar: string;
  equippedWindow: string;
  lastDailyChallengeDate: string;
  stateHash: string;
  playerProfile?: PlayerProfile;
  weeklyChallengeState?: WeeklyChallengeState;
}

// 2. Daftar-e-Hesab Debt System
export interface DaftarHesabState {
  isDebtActive: boolean;
  debtAmount: number; // 300 coins
  debtStreak: number; // 0 to 3 wins needed
  repossessedItem: string | null; // Item temporarily repossessed if failed
  borrowDate: string | null;
}

// 3. Naghali Weekend Live-Ops
export interface NaghaliState {
  isActive: boolean;
  collectedPieces: number[]; // 0..8 piece indices (9 total)
  isPaintingCompleted: boolean;
  hasClaimedReward: boolean;
  goldenGlassUnlocked: boolean;
}

// 4. Teahouse Renovation & Daily Tip Jar
export interface TeahouseDecoration {
  id: string;
  name: string;
  category: 'samovar' | 'carpet' | 'antique';
  tier: 1 | 2 | 3;
  price: number;
  unlocked: boolean;
  description: string;
  passiveCoinsPerDay: number;
  icon: string;
}

// 8. VIP Boss Customer
export type VIPBossType = 'javad_sibil' | 'haj_agha' | 'poet_shekasteh';

export interface VIPBossCustomer {
  id: VIPBossType;
  name: string;
  title: string;
  description: string;
  avatarEmoji: string;
  timeLimit?: number; // 45s for Javad Sibil
  movesLimit?: number; // 15 moves for Haj Agha
  dialogue: string[];
  tipReward: number; // 200 coins
}

// 9. Backgammon Dice Result
export interface DiceRollResult {
  dice1: number;
  dice2: number;
  isDouble: boolean;
  isSheshBesh: boolean; // Double 6
  coinsAwarded: number;
  freeBooster?: boolean;
}

// 10. In-App Direct APK & OTA Update System
export interface AppUpdateInfo {
  hasUpdate: boolean;
  latestVersion: string;
  latestVersionCode: number;
  currentVersion: string;
  currentVersionCode: number;
  releaseTitle: string;
  releaseNotes: string[];
  apkDownloadUrl: string;
  fileSizeMb?: number;
  isMandatory?: boolean;
}

